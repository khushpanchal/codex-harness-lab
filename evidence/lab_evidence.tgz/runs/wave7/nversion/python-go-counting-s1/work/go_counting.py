
WHITE = "W"
BLACK = "B"
NONE = ""


class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        self.board = board
        self.width = len(board[0]) if board else 0
        self.height = len(board)

    def _is_in_bounds(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height

    def _territory_at(self, x, y):
        """Return the owner and empty intersections connected to (x, y)."""
        owners = set()
        territory = set()
        stack = [(x, y)]
        seen = {(x, y)}

        while stack:
            current_x, current_y = stack.pop()
            territory.add((current_x, current_y))

            for neighbor_x, neighbor_y in (
                (current_x - 1, current_y),
                (current_x + 1, current_y),
                (current_x, current_y - 1),
                (current_x, current_y + 1),
            ):
                if not self._is_in_bounds(neighbor_x, neighbor_y):
                    continue

                neighbor = self.board[neighbor_y][neighbor_x]
                if neighbor == " ":
                    neighbor_position = (neighbor_x, neighbor_y)
                    if neighbor_position not in seen:
                        seen.add(neighbor_position)
                        stack.append(neighbor_position)
                else:
                    owners.add(neighbor)

        if len(owners) == 1:
            return owners.pop(), territory
        return NONE, territory

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not self._is_in_bounds(x, y):
            raise ValueError("Invalid coordinate")
        if self.board[y][x] != " ":
            return NONE, set()
        return self._territory_at(x, y)

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        result = {WHITE: set(), BLACK: set(), NONE: set()}
        seen = set()

        for y in range(self.height):
            for x in range(self.width):
                if self.board[y][x] != " " or (x, y) in seen:
                    continue
                owner, territory = self._territory_at(x, y)
                result[owner].update(territory)
                seen.update(territory)

        return result
