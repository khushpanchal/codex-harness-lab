import unittest

from go_counting import (
    Board,
    WHITE,
    BLACK,
    NONE,
)


class GoCountingTest(unittest.TestCase):
    def test_black_corner_territory_on_5x5_board(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        stone, territory = board.territory(x=0, y=1)
        self.assertEqual(stone, BLACK)
        self.assertSetEqual(territory, {(0, 0), (0, 1), (1, 0)})

    def test_white_center_territory_on_5x5_board(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        stone, territory = board.territory(x=2, y=3)
        self.assertEqual(stone, WHITE)
        self.assertSetEqual(territory, {(2, 3)})

    def test_open_corner_territory_on_5x5_board(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        stone, territory = board.territory(x=1, y=4)
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, {(0, 3), (0, 4), (1, 4), (2, 4), (3, 3), (3, 4)})

    def test_a_box_and_an_open_territory_on_5x5_board(self):
        board = Board([" B   ", "B B  ", "B W W", " W W ", " W W "])
        stone, territory = board.territory(x=1, y=0)
        self.assertEqual(stone, BLACK)
        self.assertSetEqual(territory, {(1, 0)})

    def test_territory_for_non_territory_cell(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        stone, territory = board.territory(x=2, y=2)
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, set())

    def test_territory_of_white(self):
        board = Board([" B   ", "B B  ", "B W W", " W W ", " W W "])
        stone, territory = board.territory(x=3, y=0)
        self.assertEqual(stone, WHITE)
        self.assertSetEqual(territory, {(3, 0), (4, 0), (4, 1)})

    def test_territories_of_whole_board(self):
        board = Board([" B   ", "B B  ", "B W W", " W W ", " W W "])
        territories = board.territories()
        self.assertSetEqual(territories[BLACK], {(1, 0)})
        self.assertSetEqual(territories[WHITE], {(3, 0), (4, 0), (4, 1)})
        self.assertSetEqual(territories[NONE], {(2, 0), (2, 1), (3, 1), (0, 4), (1, 4), (2, 4), (3, 4), (4, 2), (4, 3), (4, 4)})

    def test_territories_of_whole_board_with_only_black(self):
        board = Board(["B"])
        territories = board.territories()
        self.assertSetEqual(territories[BLACK], set())
        self.assertSetEqual(territories[WHITE], set())
        self.assertSetEqual(territories[NONE], set())

    def test_invalid_coordinate_x(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        with self.assertRaises(ValueError):
            board.territory(x=-1, y=1)

    def test_invalid_coordinate_y(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        with self.assertRaises(ValueError):
            board.territory(x=1, y=5)

    def test_invalid_coordinate_x_and_y(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        with self.assertRaises(ValueError):
            board.territory(x=-1, y=-1)

    def test_error_message_when_coordinate_invalid(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        with self.assertRaises(ValueError) as ctx:
            board.territory(x=-1, y=1)
        self.assertTrue(len(str(ctx.exception)) > 0)

    def test_empty_board_territories(self):
        board = Board(["  ", "  "])
        territories = board.territories()
        self.assertSetEqual(territories[BLACK], set())
        self.assertSetEqual(territories[WHITE], set())
        self.assertSetEqual(territories[NONE], {(0, 0), (1, 0), (0, 1), (1, 1)})

    def test_two_small_territories_area_board(self):
        board = Board(["BW", "BW"])
        territories = board.territories()
        self.assertSetEqual(territories[BLACK], set())
        self.assertSetEqual(territories[WHITE], set())
        self.assertSetEqual(territories[NONE], set())
