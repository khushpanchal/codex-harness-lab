class School:
    def __init__(self):
        self._students = {}
        self._was_added = True

    def add_student(self, name, grade):
        if name in self._students:
            self._was_added = False
            return

        self._students[name] = grade
        self._was_added = True

    def roster(self):
        students = sorted(
            self._students.items(), key=lambda student: (student[1], student[0])
        )
        return [name for name, _ in students]

    def grade(self, grade_number):
        return sorted(
            name for name, grade in self._students.items() if grade == grade_number
        )

    def added(self):
        return self._was_added
