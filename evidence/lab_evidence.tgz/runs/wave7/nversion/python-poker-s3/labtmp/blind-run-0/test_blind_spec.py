# These tests are auto-generated with test data from:
# https://github.com/exercism/problem-specifications/tree/main/exercises/poker/canonical-data.json

import unittest

from poker import (
    best_hands,
)


class PokerTest(unittest.TestCase):
    def test_single_hand_always_wins(self):
        self.assertEqual(best_hands(["4S 5S 7H 8D JC"]), ["4S 5S 7H 8D JC"])

    def test_highest_card_of_all_hands_wins(self):
        self.assertEqual(
            best_hands(["4D 5S 6S 8D 3C", "2S 4C 7S 9H 10H", "3S 4S 5D 6H JH"]),
            ["3S 4S 5D 6H JH"],
        )

    def test_a_tie_has_multiple_winners(self):
        self.assertEqual(
            best_hands(
                [
                    "4D 5S 6S 8D 3C",
                    "2S 4C 7S 9H 10H",
                    "3S 4S 5D 6H JH",
                    "3H 4H 5C 6C JD",
                ]
            ),
            ["3S 4S 5D 6H JH", "3H 4H 5C 6C JD"],
        )

    def test_multiple_hands_with_the_same_high_cards_tie_compares_next_highest_ranked_down_to_last_card(self):
        self.assertEqual(
            best_hands(["3S 5H 6D 8H 7D", "2S 5D 6D 8D 7D"]), ["3S 5H 6D 8H 7D"]
        )

    def test_winning_high_card_hand_also_has_lower_cards(self):
        self.assertEqual(
            best_hands(["2S 5H 6D 8H 7D", "3S 5D 6D 8D 7D"]), ["3S 5D 6D 8D 7D"]
        )

    def test_tie_has_multiple_winners_with_mixed_suits(self):
        self.assertEqual(
            best_hands(["3S 5H 6D 8H 7D", "2S 5D 6D 8D 7D"]), ["3S 5H 6D 8H 7D"]
        )

    def test_equal_cards_with_diamond_flush_wins(self):
        self.assertEqual(
            best_hands(["2S 4S 5S 6S 7D", "2D 4D 5D 6D 7D"]), ["2D 4D 5D 6D 7D"]
        )

    def test_equal_cards_with_3_diamond_flush_wins(self):
        self.assertEqual(
            best_hands(["2S 4S 5S 6D 7D", "2D 4D 5D 6C 7C"]), ["2S 4S 5S 6D 7D"]
        )

    def test_aces_can_end_a_straight_high(self):
        self.assertEqual(
            best_hands(["4S 5H 6C 7D 8D", "10D JH QS KD AC"]), ["10D JH QS KD AC"]
        )

    def test_aces_can_end_a_straight_high_2(self):
        self.assertEqual(
            best_hands(["KS AS TC QC JD"]), ["KS AS TC QC JD"]
        )

    def test_there_can_be_mutiple_winners_that_split_the_pot(self):
        self.assertEqual(
            best_hands(["6D 7C 8S 9H 10D", "6H 7D 8D 9S 10C"]), ["6D 7C 8S 9H 10D", "6H 7D 8D 9S 10C"]
        )

    def test_aces_cannot_be_in_the_middle_of_a_straight(self):
        self.assertEqual(
            best_hands(["4S 5H 6C 7D 8D", "QH KS AD TD JC"]), ["4S 5H 6C 7D 8D"]
        )

    def test_2_ace_is_lowest_straight(self):
        self.assertEqual(
            best_hands(["4S 5H 6C 7D 8D", "2C 3D AS TD KH"]), ["4S 5H 6C 7D 8D"]
        )

    def test_ace_lowest_straight_wins(self):
        self.assertEqual(
            best_hands(["2C 3D AS TD KH", "7S 8H 9C TD JD"]), ["2C 3D AS TD KH"]
        )

    def test_highest_pair_wins(self):
        self.assertEqual(
            best_hands(["4S 2H 6S 2D JD", "2S 4H 6C 4D JD"]), ["2S 4H 6C 4D JD"]
        )

    def test_two_pairs_beats_one_pair(self):
        self.assertEqual(
            best_hands(["2S 2H 3S 8D JD", "2S AH 2H AC 5D"]), ["2S AH 2H AC 5D"]
        )

    def test_two_pairs_ranks_are_compared(self):
        self.assertEqual(
            best_hands(["2S 2H 3C 5D JD", "2S 2H 3C 6D JD"]), ["2S 2H 3C 6D JD"]
        )

    def test_low_down_group_of_pairs_can_be_higher_ranked_pair(self):
        self.assertEqual(
            best_hands(["5C 2S 5D 8D 4C", "3S 2S 8D 8C 4H"]), ["3S 2S 8D 8C 4H"]
        )

    def test_two_pairs_first_ranked_by_largest_pair(self):
        self.assertEqual(
            best_hands(["2C 2S 5C 5D AC", "3C 3S 4C 4D AD"]), ["3C 3S 4C 4D AD"]
        )

    def test_two_pairs_second_ranked_by_kicker_after_max_group(self):
        self.assertEqual(
            best_hands(["2S AD 2H AC 5D", "2S AD 2H AC 4D"]), ["2S AD 2H AC 5D"]
        )

    def test_split_hands_have_multiple_winners(self):
        self.assertEqual(
            best_hands(["2S AH 2H AC 5D", "2C AD 2D AC 5H"]), ["2S AH 2H AC 5D", "2C AD 2D AC 5H"]
        )

    def test_three_of_a_kind_beats_two_pair(self):
        self.assertEqual(
            best_hands(["2S 2H 3C 3D 4S", "AS AH AD 8D 7H"]), ["AS AH AD 8D 7H"]
        )

    def test_three_of_a_kind_aces_beat_three_of_a_kind_kings(self):
        self.assertEqual(
            best_hands(["4S AH AS 8D AC", "4S KH KS 8D KC"]), ["4S AH AS 8D AC"]
        )

    def test_a_straight_beats_three_of_a_kind(self):
        self.assertEqual(
            best_hands(["4S AH AS 8D AC", "2C 3C 4D 5D 6S"]), ["2C 3C 4D 5D 6S"]
        )

    def test_aces_can_end_a_straight_flush(self):
        self.assertEqual(
            best_hands(["KC AH AS AD AC", "10C JC QC KC AC"]), ["10C JC QC KC AC"]
        )

    def test_a_full_house_beats_a_straight(self):
        self.assertEqual(
            best_hands(["4S 5H 4D 5D 4H", "3S 4S 5D 6H JC"]), ["4S 5H 4D 5D 4H"]
        )

    def test_full_house_aces_beat_full_house_kings(self):
        self.assertEqual(
            best_hands(["AH AS AD 5C 5H", "KH KS KD 4C 4H"]), ["AH AS AD 5C 5H"]
        )

    def test_full_house_3_3_3_beats_full_house_2_2_2(self):
        self.assertEqual(
            best_hands(["3S 3H 3D 2S 2H", "2S 2H 2D 3S 3H"]), ["3S 3H 3D 2S 2H"]
        )

    def test_full_house_ranked_by_remaining_card(self):
        self.assertEqual(
            best_hands(["5H 5D 5S 3S 3H", "5H 5D 5S 4S 4H"]), ["5H 5D 5S 4S 4H"]
        )

    def test_a_flush_beats_a_full_house(self):
        self.assertEqual(
            best_hands(["4S 5H 4D 5D 4H", "2C 3C 8C 9C 10C"]), ["2C 3C 8C 9C 10C"]
        )

    def test_flush_beats_flush(self):
        self.assertEqual(
            best_hands(["2H 3H 8H 9H 10H", "2C 3C 8C 9C JC"]), ["2C 3C 8C 9C JC"]
        )

    def test_a_straight_flush_beats_four_of_a_kind(self):
        self.assertEqual(
            best_hands(["4S AH AS 7D AC", "3C 4C 5C 6C 7C"]), ["3C 4C 5C 6C 7C"]
        )

    def test_a_beats_a(self):
        self.assertEqual(
            best_hands(["5H AH AS AD AC", "5C AC AS AD AH"]), ["5H AH AS AD AC", "5C AC AS AD AH"]
        )

    def test_royal_flush_beats_straight_flush(self):
        self.assertEqual(
            best_hands(["10C JC QC KC AC", "9C JC QC KC AC"]), ["10C JC QC KC AC"]
        )

    def test_straight_flush_aces_can_be_low_ace_low_straight_wins(self):
        self.assertEqual(
            best_hands(["2H 3H 4H 5H 6H", "AD 2D 3D 4D 5D"]), ["2H 3H 4H 5H 6H"]
        )

    def test_straight_flush_aces_can_be_low_the_other_wins(self):
        self.assertEqual(
            best_hands(["2C 3D AS TD KH", "AD 2D 3D 4D 5D"]), ["AD 2D 3D 4D 5D"]
        )

    def test_four_of_a_kind_beats_full_house(self):
        self.assertEqual(
            best_hands(["4S 5H 4D 5D 4H", "3S 3H 2S 2D 3D"]), ["4S 5H 4D 5D 4H"]
        )

    def test_four_of_a_kind_beats_four_of_a_kind(self):
        self.assertEqual(
            best_hands(["4S 5H 5D 5S 4H", "3S 3H 3D 3S 3D".replace("3D 3S 3D", "3C 3S 3D")]),
            ["3S 3H 3D 3C 3S 3D".replace("3D 3C", "3C")],
        )

    def test_four_of_a_kind_ranked_by_kicker(self):
        self.assertEqual(
            best_hands(["2S 2H 2C 2D 5H", "2S 2H 2C 2D 4H"]), ["2S 2H 2C 2D 5H"]
        )

    def test_high_card_ace_wins_over_high_card_king(self):
        self.assertEqual(
            best_hands(["4D 5S 6S 8D 3C", "KS AS TC QC JD".replace("KS AS", "2S AS")]),
            best_hands(["2S AS TC QC JD"]),
        )


if __name__ == "__main__":
    unittest.main()
