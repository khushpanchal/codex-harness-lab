RANK_VALUES = {
    "2": 2,
    "3": 3,
    "4": 4,
    "5": 5,
    "6": 6,
    "7": 7,
    "8": 8,
    "9": 9,
    "10": 10,
    "T": 10,
    "J": 11,
    "Q": 12,
    "K": 13,
    "A": 14,
}

SUIT_VALUES = {"C": 1, "D": 2, "H": 3, "S": 4}

HIGH_CARD, PAIR, TWO_PAIR, THREE_OF_A_KIND, STRAIGHT = range(5)
FLUSH, FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH = range(5, 9)


class Card:
    def __init__(self, text):
        if len(text) not in (2, 3):
            raise ValueError(f"invalid card: {text!r}")

        rank, suit = text[:-1], text[-1]
        if rank not in RANK_VALUES or suit not in SUIT_VALUES:
            raise ValueError(f"invalid card: {text!r}")

        self.rank = RANK_VALUES[rank]
        self.suit = suit


def _rank_counts(cards):
    counts = {}
    for card in cards:
        counts[card.rank] = counts.get(card.rank, 0) + 1
    return counts


def _grouped_ranks(counts):
    return sorted(counts, key=lambda rank: (counts[rank], rank), reverse=True)


def _straight_high(ranks):
    unique = sorted(set(ranks), reverse=True)
    if len(unique) != 5:
        return None

    # The ace also serves as the low card in an A-2-3-4-5 straight.
    if unique == [14, 5, 4, 3, 2]:
        return 5
    if unique[0] - unique[4] == 4:
        return unique[0]
    return None


def _rank_hand(hand):
    """Return a tuple whose lexical order matches poker hand strength."""
    cards = hand
    ranks = [card.rank for card in cards]
    is_flush = len({card.suit for card in cards}) == 1
    counts = _rank_counts(cards)
    groups = _grouped_ranks(counts)
    straight_high = _straight_high(ranks)

    if straight_high is not None and is_flush:
        return (STRAIGHT_FLUSH, straight_high)
    if max(counts.values()) == 4:
        return (FOUR_OF_A_KIND, *groups)
    if len(counts) == 2:
        return (FULL_HOUSE, groups[0], groups[1])
    if is_flush:
        return (FLUSH, *sorted(ranks, reverse=True))
    if straight_high is not None:
        return (STRAIGHT, straight_high)
    if max(counts.values()) == 3:
        return (THREE_OF_A_KIND, groups[0], groups[1], groups[2])
    if sorted(counts.values()) == [1, 2, 2]:
        return (TWO_PAIR, groups[0], groups[1], groups[2])
    if max(counts.values()) == 2:
        return (PAIR, groups[0], groups[1], groups[2], groups[3])
    return (HIGH_CARD, *sorted(ranks, reverse=True))


def _parse_hand(hand):
    if not isinstance(hand, str):
        raise ValueError("hand must be a string")

    cards = [Card(text) for text in hand.split()]
    if len(cards) != 5:
        raise ValueError("hand must contain exactly 5 cards")
    if len({(card.rank, card.suit) for card in cards}) != 5:
        raise ValueError("hand must contain 5 distinct cards")
    return cards


def best_hands(hands):
    if not hands:
        return []

    parsed_hands = [(hand, _parse_hand(hand)) for hand in hands]
    best_rank = max(_rank_hand(cards) for _, cards in parsed_hands)
    return [hand for hand, cards in parsed_hands if _rank_hand(cards) == best_rank]
