pub fn answer(command: &str) -> Option<i32> {
    let command = command.trim();
    let tokens = command.strip_suffix('?').unwrap_or(command).split_whitespace();
    let mut tokens = tokens.peekable();

    if tokens.next()? != "What" || tokens.next()? != "is" {
        return None;
    }

    let mut value = parse_i32(tokens.next()?)?;

    while tokens.peek().is_some() {
        let operator = tokens.next()?;
        if operator == "multiplied" || operator == "divided" {
            if tokens.next()? != "by" {
                return None;
            }
            let operand = parse_i32(tokens.next()?)?;
            value = match operator {
                "multiplied" => value.checked_mul(operand)?,
                _ => value.checked_div(operand)?,
            };
        } else if operator == "plus" || operator == "minus" {
            let operand = parse_i32(tokens.next()?)?;
            value = match operator {
                "plus" => value.checked_add(operand)?,
                _ => value.checked_sub(operand)?,
            };
        } else if cfg!(feature = "exponentials") && operator == "raised" {
            let power = parse_exponent(&mut tokens)?;
            value = checked_power(value, power)?;
        } else {
            return None;
        }
    }

    Some(value)
}

fn parse_i32(token: &str) -> Option<i32> {
    let digits = token.strip_prefix('-').unwrap_or(token);
    if digits.is_empty() || !digits.bytes().all(|byte| byte.is_ascii_digit()) {
        return None;
    }
    token.parse().ok()
}

#[cfg(feature = "exponentials")]
fn parse_exponent<'a, I>(tokens: &mut I) -> Option<i32>
where
    I: Iterator<Item = &'a str>,
{
    if tokens.next()? != "the" {
        return None;
    }
    let number = tokens.next()?;
    let suffix_token = tokens.next()?;
    if suffix_token != "power" {
        return None;
    }

    let ordinal = number
        .strip_prefix('-')
        .unwrap_or(number)
        .bytes()
        .position(|byte| !byte.is_ascii_digit())?;
    let (digits, suffix) = number.split_at(ordinal);
    if !matches!(suffix, "st" | "nd" | "rd" | "th") {
        return None;
    }
    parse_i32(digits)
}

#[cfg(feature = "exponentials")]
fn checked_power(base: i32, exponent: i32) -> Option<i32> {
    if exponent < 0 {
        return None;
    }

    let mut result: i32 = 1;
    let mut base = base;
    let mut exponent = exponent;
    while exponent > 0 {
        if exponent & 1 == 1 {
            result = result.checked_mul(base)?;
        }
        exponent >>= 1;
        if exponent > 0 {
            base = base.checked_mul(base)?;
        }
    }
    Some(result)
}

#[cfg(not(feature = "exponentials"))]
fn parse_exponent<'a, I>(_: &mut I) -> Option<i32>
where
    I: Iterator<Item = &'a str>,
{
    None
}

#[cfg(not(feature = "exponentials"))]
fn checked_power(_: i32, _: i32) -> Option<i32> {
    None
}
