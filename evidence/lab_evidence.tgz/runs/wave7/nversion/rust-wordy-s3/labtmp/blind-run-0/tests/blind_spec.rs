use wordy::*;

#[test]
fn just_a_number() {
    assert_eq!(answer("What is 5?"), Some(5));
}

#[test]
fn large_number() {
    assert_eq!(answer("What is 1234567890?"), Some(1234567890));
}

#[test]
fn negative_number() {
    assert_eq!(answer("What is -3?"), Some(-3));
}

#[test]
fn addition() {
    assert_eq!(answer("What is 5 plus 13?"), Some(18));
}

#[test]
fn addition_negative() {
    assert_eq!(answer("What is -1 plus -10?"), Some(-11));
}

#[test]
fn subtraction() {
    assert_eq!(answer("What is 7 minus 5?"), Some(2));
}

#[test]
fn subtraction_negative_result() {
    assert_eq!(answer("What is 5 minus 7?"), Some(-2));
}

#[test]
fn multiplication() {
    assert_eq!(answer("What is 6 multiplied by 4?"), Some(24));
}

#[test]
fn division() {
    assert_eq!(answer("What is 25 divided by 5?"), Some(5));
}

#[test]
fn addition_chain() {
    assert_eq!(answer("What is 5 plus 13 plus 6?"), Some(24));
}

#[test]
fn left_to_right_not_order_of_operations() {
    assert_eq!(answer("What is 3 plus 2 multiplied by 3?"), Some(15));
}

#[test]
fn mixed_operations() {
    assert_eq!(answer("What is 1 plus 1 minus 1?"), Some(1));
}

#[test]
fn mixed_operations_two() {
    assert_eq!(answer("What is 20 minus 4 divided by 2?"), Some(8));
}

#[test]
fn unsupported_operation() {
    assert_eq!(answer("What is 52 cubed?"), None);
}

#[test]
fn non_math_question() {
    assert_eq!(
        answer("Who is the President of the United States"),
        None
    );
}

#[test]
fn invalid_syntax_double_operator() {
    assert_eq!(answer("What is 1 plus plus 2?"), None);
}

#[test]
fn empty_input() {
    assert_eq!(answer(""), None);
}

#[test]
fn trailing_garbage() {
    assert_eq!(answer("What is 5 plus 2 times?"), None);
}
