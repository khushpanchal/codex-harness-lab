def best_hands(hands):
    """Return all hands tied for the highest standard five-card poker ranking."""
    rankings = [(rank_hand(hand), hand) for hand in hands]
    best_rank = max(rank for rank, _ in rankings)
    return [hand for rank, hand in rankings if rank == best_rank]


def rank_hand(hand):
    """Return a comparable tuple describing a hand's category and tiebreakers."""
    cards = hand.split()
    ranks = sorted((card_rank(card[:-1]) for card in cards), reverse=True)
    suits = {card[-1] for card in cards}
    flush = len(suits) == 1
    straight_high = straight_rank(ranks)

    if len(cards) != 5 or len(set(cards)) != 5:
        return -1, (0,)

    count_by_rank = {}
    for rank in ranks:
        count_by_rank[rank] = count_by_rank.get(rank, 0) + 1
    groups = sorted(count_by_rank.items(), key=lambda item: (-item[1], -item[0]))
    counts = tuple(count for _, count in groups)
    ordered_ranks = tuple(rank for rank, _ in groups)

    if straight_high and flush:
        category = 8
        tiebreak = (straight_high,)
    elif counts == (4, 1):
        category = 7
        tiebreak = ordered_ranks
    elif counts == (3, 2):
        category = 6
        tiebreak = ordered_ranks
    elif flush:
        category = 5
        tiebreak = tuple(ranks)
    elif straight_high:
        category = 4
        tiebreak = (straight_high,)
    elif counts[0] == 3:
        category = 3
        tiebreak = ordered_ranks
    elif counts[:2] == (2, 2):
        category = 2
        tiebreak = ordered_ranks
    elif counts[0] == 2:
        category = 1
        tiebreak = ordered_ranks
    else:
        category = 0
        tiebreak = tuple(ranks)

    return category, tiebreak


def card_rank(label):
    if label.isdigit():
        return int(label)
    return FACE_RANKS[label]


def straight_rank(ranks):
    unique = sorted(set(ranks), reverse=True)
    if len(unique) != 5:
        return None
    if unique[0] - unique[-1] == 4:
        return unique[0]
    # Ace-low straight: A, 5, 4, 3, 2 has high card 5.
    if unique == (14, 5, 4, 3, 2):
        return 5
    return None


FACE_RANKS = {
    "2": 2,
    "3": 3,
    "4": 4,
    "5": 5,
    "6": 6,
    "7": 7,
    "8": 8,
    "9": 9,
    "10": 10,
    "T": 10,
    "J": 11,
    "Q": 12,
    "K": 13,
    "A": 14,
}
