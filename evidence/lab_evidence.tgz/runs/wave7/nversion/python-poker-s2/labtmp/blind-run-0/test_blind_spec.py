import unittest

from poker import best_hands


class PokerTest(unittest.TestCase):
    def test_single_hand_always_wins(self):
        self.assertEqual(best_hands(["4S 5S 7H 8D JC"]), ["4S 5S 7H 8D JC"])

    def test_highest_card_of_all_hands_wins(self):
        self.assertEqual(
            best_hands(["4D 5S 6S 8D 3C", "2S 4C 7S 9H 10H", "3S 4S 5D 6H JH"]),
            ["3S 4S 5D 6H JH"],
        )

    def test_a_tie_has_multiple_winners(self):
        self.assertEqual(
            best_hands(
                [
                    "4D 5S 6S 8D 3C",
                    "2S 4C 7S 9H 10H",
                    "3S 4S 5D 6H JH",
                    "3H 4H 5C 6C JD",
                ]
            ),
            ["3S 4S 5D 6H JH", "3H 4H 5C 6C JD"],
        )

    def test_multiple_hands_with_the_same_high_cards_tie_to_lowest_card_thereafter(self):
        self.assertEqual(
            best_hands(["4S 5H 6S 8D JC", "2S 4C 7S 9H 10H", "3S 4S 5D 6H JH"]),
            ["4S 5H 6S 8D JC"],
        )

    def test_two_pairs_wins(self):
        self.assertEqual(
            best_hands(["4S 2H 6S 2D JH", "2S 4D 6S 9H JH"]), ["4S 2H 6S 2D JH"]
        )

    def test_one_pair_beats_high_card(self):
        self.assertEqual(
            best_hands(["4S 5H 6C 8D KH", "2S 4D 6S 9D JH", "3S 4S 5D 6H JD"]),
            ["2S 4D 6S 9D JH"],
        )

    def test_two_pairs_ranks_are_ordered_by_value_of_higher_pair(self):
        self.assertEqual(
            best_hands(["2S 8H 6S 8D JH", "4S 5H 4S 5D JH"]), ["2S 8H 6S 8D JH"]
        )

    def test_two_pairs_second_pair_cascades(self):
        self.assertEqual(
            best_hands(["2S QS 2C QD JH", "JD QH JS 8D QH"]), ["JD QH JS 8D QH"]
        )

    def test_two_pairs_last_kicker_cascades(self):
        self.assertEqual(
            best_hands(["JD QH JS 8D QH", "JS QS JH 2D QD"]), ["JD QH JS 8D QH"]
        )

    def test_three_of_a_kind_beats_two_pair(self):
        self.assertEqual(
            best_hands(["2S 2H 6S 6D JH", "QS AS 8S 8D 8H"]), ["QS AS 8S 8D 8H"]
        )

    def test_two_three_of_a_kind_set_of_higher_three_cards_is_winner(self):
        self.assertEqual(
            best_hands(["2S 2H 4C 8D 2H", "3S 3H 4C 8D 3H"]), ["3S 3H 4C 8D 3H"]
        )

    def test_low_three_of_a_kind_beats_high_two_pair(self):
        self.assertEqual(
            best_hands(["2S 2H 4C 8D 2H", "3S 8H 4C 8D 8H"]), ["2S 2H 4C 8D 2H"]
        )

    def test_three_of_a_kind_kicker_cascades(self):
        self.assertEqual(
            best_hands(["3S 3H 4C 8D 2H", "3S 3H 4C 8D 3H"]), ["3S 3H 4C 8D 3H"]
        )

    def test_a_straight_beats_three_of_a_kind(self):
        self.assertEqual(
            best_hands(["4S 5H 6C 8D KH", "4S AD 6S 7D 8H"]), ["4S AD 6S 7D 8H"]
        )

    def test_aces_can_end_a_straight_high(self):
        self.assertEqual(best_hands(["4S 5H 6C 7D 8H", "10S JH QC KD AS"]), ["10S JH QC KD AS"])

    def test_aces_can_start_a_straight_low(self):
        self.assertEqual(best_hands(["4S 5H 6C 7D 8H", "AS 2H 3C 4D 5H"]), ["4S 5H 6C 7D 8H"])

    def test_aces_cannot_be_in_the_middle_of_a_straight(self):
        self.assertEqual(
            best_hands(["2C 3D 4H 5S 6S", "AS QD AC KH AH"]), ["2C 3D 4H 5S 6S"]
        )

    def test_both_hands_with_a_straight_tie_to_highest_ranked_card(self):
        self.assertEqual(
            best_hands(["4S 6C 7S 8D 5H", "5S 7H 8S 9D 6H"]), ["5S 7H 8S 9D 6H"]
        )

    def test_even_though_an_ace_is_usually_high_a_low_straight_wins(self):
        self.assertEqual(best_hands(["KH 9C AD 5S TC", "QC JC 2S 4H 3D"]), ["QC JC 2S 4H 3D"])

    def test_flush_beats_a_straight(self):
        self.assertEqual(
            best_hands(["4C 6H 7D 8D 5H", "2S 4S 5S 6S 7S"]), ["2S 4S 5S 6S 7S"]
        )

    def test_both_hands_with_a_flush_tie_to_high_card_then_down(self):
        self.assertEqual(
            best_hands(["2H 7H 8H 9H 6H", "3S 5S 6S 7S 8S"]), ["2H 7H 8H 9H 6H"]
        )

    def test_full_house_beats_a_flush(self):
        self.assertEqual(
            best_hands(["3H 6H 7H 8H 5H", "4S 5H 4C 5D KH"]), ["4S 5H 4C 5D KH"]
        )

    def test_both_hands_with_a_full_house_tie_by_triplets(self):
        self.assertEqual(
            best_hands(["4H 4S 4D 9S 9D", "5H 5S 5D 8S 8D"]), ["5H 5S 5D 8S 8D"]
        )

    def test_full_house_compare_kicker_last(self):
        self.assertEqual(
            best_hands(["5H 5S 5D 9S 9D", "5H 5S 5D 8S 8D"]), ["5H 5S 5D 9S 9D"]
        )

    def test_four_of_a_kind_beats_a_full_house(self):
        self.assertEqual(
            best_hands(["4S 5H 4D 5D KH", "3S 3H 2S 2D 3H"]), ["3S 3H 2S 2D 3H"]
        )

    def test_both_hands_with_four_of_a_kind_tie_by_quads(self):
        self.assertEqual(
            best_hands(["2S 2H 2C 8D 2D", "4S 4H 6C 4D 4D"]), ["4S 4H 6C 4D 4D"]
        )

    def test_four_of_a_kind_kicker_cascades(self):
        self.assertEqual(
            best_hands(["2S 2H 2C 8D 2D", "2S 2H 2C 8D 2H"]), ["2S 2H 2C 8D 2D"]
        )

    def test_straight_flush_beats_four_of_a_kind(self):
        self.assertEqual(
            best_hands(["4S 5H 5D 5D KH", "3S 4S 5S 6S 7S"]), ["3S 4S 5S 6S 7S"]
        )

    def test_aces_can_end_a_straight_flush_high(self):
        self.assertEqual(
            best_hands(["KC AH AS AD AC", "10C JC QC KC AC"]), ["10C JC QC KC AC"]
        )

    def test_aces_can_start_a_straight_flush_low(self):
        self.assertEqual(
            best_hands(["KS AH AS AD AC", "AC 2C 3C 4C 5C"]), ["AC 2C 3C 4C 5C"]
        )

    def test_both_hands_with_a_straight_flush_tie_to_highest_ranked_card(self):
        self.assertEqual(
            best_hands(["4C 6C 7C 8C 5C", "5S 7S 8S 9S 6S"]), ["5S 7S 8S 9S 6S"]
        )

    def test_even_though_an_ace_is_usually_high_a_low_straight_flush_wins(self):
        self.assertEqual(
            best_hands(["KH 9C AD 5S TC", "QC JC 2S 4H 3D"]), ["QC JC 2S 4H 3D"]
        )

    def test_five_of_a_kind_beats_straight_flush(self):
        # not a standard poker hand; only include if spec mentions it - skip
        pass

    def test_straight_flush_aces_can_be_high(self):
        self.assertEqual(best_hands(["AS KS QS JS TS"]), ["AS KS QS JS TS"])

    def test_high_card_kicker_cascades_fully(self):
        self.assertEqual(
            best_hands(["AH 2C 3D 4S 6S", "2H 3C 4D 5S 6H"]), ["AH 2C 3D 4S 6S"]
        )

    def test_two_high_cards_same_to_fifth_card(self):
        self.assertEqual(
            best_hands(["AS KC QH 9D 8C", "AH KC QH 9D 7C"]), ["AS KC QH 9D 8C"]
        )


if __name__ == "__main__":
    unittest.main()
