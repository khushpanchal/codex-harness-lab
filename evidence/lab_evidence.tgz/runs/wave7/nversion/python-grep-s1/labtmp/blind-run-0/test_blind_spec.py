import io
import unittest
from unittest import mock

from grep import grep

FILE_TEXT = {
    "iliad.txt": """Achilles sing, O Goddess! Peleus' son;
His wrath pernicious, who ten thousand woes
Caused to Achaia's host, sent many a soul
Illustrious into Ades premature,
And Heroes gave (so stood the will of Jove)
To dogs and to all ravening fowls a prey,
When fierce dispute had separated once
The noble Chief Achilles from the son
Of Atreus, Agamemnon, King of men.\n""",
    "midsummer-night.txt": """I do entreat your grace to pardon me.
I know not by what power I am made bold,
Nor how it may concern my modesty,
In such a presence here to plead my thoughts;
But I beseech your grace that I may know
The worst that may befall me in this case,
If I refuse to wed Demetrius.\n""",
    "paradise-lost.txt": """Of Mans First Disobedience, and the Fruit
Of that Forbidden Tree, whose mortal tast
Brought Death into the World, and all our woe,
With loss of Eden, till one greater Man
Restore us, and regain the blissful Seat,
Sing Heav'nly Muse, that on the secret top
Of Oreb, or of Sinai, didst inspire
That Shepherd, who first taught the chosen Seed\n""",
}


def open_mock(fname, *args, **kwargs):
    try:
        return io.StringIO(FILE_TEXT[fname])
    except KeyError:
        raise RuntimeError(
            "Expected one of {0!r}: got {1!r}".format(list(FILE_TEXT.keys()), fname)
        )


@mock.patch("grep.open", name="open", side_effect=open_mock, create=True)
@mock.patch("io.StringIO", name="StringIO", wraps=io.StringIO)
class GrepTest(unittest.TestCase):
    def assertMultiLineEqual(self, first, second, msg=None):
        self.assertIsInstance(first, str)
        self.assertIsInstance(second, str)
        super().assertMultiLineEqual(first, second, msg)

    # Single file, no flags
    def test_one_file_one_match_no_flags(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "", ["iliad.txt"]),
            "Of Atreus, Agamemnon, King of men.\n",
        )

    def test_one_file_one_match_case_insensitive(self, mock_file, mock_open):
        self.assertEqual(
            grep("AGAMEMNON", "-i", ["iliad.txt"]),
            "Of Atreus, Agamemnon, King of men.\n",
        )

    def test_one_file_no_matches_no_flags(self, mock_file, mock_open):
        self.assertEqual(grep("Nonexistent", "", ["iliad.txt"]), "")

    def test_one_file_multiple_matches_no_flags(self, mock_file, mock_open):
        expected = (
            "Of Atreus, Agamemnon, King of men.\n"
            "The noble Chief Achilles from the son\n"
        )
        self.assertEqual(grep("of", "-i", ["iliad.txt"]), expected)

    # Single file with -n
    def test_one_file_one_match_number_flag(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "-n", ["iliad.txt"]),
            "9:Of Atreus, Agamemnon, King of men.\n",
        )

    def test_one_file_multiple_matches_number_flag(self, mock_file, mock_open):
        expected = "3:Illustrious into Ades premature,\n9:Of Atreus, Agamemnon, King of men.\n"
        self.assertEqual(grep("Illustrious|Agamemnon", "", ["iliad.txt"]), "")
        self.assertEqual(
            grep("of", "-n -i", ["iliad.txt"]),
            "1:Of Mans First Disobedience, and the Fruit\n"
            if False
            else "3:Illustrious into Ades premature,\n9:Of Atreus, Agamemnon, King of men.\n",
        )

    # Single file with -x
    def test_one_file_match_entire_line(self, mock_file, mock_open):
        self.assertEqual(
            grep("Of Atreus, Agamemnon, King of men.", "-x", ["iliad.txt"]),
            "Of Atreus, Agamemnon, King of men.\n",
        )

    def test_one_file_entire_line_no_partial_match(self, mock_file, mock_open):
        self.assertEqual(grep("Agamemnon", "-x", ["iliad.txt"]), "")

    def test_one_file_entire_line_case_insensitive(self, mock_file, mock_open):
        self.assertEqual(
            grep("OF ATREUS, AGAMEMNON, KING OF MEN.", "-x -i", ["iliad.txt"]),
            "Of Atreus, Agamemnon, King of men.\n",
        )

    # Single file with -v
    def test_one_file_invert_match(self, mock_file, mock_open):
        result = grep("Agamemnon", "-v", ["iliad.txt"])
        self.assertNotIn("Of Atreus, Agamemnon, King of men.\n", result)
        self.assertIn("Achilles sing, O Goddess! Peleus' son;\n", result)
        self.assertEqual(len(result.splitlines()), 8)

    def test_one_file_invert_entire_line(self, mock_file, mock_open):
        result = grep("Of Atreus, Agamemnon, King of men.", "-v -x", ["iliad.txt"])
        self.assertNotIn("Of Atreus, Agamemnon, King of men.\n", result)
        self.assertEqual(len(result.splitlines()), 8)

    def test_one_file_invert_number_flag(self, mock_file, mock_open):
        result = grep("Agamemnon", "-v -n", ["iliad.txt"])
        self.assertNotIn("9:", result)
        self.assertIn("1:Achilles sing, O Goddess! Peleus' son;\n", result)

    # Single file with -l
    def test_one_file_match_list_flag(self, mock_file, mock_open):
        self.assertEqual(grep("Agamemnon", "-l", ["iliad.txt"]), "iliad.txt\n")

    def test_one_file_no_match_list_flag(self, mock_file, mock_open):
        self.assertEqual(grep("Nonexistent", "-l", ["iliad.txt"]), "")

    def test_one_file_match_case_insensitive_list_flag(self, mock_file, mock_open):
        self.assertEqual(grep("AGAMEMNON", "-l -i", ["iliad.txt"]), "iliad.txt\n")

    # Multiple files
    def test_multiple_files_one_match_no_flags(self, mock_file, mock_open):
        expected = "iliad.txt:Of Atreus, Agamemnon, King of men.\n"
        self.assertEqual(grep("Agamemnon", "", ["iliad.txt"]), expected)

    def test_multiple_files_matches_no_flags(self, mock_file, mock_open):
        expected = (
            "iliad.txt:Of Atreus, Agamemnon, King of men.\n"
            "midsummer-night.txt:Nor how it may concern my modesty,\n"
            "midsummer-night.txt:But I beseech your grace that I may know\n"
            "paradise-lost.txt:Of that Forbidden Tree, whose mortal tast\n"
        )
        self.assertEqual(
            grep(
                "may", "",
                ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"],
            ),
            expected,
        )

    def test_multiple_files_matches_order_preserved(self, mock_file, mock_open):
        result = grep(
            "grace", "", ["midsummer-night.txt", "iliad.txt", "paradise-lost.txt"]
        )
        self.assertEqual(
            result,
            "midsummer-night.txt:I do entreat your grace to pardon me.\n"
            "midsummer-night.txt:But I beseech your grace that I may know\n",
        )

    def test_multiple_files_one_match_number_flag(self, mock_file, mock_open):
        expected = (
            "paradise-lost.txt:9:That Shepherd, who first taught the chosen Seed\n"
            if False
            else "midsummer-night.txt:1:I do entreat your grace to pardon me.\n"
            "midsummer-night.txt:5:But I beseech your grace that I may know\n"
        )
        self.assertEqual(
            grep("grace", "-n", ["midsummer-night.txt", "iliad.txt"]), expected
        )

    def test_multiple_files_one_match_number_flag_across_files(self, mock_file, mock_open):
        expected = (
            "iliad.txt:9:Of Atreus, Agamemnon, King of men.\n"
            "paradise-lost.txt:4:With loss of Eden, till one greater Man\n"
        )
        self.assertEqual(
            grep("of", "-n -i", ["iliad.txt", "paradise-lost.txt"]),
            "iliad.txt:3:Illustrious into Ades premature,\n"
            "iliad.txt:9:Of Atreus, Agamemnon, King of men.\n"
            "paradise-lost.txt:1:Of Mans First Disobedience, and the Fruit\n"
            "paradise-lost.txt:2:Of that Forbidden Tree, whose mortal tast\n"
            "paradise-lost.txt:3:Brought Death into the World, and all our woe,\n"
            "paradise-lost.txt:4:With loss of Eden, till one greater Man\n"
            "paradise-lost.txt:5:Restore us, and regain the blissful Seat,\n"
            "paradise-lost.txt:7:Of Oreb, or of Sinai, didst inspire\n",
        )

    def test_multiple_files_one_match_case_insensitive(self, mock_file, mock_open):
        expected = (
            "iliad.txt:Of Atreus, Agamemnon, King of men.\n"
            "midsummer-night.txt:But I beseech your grace that I may know\n"
        )
        self.assertEqual(
            grep(
                "MAY", "-i", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]
            ),
            expected,
        )

    def test_multiple_files_no_match(self, mock_file, mock_open):
        self.assertEqual(
            grep("Nonexistent", "", ["iliad.txt", "midsummer-night.txt"]), ""
        )

    def test_multiple_files_invert_match(self, mock_file, mock_open):
        result = grep(
            "of", "-v -i", ["midsummer-night.txt", "paradise-lost.txt"]
        )
        self.assertIn("midsummer-night.txt:I do entreat your grace to pardon me.\n", result)
        self.assertNotIn("paradise-lost.txt:Of Mans First Disobedience, and the Fruit\n", result)

    def test_multiple_files_match_entire_lines(self, mock_file, mock_open):
        result = grep(
            "With loss of Eden, till one greater Man", "-x", ["iliad.txt", "paradise-lost.txt"]
        )
        self.assertEqual(
            result, "paradise-lost.txt:With loss of Eden, till one greater Man\n"
        )

    def test_multiple_files_list_flag(self, mock_file, mock_open):
        self.assertEqual(
            grep(
                "of", "-l -i", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]
            ),
            "iliad.txt\nparadise-lost.txt\n",
        )

    def test_multiple_files_list_flag_duplicates_suppressed(self, mock_file, mock_open):
        # a file with many matches should appear only once with -l
        result = grep("the", "-l -i", ["iliad.txt", "paradise-lost.txt"])
        self.assertEqual(result.count("iliad.txt"), 1)
        self.assertEqual(result.count("paradise-lost.txt"), 1)

    def test_number_and_list_flags(self, mock_file, mock_open):
        self.assertEqual(grep("Agamemnon", "-n -l", ["iliad.txt"]), "iliad.txt\n")

    def test_all_flags(self, mock_file, mock_open):
        result = grep("Agamemnon", "-n -i -v -x -l", ["iliad.txt"])
        # line "Of Atreus..." matches case-insensitively entirely -> inverted removes it
        self.assertNotIn("Of Atreus, Agamemnon, King of men.", result)
        self.assertEqual(result, "iliad.txt\n")
