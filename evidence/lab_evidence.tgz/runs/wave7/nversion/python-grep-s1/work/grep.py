def grep(pattern, flags, files):
    case_insensitive = "-i" in flags
    invert = "-v" in flags
    entire_line = "-x" in flags
    line_numbers = "-n" in flags
    names_only = "-l" in flags

    if case_insensitive:
        pattern = pattern.lower()

    output = []
    matching_files = []

    for filename in files:
        file_output = []

        with open(filename, "r", encoding="utf-8") as file:
            for line_number, raw_line in enumerate(file, start=1):
                line = raw_line.rstrip("\n")
                compare_line = line.lower() if case_insensitive else line

                if entire_line:
                    matches = compare_line == pattern
                else:
                    matches = pattern in compare_line

                if invert:
                    matches = not matches

                if not matches:
                    continue

                if names_only:
                    file_output.append(filename)
                    continue

                prefix = ""
                if len(files) > 1:
                    prefix += filename + ":"
                if line_numbers:
                    prefix += str(line_number) + ":"

                file_output.append(prefix + line)

        if file_output:
            matching_files.append(filename)
            output.extend(file_output)

    if names_only:
        return "".join(filename + "\n" for filename in matching_files)

    return "".join(line + "\n" for line in output)
