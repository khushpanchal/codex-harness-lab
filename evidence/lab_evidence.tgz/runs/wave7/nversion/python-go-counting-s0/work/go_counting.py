
WHITE = "W"
BLACK = "B"
NONE = ""
EMPTY = " "


class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        self.board = board
        self.rows = len(board)
        self.columns = len(board[0]) if board else 0

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not (0 <= x < self.columns and 0 <= y < self.rows):
            raise ValueError("Invalid coordinate")

        if self.board[y][x] in (WHITE, BLACK):
            return NONE, set()

        owner = None
        region = set()
        pending = [(x, y)]

        while pending:
            point = pending.pop()
            if point in region:
                continue
            region.add(point)
            point_x, point_y = point

            for neighbor in self._neighbors(point_x, point_y):
                stone = self.board[neighbor[1]][neighbor[0]]
                if stone == EMPTY:
                    pending.append(neighbor)
                elif owner is None:
                    owner = stone
                elif owner != stone:
                    owner = NONE

        return owner or NONE, region

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        result = {WHITE: set(), BLACK: set(), NONE: set()}
        seen = set()

        for y in range(self.rows):
            for x in range(self.columns):
                if self.board[y][x] != EMPTY or (x, y) in seen:
                    continue
                owner, region = self.territory(x, y)
                seen.update(region)
                result[owner].update(region)

        return result

    def _neighbors(self, x, y):
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.columns and 0 <= ny < self.rows:
                yield nx, ny
