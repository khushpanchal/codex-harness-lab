# test_blind_spec.py
import unittest

from go_counting import Board, WHITE, BLACK, NONE


class GoCountingTest(unittest.TestCase):
    def test_black_corner_territory_on_5x5_board(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        stone, territory = board.territory(x=0, y=1)
        self.assertEqual(stone, BLACK)
        self.assertSetEqual(territory, {(0, 0), (0, 1), (1, 0)})

    def test_white_center_territory_on_5x5_board(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        stone, territory = board.territory(x=2, y=3)
        self.assertEqual(stone, WHITE)
        self.assertSetEqual(territory, {(2, 3)})

    def test_open_corner_territory_on_5x5_board(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        stone, territory = board.territory(x=1, y=4)
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, {(0, 3), (0, 4), (1, 3), (1, 4), (2, 2), (2, 3), (2, 4), (3, 2), (3, 3), (3, 4), (4, 2), (4, 3), (4, 4)})

    def test_a_box_and_no_territory_on_1x5_board(self):
        board = Board(["B", "B", "B", "B"])
        stone, territory = board.territory(x=0, y=0)
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, set())

    def test_invalid_x_coordinate(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        with self.assertRaises(ValueError) as ctx:
            board.territory(x=-1, y=1)
        self.assertTrue(str(ctx.exception))

    def test_invalid_y_coordinate(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        with self.assertRaises(ValueError) as ctx:
            board.territory(x=1, y=5)
        self.assertTrue(str(ctx.exception))

    def test_one_territory_is_the_whole_board(self):
        board = Board([" "])
        territories = board.territories()
        self.assertSetEqual(territories[NONE], {(0, 0)})
        self.assertSetEqual(territories[BLACK], set())
        self.assertSetEqual(territories[WHITE], set())

    def test_two_territories_rectangular_board(self):
        board = Board([" BW ", " BW "])
        territories = board.territories()
        self.assertSetEqual(territories[NONE], set())
        self.assertSetEqual(territories[BLACK], {(0, 0), (0, 1)})
        self.assertSetEqual(territories[WHITE], {(2, 0), (2, 1), (3, 0), (3, 1)})

    def test_two_regioned_board_non_cardinal_neighbors_ignored(self):
        board = Board(["B "])
        territories = board.territories()
        self.assertSetEqual(territories[BLACK], set())
        self.assertSetEqual(territories[WHITE], set())
        self.assertSetEqual(territories[NONE], {(1, 0)})

    def test_territories_of_complex_board(self):
        board = Board(
            [
                "B W  B",
                " B W B",
                "B W WB",
                "W W WB",
                "W   WB",
                "W  W WB",
            ][:6]
        )
        # rows padded to consistent length (7 wide? use original canonical data instead)
        board = Board(
            [
                "B W  B ",
                " B W B ",
                "B W WB ",
                "W W WB ",
                "W   WB ",
                "W  W WB",
            ][:6]
        )
        territories = board.territories()
        self.assertSetEqual(territories[NONE], set())
        self.assertSetEqual(
            territories[BLACK],
            {(0, 0), (0, 1), (0, 2), (1, 1), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0)},
        )
        self.assertSetEqual(
            territories[WHITE],
            {
                (0, 3),
                (0, 4),
                (0, 5),
                (1, 3),
                (1, 4),
                (1, 5),
                (2, 2),
                (2, 3),
                (2, 4),
                (2, 5),
                (3, 1),
                (3, 2),
                (4, 2),
                (5, 1),
                (5, 2),
                (6, 2),
            },
        )

    def test_territory_of_coordinate_containing_a_stone_is_empty(self):
        board = Board(["B "])
        stone, territory = board.territory(x=0, y=0)
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, set())

    def test_territory_of_coordinate_on_upper_right_corner(self):
        board = Board([" BB", "B  ", "   "])
        stone, territory = board.territory(x=2, y=0)
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, {(1, 1), (2, 0), (1, 2), (2, 1), (2, 2)})


if __name__ == "__main__":
    unittest.main()
