
WHITE = 'W'
BLACK = 'B'
NONE = ''


class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        self.board = board
        self.height = len(board)
        self.width = max((len(row) for row in board), default=0)

        if any(len(row) != self.width for row in board):
            raise ValueError('All rows of the board must have the same length')

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not isinstance(x, int) or not isinstance(y, int):
            raise ValueError('Invalid coordinate')

        if x < 0 or y < 0 or x >= self.width or y >= self.height:
            raise ValueError('Invalid coordinate')

        to_visit = [(x, y)]
        visited = {(x, y)}
        owners = set()
        territory = {(x, y)}

        while to_visit:
            current_x, current_y = to_visit.pop()

            for neighbor_x, neighbor_y in self._neighbors(current_x, current_y):
                point = self.board[neighbor_y][neighbor_x]

                if point in (BLACK, WHITE):
                    owners.add(point)
                elif (neighbor_x, neighbor_y) not in visited:
                    visited.add((neighbor_x, neighbor_y))
                    territory.add((neighbor_x, neighbor_y))
                    to_visit.append((neighbor_x, neighbor_y))

        if len(owners) == 1:
            return owners.pop(), territory

        return NONE, territory

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        result = {
            BLACK: set(),
            WHITE: set(),
            NONE: set(),
        }

        for y in range(self.height):
            for x in range(self.width):
                if self.board[y][x] not in (BLACK, WHITE):
                    owner, territory = self.territory(x, y)
                    result[owner].update(territory)

        return result

    def _neighbors(self, x, y):
        candidates = ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1))

        return (
            (neighbor_x, neighbor_y)
            for neighbor_x, neighbor_y in candidates
            if 0 <= neighbor_x < self.width and 0 <= neighbor_y < self.height
        )
