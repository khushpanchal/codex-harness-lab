# test_blind_spec.py
import unittest

from go_counting import Board, WHITE, BLACK, NONE


class TerritoryTests(unittest.TestCase):
    def test_black_corner_territory_on_5x5_board(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        stone, territory = board.territory(x=0, y=1)
        self.assertEqual(stone, BLACK)
        self.assertSetEqual(territory, {(0, 0), (0, 1), (1, 0)})

    def test_white_territory_in_middle_of_board(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        stone, territory = board.territory(x=2, y=3)
        self.assertEqual(stone, WHITE)
        self.assertSetEqual(territory, {(1, 4), (2, 4), (1, 3)})

    def test_open_territory(self):
        board = Board(["      ", "      ", "  W  B", "      ", "      "])
        stone, territory = board.territory(x=3, y=2)
        self.assertEqual(stone, "")
        self.assertSetEqual(
            territory,
            {(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0),
             (0, 1), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1),
             (0, 2), (1, 2), (2, 2),
             (0, 3), (1, 3), (2, 3), (3, 3), (4, 3), (5, 3),
             (0, 4), (1, 4), (2, 4), (3, 4), (4, 4), (5, 4)},
        )

    def test_a_stone_and_open_territory_interior(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        stone, territory = board.territory(x=1, y=4)
        self.assertEqual(stone, WHITE)
        self.assertSetEqual(territory, {(1, 4), (2, 4), (1, 3)})

    def test_two_territories_separated_by_one_stone(self):
        board = Board(["B W B ", " B B W"])
        stone, territory = board.territory(x=1, y=0)
        self.assertEqual(stone, BLACK)
        self.assertSetEqual(territory, {(1, 0)})

    def test_invalid_x(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        with self.assertRaises(ValueError):
            board.territory(x=-1, y=1)

    def test_invalid_y(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        with self.assertRaises(ValueError):
            board.territory(x=1, y=5)

    def test_invalid_coordinate_out_of_range_high(self):
        board = Board(["B"])
        with self.assertRaises(ValueError):
            board.territory(x=1, y=0)

    def test_invalid_coordinate_out_of_range_low(self):
        board = Board(["B"])
        with self.assertRaises(ValueError):
            board.territory(x=-1, y=0)

    def test_invalid_coordinate_raises_with_message(self):
        board = Board(["B"])
        with self.assertRaises(ValueError) as cm:
            board.territory(x=1, y=0)
        self.assertTrue(str(cm.exception))

    def test_stone_coordinate_has_no_territory(self):
        board = Board(["BW"])
        stone, territory = board.territory(x=0, y=0)
        self.assertEqual(stone, "")
        self.assertSetEqual(territory, set())

    def test_territory_of_stone_cell_belongs_to_nobody(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        stone, territory = board.territory(x=2, y=2)
        self.assertEqual(stone, "")
        self.assertSetEqual(territory, set())


class TerritoriesTests(unittest.TestCase):
    def test_territories_of_5x5_board(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        result = board.territories()
        self.assertEqual(
            result,
            {
                BLACK: {(0, 0), (0, 1), (1, 0)},
                WHITE: {(1, 3), (1, 4), (2, 4)},
                NONE: set(),
            },
        )

    def test_all_open_territories_of_board(self):
        board = Board(["      ", "      ", "  W  B", "      ", "      "])
        result = board.territories()
        self.assertEqual(
            result,
            {
                BLACK: {(5, 3), (5, 4), (5, 1), (5, 0), (5, 2)},
                WHITE: {(2, 2)},
                NONE: {
                    (0, 0), (1, 0), (2, 0), (3, 0), (4, 0),
                    (0, 1), (1, 1), (2, 1), (3, 1), (4, 1),
                    (0, 2), (1, 2),
                    (0, 3), (1, 3), (2, 3), (3, 3), (4, 3),
                    (0, 4), (1, 4), (2, 4), (3, 4), (4, 4),
                },
            },
        )

    def test_territories_of_single_column_board(self):
        board = Board(["B", "W"])
        result = board.territories()
        self.assertEqual(result, {BLACK: set(), WHITE: set(), NONE: set()})

    def test_territories_full_of_stones(self):
        board = Board(["BB", "WW"])
        result = board.territories()
        self.assertEqual(
            result, {BLACK: set(), WHITE: set(), NONE: set()}
        )

    def test_owner_constants(self):
        self.assertEqual(BLACK, "B")
        self.assertEqual(WHITE, "W")
        self.assertEqual(NONE, "")


if __name__ == "__main__":
    unittest.main()
