class School:
    def __init__(self):
        self.students = {}

    def add_student(self, name, grade):
        if name in self.students:
            return False

        self.students[name] = grade
        return True

    def roster(self):
        return sorted(
            (name for name in self.students),
            key=lambda name: (self.students[name], name),
        )

    def grade(self, grade_number):
        return sorted(
            name for name, grade in self.students.items() if grade == grade_number
        )

    def added(self):
        return self.students
