import unittest

from grade_school import School


class GradeSchoolTest(unittest.TestCase):
    def test_roster_is_empty_when_no_student_is_added(self):
        school = School()
        self.assertEqual(school.roster(), [])

    def test_add_student(self):
        school = School()
        school.add_student("Aimee", 2)
        self.assertEqual(school.roster(), ["Aimee"])

    def test_add_students_in_same_grade_sorted_alphabetically(self):
        school = School()
        school.add_student("Blair", 2)
        school.add_student("James", 2)
        school.add_student("Paul", 2)
        self.assertEqual(school.grade(2), ["Blair", "James", "Paul"])

    def test_grade_list_is_empty_when_no_students_in_that_grade(self):
        school = School()
        self.assertEqual(school.grade(1), [])

    def test_student_in_multiple_grades_appear_in_grade_roster(self):
        school = School()
        school.add_student("Franklin", 5)
        school.add_student("Bradley", 5)
        school.add_student("Jeff", 1)
        self.assertEqual(school.grade(5), ["Bradley", "Franklin"])
        self.assertEqual(school.grade(1), ["Jeff"])

    def test_student_not_added_to_same_grade_more_than_once(self):
        school = School()
        school.add_student("Blair", 2)
        school.add_student("James", 2)
        school.add_student("James", 2)
        school.add_student("Paul", 2)
        self.assertEqual(school.grade(2), ["Blair", "James", "Paul"])

    def test_student_not_added_to_other_grade_more_than_once(self):
        school = School()
        school.add_student("Blair", 2)
        school.add_student("James", 2)
        school.add_student("James", 3)
        school.add_student("Paul", 3)
        self.assertEqual(school.grade(2), ["Blair", "James"])
        self.assertEqual(school.grade(3), ["Paul"])

    def test_student_not_added_to_multiple_grades_in_roster(self):
        school = School()
        school.add_student("Blair", 2)
        school.add_student("James", 2)
        school.add_student("James", 3)
        school.add_student("Paul", 3)
        self.assertEqual(
            school.roster(), ["Blair", "James", "Paul"]
        )

    def test_roster_is_sorted_by_grade_then_name(self):
        school = School()
        school.add_student("Peter", 2)
        school.add_student("Anna", 1)
        school.add_student("Barb", 1)
        school.add_student("Charlie", 1)
        school.add_student("Alex", 2)
        school.add_student("Jim", 5)
        school.add_student("Zoe", 2)
        expected = [
            "Anna",
            "Barb",
            "Charlie",
            "Alex",
            "Peter",
            "Zoe",
            "Jim",
        ]
        self.assertEqual(school.roster(), expected)

    def test_adding_a_student_is_indicated_as_successful(self):
        school = School()
        result = school.add_student("Aimee", 2)
        self.assertTrue(result)

    def test_adding_same_student_to_same_grade_is_indicated_as_failure(self):
        school = School()
        school.add_student("Aimee", 2)
        result = school.add_student("Aimee", 2)
        self.assertFalse(result)

    def test_adding_same_student_to_different_grade_is_indicated_as_failure(self):
        school = School()
        school.add_student("Aimee", 2)
        result = school.add_student("Aimee", 3)
        self.assertFalse(result)

    def test_grade_method_returns_copy_not_internal_state(self):
        school = School()
        school.add_student("Aimee", 2)
        result = school.grade(2)
        if isinstance(result, list):
            result.append("Oops")
            self.assertEqual(school.grade(2), ["Aimee"])

    def test_roster_method_returns_copy_not_internal_state(self):
        school = School()
        school.add_student("Aimee", 2)
        result = school.roster()
        if isinstance(result, list):
            result.append("Oops")
            self.assertEqual(school.roster(), ["Aimee"])

    def test_roster_works_after_rejected_duplicate_add(self):
        school = School()
        school.add_student("Aimee", 2)
        school.add_student("Aimee", 2)
        self.assertEqual(school.roster(), ["Aimee"])

    def test_grade_empty_for_grade_never_used_even_after_other_grades(self):
        school = School()
        school.add_student("Aimee", 2)
        school.add_student("Jim", 5)
        self.assertEqual(school.grade(3), [])

    def test_single_student_roster_sorted(self):
        school = School()
        school.add_student("Zoe", 3)
        self.assertEqual(school.roster(), ["Zoe"])


if __name__ == "__main__":
    unittest.main()
