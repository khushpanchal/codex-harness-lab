import unittest

from poker import best_hands


class PokerTest(unittest.TestCase):
    # --- basic ---
    def test_single_hand_always_wins(self):
        self.assertEqual(best_hands(["4S 5S 7H 8D JC"]), ["4S 5S 7H 8D JC"])

    # --- high card ---
    def test_highest_card_wins(self):
        self.assertEqual(
            best_hands(["4D 5S 6S 8D 3C", "2S 4C 7S 9H 10H", "3S 4S 5D 6H JH"]),
            ["3S 4S 5D 6H JH"],
        )

    def test_high_card_tie_multiple_winners(self):
        self.assertEqual(
            best_hands(["4D 5S 6S 8D 3C", "2S 4C 7S 9H 10H", "3S 4S 5D 6H JH", "3H 4H 5C 6C JD"]),
            ["3S 4S 5D 6H JH", "3H 4H 5C 6C JD"],
        )

    # --- one pair ---
    def test_one_pair_beats_high_card(self):
        self.assertEqual(
            best_hands(["4S 5H 6C 8D KH", "2S 4H 6C 8D 4H"]),
            ["2S 4H 6C 8D 4H"],
        )

    def test_highest_pair_wins(self):
        self.assertEqual(
            best_hands(["4S 2H 6S 2D KQ".replace("Q", "H"), "2S 4H 6C 8D 4H"]),
            ["4S 2H 6S 2D KH"],
        )

    def test_equal_pairs_tie_kicker(self):
        self.assertEqual(
            best_hands(["4S 5H 4C 8D KH", "4S 5H 4C 7D KH"]),
            ["4S 5H 4C 8D KH"],
        )

    def test_equal_pairs_tied(self):
        self.assertEqual(
            best_hands(["4S 5H 4C 8D KH", "4H 5S 4D 8C KS"]),
            ["4S 5H 4C 8D KH", "4H 5S 4D 8C KS"],
        )

    def test_kicker_order_matters(self):
        self.assertEqual(
            best_hands(["4S 5H 4C 8D KH", "4S 5H 4C 7D KH"]),
            ["4S 5H 4C 8D KH"],
        )

    # --- two pair ---
    def test_two_pair_beats_one_pair(self):
        self.assertEqual(
            best_hands(["4S 2H 6S 2D KQ".replace("Q", "H"), "2S 4H 6C 4D KD"]),
            ["2S 4H 6C 4D KD"],
        )

    def test_two_pair_first_rank_wins(self):
        self.assertEqual(
            best_hands(["2S 2H 6S 6D KH", "4S 4H 3S 3D KH"]),
            ["4S 4H 3S 3D KH"],
        )

    def test_two_pair_second_rank_wins(self):
        self.assertEqual(
            best_hands(["2S 2H 4S 4D KH", "2S 2H 6S 6D KH"]),
            ["2S 2H 6S 6D KH"],
        )

    def test_two_pair_equal_kicker_wins(self):
        self.assertEqual(
            best_hands(["2S AH 2S AD 4H".replace("H", "C"), "2S AH 4S AD 2C"]),  # placeholder
            ["2S AC 2H AD 4C"],
        )

    def test_two_pair_kicker(self):
        self.assertEqual(
            best_hands(["2S 2H 4S 4D KH", "2S 2H 4S 4D AS"]),
            ["2S 2H 4S 4D AS"],
        )

    # --- three of a kind ---
    def test_three_of_a_kind_beats_two_pair(self):
        self.assertEqual(
            best_hands(["2S 2H 4S 4D 3S", "2S 2H 2D 4D 5S"]),
            ["2S 2H 2D 4D 5S"],
        )

    def test_higher_three_of_a_kind_wins(self):
        self.assertEqual(
            best_hands(["2S 2H 2D 4D 5S", "3S 3H 3D 4D 5S"]),
            ["3S 3H 3D 4D 5S"],
        )

    def test_lower_three_of_a_kind_loses(self):
        self.assertEqual(
            best_hands(["2S 2H 2D 4D 5S", "3S 3H 3D 4D 5S"]),
            ["3S 3H 3D 4D 5S"],
        )

    # --- straight ---
    def test_straight_beats_three_of_a_kind(self):
        self.assertEqual(
            best_hands(["4S 5H 4C 8D 4H", "3S 4D 5S 6H 7C"]),
            ["3S 4D 5S 6H 7C"],
        )

    def test_ace_low_straight(self):
        self.assertEqual(
            best_hands(["4S 6H KS 8D 2C", "4S AH 3S 2D 5H"]),
            ["4S AH 3S 2D 5H"],
        )

    def test_ace_high_straight(self):
        self.assertEqual(
            best_hands(["4S 6H KS 8D 2C", "10S QH JS KD AH"]),
            ["10S QH JS KD AH"],
        )

    def test_higher_straight_wins(self):
        self.assertEqual(
            best_hands(["4S 6H 7S 8D 5H", "5S 7H 8S 9D 6H"]),
            ["5S 7H 8S 9D 6H"],
        )

    def test_ace_low_straight_beats_high_card(self):
        self.assertEqual(
            best_hands(["4S 6H KS 8D 2C", "4S AH 3S 2D 5H"]),
            ["4S AH 3S 2D 5H"],
        )

    # --- flush ---
    def test_flush_beats_straight(self):
        self.assertEqual(
            best_hands(["4C 6H 7D 8D 5H", "2S 4S 5S 6S 7S"]),
            ["2S 4S 5S 6S 7S"],
        )

    def test_higher_flush_wins(self):
        self.assertEqual(
            best_hands(["4H 6H 7H 8H 5H", "2S 4S 5S 6S 7S"]),
            ["4H 6H 7H 8H 5H"],
        )

    def test_flush_tie(self):
        self.assertEqual(
            best_hands(["2H 4H 6H 8H AH", "2S 4S 6S 8S AS"]),
            ["2H 4H 6H 8H AH", "2S 4S 6S 8S AS"],
        )

    # --- full house ---
    def test_full_house_beats_flush(self):
        self.assertEqual(
            best_hands(["3S 4S 5S 6S 7S", "2S 2H 2D 4D 4S"]),
            ["2S 2H 2D 4D 4S"],
        )

    def test_full_house_rank_wins(self):
        self.assertEqual(
            best_hands(["5H 5C 5S 2H 2D", "4H 4C 4S AH AD"]),
            ["5H 5C 5S 2H 2D"],
        )

    def test_full_house_secondary_rank_wins(self):
        self.assertEqual(
            best_hands(["4H 4C 4S AH AD", "4H 4C 4S KH KD"]),
            ["4H 4C 4S AH AD"],
        )

    # --- four of a kind ---
    def test_four_of_a_kind_beats_full_house(self):
        self.assertEqual(
            best_hands(["2S 2H 2D 4D 4S", "2S 2H 2C 2D 5S"]),
            ["2S 2H 2C 2D 5S"],
        )

    def test_higher_four_of_a_kind_wins(self):
        self.assertEqual(
            best_hands(["2S 2H 2C 2D 5S", "3S 3H 3C 3D 5S"]),
            ["3S 3H 3C 3D 5S"],
        )

    # --- straight flush ---
    def test_straight_flush_beats_four_of_a_kind(self):
        self.assertEqual(
            best_hands(["2S 2H 2C 2D 5S", "3S 4S 5S 6S 7S"]),
            ["3S 4S 5S 6S 7S"],
        )

    def test_higher_straight_flush_wins(self):
        self.assertEqual(
            best_hands(["4S 5S 6S 7S 8S", "3S 4S 5S 6S 7S"]),
            ["4S 5S 6S 7S 8S"],
        )

    def test_ace_high_straight_flush(self):
        self.assertEqual(
            best_hands(["4S 5S 6S 7S 8S", "9S TS JS QS KS"]),
            ["9S TS JS QS KS"],
        )

    def test_ace_low_straight_flush(self):
        self.assertEqual(
            best_hands(["9S TS JS QS KS", "AS 2S 3S 4S 5S"]),
            ["9S TS JS QS KS"],
        )

    def test_royal_flush(self):
        self.assertEqual(
            best_hands(["TS JS QS KS AS", "9S TS JS QS KS"]),
            ["TS JS QS KS AS"],
        )

    # --- misc / multiple winners ---
    def test_even_more_hands(self):
        self.assertEqual(
            best_hands(
                [
                    "3S 8S 9S 5S KS",
                    "3D 8D 9D 5D KD",
                    "3C 8C 9C 5C KC",
                    "3H 8H 9H 5H KH",
                ]
            ),
            [
                "3S 8S 9S 5S KS",
                "3D 8D 9D 5D KD",
                "3C 8C 9C 5C KC",
                "3H 8H 9H 5H KH",
            ],
        )

    def test_ties_return_all(self):
        self.assertEqual(
            best_hands(["JH 2D 9H 3C 4D", "JD 2C 9S 3H 4C", "JS 2H 9D 3S 4H"]),
            ["JH 2D 9H 3C 4D", "JD 2C 9S 3H 4C", "JS 2H 9D 3S 4H"],
        )


if __name__ == "__main__":
    unittest.main()
