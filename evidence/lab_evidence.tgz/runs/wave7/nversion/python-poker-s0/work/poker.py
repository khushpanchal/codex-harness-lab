def best_hands(hands):
    """Return every hand tied for the best poker ranking."""
    rankings = [(rank_hand(hand), hand) for hand in hands]
    best_rank = max(rank for rank, _ in rankings)
    return [hand for rank, hand in rankings if rank == best_rank]


def rank_hand(hand):
    """Turn a five-card hand into a comparable ranking tuple."""
    cards = hand.split()
    values = sorted((card_value(card[:-1]) for card in cards), reverse=True)
    suits = {card[-1] for card in cards}
    groups = []
    for value in values:
        if not groups or groups[-1][0] != value:
            groups.append((value, 1))
        else:
            groups[-1] = (value, groups[-1][1] + 1)
    groups.sort(key=lambda group: (group[1], group[0]), reverse=True)

    straight_high = straight_high_card(values)
    flush = len(suits) == 1

    if straight_high and flush:
        category = 8
    elif groups[0][1] == 4:
        category = 7
    elif groups[0][1] == 3 and groups[1][1] == 2:
        category = 6
    elif flush:
        category = 5
    elif straight_high:
        category = 4
    elif groups[0][1] == 3:
        category = 3
    elif groups[0][1] == 2 and groups[1][1] == 2:
        category = 2
    elif groups[0][1] == 2:
        category = 1
    else:
        category = 0

    if category == 8:
        return (category, straight_high)
    if category == 4:
        return (category, straight_high)
    if category == 5:
        return (category, *values)
    tie_breakers = (category, *(value for value, _ in groups))
    if category in (1, 2, 3, 6, 7):
        # Kickers are not represented by grouped ranks, so retain all card
        # values while preserving multiplicity ordering.
        ordered = sorted(
            values,
            key=lambda value: next(
                index for index, (group_value, _) in enumerate(groups)
                if group_value == value
            ),
        )
        tie_breakers = (category, *ordered)
    return tie_breakers


def card_value(label):
    face_values = {"T": 10, "J": 11, "Q": 12, "K": 13, "A": 14}
    return face_values[label] if label in face_values else int(label)


def straight_high_card(values):
    if values == [14, 5, 4, 3, 2]:
        return 5
    if all(values[index] - values[index + 1] == 1 for index in range(4)):
        return values[0]
    return None
