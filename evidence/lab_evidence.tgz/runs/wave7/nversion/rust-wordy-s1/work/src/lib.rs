#[derive(Clone, Copy)]
enum Operation {
    Add,
    Subtract,
    Multiply,
    Divide,
    #[cfg(feature = "exponentials")]
    Exponentiate,
}

fn parse_number(word: &str) -> Option<i128> {
    word.parse().ok()
}

fn parse_exponent(word: &str) -> Option<i128> {
    let digits = word
        .chars()
        .take_while(|character| character.is_ascii_digit())
        .collect::<String>();
    if digits.is_empty() {
        return None;
    }
    digits.parse().ok()
}

fn parse_operation(words: &[&str]) -> Option<Operation> {
    match words {
        ["plus"] => Some(Operation::Add),
        ["minus"] => Some(Operation::Subtract),
        ["multiplied", "by"] => Some(Operation::Multiply),
        ["divided", "by"] => Some(Operation::Divide),
        #[cfg(feature = "exponentials")]
        ["raised", "to", "the", ..] => Some(Operation::Exponentiate),
        _ => None,
    }
}

fn exponentiate(base: i128, exponent: i128) -> Option<i128> {
    (0..exponent).try_fold(1_i128, |result, _| result.checked_mul(base))
}

pub fn answer(command: &str) -> Option<i32> {
    let question = command.strip_prefix("What is ")?.strip_suffix('?')?;
    if question.is_empty() {
        return None;
    }

    let mut words = question.split_whitespace().peekable();
    let mut result = parse_number(words.next()?)?;

    while words.peek().is_some() {
        let length = match words.peek() {
            Some(&"multiplied") | Some(&"divided") => 2,
            #[cfg(feature = "exponentials")]
            Some(&"raised") => 4,
            _ => 1,
        };
        let operation_words: Vec<_> = words.by_ref().take(length).collect();
        let operation = parse_operation(&operation_words)?;

        let value = if cfg!(feature = "exponentials")
            && operation_words == ["raised", "to", "the"]
            && words.peek().is_some_and(|word| {
                word.chars()
                    .all(|character| character.is_ascii_alphanumeric())
            }) {
            words.by_ref().next()?;
            parse_exponent(operation_words[2])?
        } else {
            parse_number(words.next()?)?
        };
        result = match operation {
            Operation::Add => result.checked_add(value),
            Operation::Subtract => result.checked_sub(value),
            Operation::Multiply => result.checked_mul(value),
            Operation::Divide if value != 0 => Some(result / value),
            Operation::Divide => None,
            #[cfg(feature = "exponentials")]
            Operation::Exponentiate => exponentiate(result, value),
        }?;
    }

    i32::try_from(result).ok()
}
