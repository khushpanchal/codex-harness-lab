pub fn answer(command: &str) -> Option<i32> {
    let expression = command.strip_prefix("What is ")?.strip_suffix('?')?;
    let words: Vec<&str> = expression.split_whitespace().collect();
    let mut parser = Parser { words, position: 0 };
    let mut result = parser.number()?;

    while !parser.finished() {
        let operation = parser.operation()?;
        let right = parser.number()?;
        result = apply(result, operation, right)?;
    }

    Some(result)
}

#[derive(Clone, Copy)]
enum Operation {
    Add,
    Subtract,
    Multiply,
    Divide,
}

struct Parser<'a> {
    words: Vec<&'a str>,
    position: usize,
}

impl<'a> Parser<'a> {
    fn finished(&self) -> bool {
        self.position == self.words.len()
    }

    fn number(&mut self) -> Option<i32> {
        let word = *self.words.get(self.position)?;
        self.position += 1;
        let number = parse_integer(word)?;

        #[cfg(feature = "exponentials")]
        {
            return self
                .exponent()
                .map_or(Some(number), |exponent| checked_pow(number, exponent));
        }

        #[cfg(not(feature = "exponentials"))]
        Some(number)
    }

    #[cfg(feature = "exponentials")]
    fn exponent(&mut self) -> Option<i32> {
        match self.words.get(self.position) {
            Some(&"squared") => {
                self.position += 1;
                Some(2)
            }
            Some(&"cubed") => {
                self.position += 1;
                Some(3)
            }
            Some(&"to" | &"raised") => {
                if self.words.get(self.position) == Some(&"raised") {
                    self.position += 1;
                }
                if self.words.get(self.position) != Some(&"to") {
                    return None;
                }
                self.position += 1;
                if self.words.get(self.position) != Some(&"the") {
                    return None;
                }
                self.position += 1;

                let exponent = match self.words.get(self.position) {
                    Some(&"power") => {
                        self.position += 1;
                        if self.words.get(self.position) != Some(&"of") {
                            return None;
                        }
                        self.position += 1;
                        let exponent: i32 = self.words.get(self.position)?.parse().ok()?;
                        self.position += 1;
                        exponent
                    }
                    Some(ordinal) => {
                        let (exponent, suffix) = split_ordinal(ordinal)?;
                        self.position += 1;
                        if self.words.get(self.position) != Some(&"power") || !suffix.is_empty() {
                            return None;
                        }
                        self.position += 1;
                        exponent.parse::<i32>().ok()?
                    }
                    _ => return None,
                };
                Some(exponent)
            }
            _ => None,
        }
    }

    fn operation(&mut self) -> Option<Operation> {
        let word = self.words.get(self.position)?;
        self.position += 1;
        match *word {
            "plus" => Some(Operation::Add),
            "minus" => Some(Operation::Subtract),
            "multiplied" => {
                if self.words.get(self.position) != Some(&"by") {
                    return None;
                }
                self.position += 1;
                Some(Operation::Multiply)
            }
            "divided" => {
                if self.words.get(self.position) != Some(&"by") {
                    return None;
                }
                self.position += 1;
                Some(Operation::Divide)
            }
            _ => None,
        }
    }
}

#[cfg(feature = "exponentials")]
fn split_ordinal(word: &str) -> Option<(&str, &str)> {
    let split = word.find(|character: char| !character.is_ascii_digit())?;
    let (number, suffix) = word.split_at(split);
    if number.is_empty() || !matches!(suffix, "st" | "nd" | "rd" | "th") {
        return None;
    }
    Some((number, suffix))
}

fn parse_integer(word: &str) -> Option<i32> {
    let digits = word.strip_prefix('-').unwrap_or(word);
    if digits.is_empty() || !digits.bytes().all(|byte| byte.is_ascii_digit()) {
        return None;
    }
    word.parse().ok()
}

#[cfg(feature = "exponentials")]
fn checked_pow(base: i32, exponent: i32) -> Option<i32> {
    if exponent < 0 {
        return None;
    }
    let mut result: i32 = 1;
    for _ in 0..exponent {
        result = result.checked_mul(base)?;
    }
    Some(result)
}

fn apply(left: i32, operation: Operation, right: i32) -> Option<i32> {
    match operation {
        Operation::Add => left.checked_add(right),
        Operation::Subtract => left.checked_sub(right),
        Operation::Multiply => left.checked_mul(right),
        Operation::Divide => left.checked_div(right),
    }
}
