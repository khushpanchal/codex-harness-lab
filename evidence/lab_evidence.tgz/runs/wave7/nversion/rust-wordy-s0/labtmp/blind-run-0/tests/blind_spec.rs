use wordy::*;

#[test]
fn just_a_number() {
    assert_eq!(answer("What is 5?"), Some(5));
}

#[test]
fn just_another_number() {
    assert_eq!(answer("What is 1234?"), Some(1234));
}

#[test]
fn large_number() {
    assert_eq!(answer("What is 1234567?"), Some(1234567));
}

#[test]
fn negative_number() {
    assert_eq!(answer("What is -5?"), Some(-5));
}

#[test]
fn addition() {
    assert_eq!(answer("What is 5 plus 13?"), Some(18));
}

#[test]
fn addition_with_negatives() {
    assert_eq!(answer("What is -1 plus -10?"), Some(-11));
}

#[test]
fn addition_large_numbers() {
    assert_eq!(answer("What is 1000000 plus 2000000?"), Some(3000000));
}

#[test]
fn subtraction() {
    assert_eq!(answer("What is 7 minus 5?"), Some(2));
}

#[test]
fn subtraction_resulting_negative() {
    assert_eq!(answer("What is 5 minus 7?"), Some(-2));
}

#[test]
fn multiplication() {
    assert_eq!(answer("What is 6 multiplied by 4?"), Some(24));
}

#[test]
fn division() {
    assert_eq!(answer("What is 25 divided by 5?"), Some(5));
}

#[test]
fn division_with_negatives() {
    assert_eq!(answer("What is -10 divided by 2?"), Some(-5));
}

#[test]
fn multiple_additions() {
    assert_eq!(answer("What is 5 plus 13 plus 6?"), Some(24));
}

#[test]
fn left_to_right_beats_precedence() {
    assert_eq!(answer("What is 3 plus 2 multiplied by 3?"), Some(15));
}

#[test]
fn mixed_operations() {
    assert_eq!(answer("What is 1 plus 2 minus 3?"), Some(0));
}

#[test]
fn multiple_mixed_operations() {
    assert_eq!(answer("What is 17 minus 6 plus 3?"), Some(14));
}

#[test]
fn division_in_sequence() {
    assert_eq!(answer("What is 100 divided by 5 divided by 2?"), Some(10));
}

#[test]
fn unsupported_operation_cubed() {
    assert_eq!(answer("What is 52 cubed?"), None);
}

#[test]
fn non_math_question() {
    assert_eq!(
        answer("Who is the President of the United States"),
        None
    );
}

#[test]
fn invalid_syntax_double_operator() {
    assert_eq!(answer("What is 1 plus plus 2?"), None);
}

#[test]
fn invalid_syntax_missing_number() {
    assert_eq!(answer("What is 1 plus?"), None);
}

#[test]
fn invalid_syntax_trailing_operator() {
    assert_eq!(answer("What is 5 times?"), None);
}

#[test]
fn unknown_word() {
    assert_eq!(answer("What is 4 plus 5 banana?"), None);
}

#[test]
fn empty_input() {
    assert_eq!(answer(""), None);
}

#[test]
fn no_question() {
    assert_eq!(answer("What is?"), None);
}
