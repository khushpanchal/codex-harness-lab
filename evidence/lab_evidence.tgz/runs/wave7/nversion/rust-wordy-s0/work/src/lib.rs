pub fn answer(command: &str) -> Option<i32> {
    let body = command.strip_prefix("What is ")?.strip_suffix("?")?;
    if body.is_empty() {
        return None;
    }

    let mut tokens = body.split_whitespace();
    let mut value = parse_number(tokens.next()?)?;
    let Some(mut operator) = tokens.next() else {
        return Some(value);
    };

    loop {
        let operand = match operator {
            "plus" | "minus" => parse_number(tokens.next()?)?,
            "multiplied" | "divided" => {
                if tokens.next()? != "by" {
                    return None;
                }
                parse_number(tokens.next()?)?
            }
            #[cfg(feature = "exponentials")]
            "raised" => {
                if tokens.next()? != "to" || tokens.next()? != "the" || tokens.next()? != "power" {
                    return None;
                }
                let exponent = parse_exponent(tokens.next()?)?;
                value.checked_pow(u32::try_from(exponent).ok()?)?
            }
            _ => return None,
        };

        if operator != "raised" {
            value = match operator {
                "plus" => value.checked_add(operand),
                "minus" => value.checked_sub(operand),
                "multiplied" => value.checked_mul(operand),
                "divided" => {
                    if operand == 0 {
                        return None;
                    }
                    value.checked_div(operand)
                }
                _ => None,
            }?;
        }
        let Some(next_operator) = tokens.next() else {
            return Some(value);
        };
        operator = next_operator;
    }
}

fn parse_number(token: &str) -> Option<i32> {
    token.parse().ok()
}

#[cfg(feature = "exponentials")]
fn parse_exponent(token: &str) -> Option<i32> {
    let digits = token
        .strip_suffix("st")
        .or_else(|| token.strip_suffix("nd"))
        .or_else(|| token.strip_suffix("rd"))
        .or_else(|| token.strip_suffix("th"))?;

    if digits.is_empty() || !digits.bytes().all(|byte| byte.is_ascii_digit()) {
        return None;
    }

    digits.parse().ok()
}
