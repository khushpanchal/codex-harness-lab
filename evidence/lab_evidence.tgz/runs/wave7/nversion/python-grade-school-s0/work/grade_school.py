class School:
    def __init__(self):
        self._students = {}

    def add_student(self, name, grade):
        if name in self._students:
            self._added = False
        else:
            self._students[name] = grade
            self._added = True

    def roster(self):
        students_by_grade = sorted(
            self._students.items(), key=lambda item: (item[1], item[0])
        )
        return [name for name, _ in students_by_grade]

    def grade(self, grade_number):
        return sorted(
            name for name, grade in self._students.items() if grade == grade_number
        )

    def added(self):
        return self._added
