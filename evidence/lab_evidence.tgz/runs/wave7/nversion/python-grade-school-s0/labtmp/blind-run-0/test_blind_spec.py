import unittest

from grade_school import School


class GradeSchoolTest(unittest.TestCase):
    # --- Roster behavior ---

    def test_roster_is_empty_when_no_student_is_added(self):
        self.assertEqual(School().roster(), [])

    def test_roster_is_sorted_by_grade_then_name(self):
        school = School()
        school.add_student("Jim", 5)
        school.add_student("Anna", 1)
        school.add_student("Alex", 2)
        school.add_student("Barb", 1)
        school.add_student("Zoe", 2)
        school.add_student("Charlie", 1)
        expected = ["Anna", "Barb", "Charlie", "Alex", "Zoe", "Jim"]
        self.assertEqual(school.roster(), expected)

    def test_roster_sorted_alphabetically_within_grade(self):
        school = School()
        for name, grade in [("Peter", 2), ("Anna", 1), ("Barb", 1), ("Charlie", 1), ("Alex", 2), ("Zoe", 2), ("Jim", 5)]:
            school.add_student(name, grade)
        self.assertEqual(
            school.roster(),
            ["Anna", "Barb", "Charlie", "Alex", "Peter", "Zoe", "Jim"],
        )

    def test_roster_grades_sort_numerically_not_lexicographically(self):
        school = School()
        for grade in (2, 10, 1):
            school.add_student(f"Student{grade}", grade)
        self.assertEqual(school.roster(), ["Student1", "Student2", "Student10"])

    def test_roster_is_not_mutated_by_caller(self):
        school = School()
        school.add_student("Jim", 3)
        roster = school.roster()
        roster.append("Bob")
        self.assertNotIn("Bob", school.roster())

    # --- Grade behavior ---

    def test_grade_is_empty_when_no_students_in_that_grade(self):
        self.assertEqual(School().grade(1), [])

    def test_grade_returns_students_in_that_grade(self):
        school = School()
        school.add_student("Jim", 2)
        school.add_student("Zoe", 2)
        school.add_student("Anna", 1)
        self.assertEqual(school.grade(2), ["Jim", "Zoe"])

    def test_grade_students_sorted_alphabetically(self):
        school = School()
        for name in ("Zoe", "Alex", "Peter"):
            school.add_student(name, 2)
        self.assertEqual(school.grade(2), ["Alex", "Peter", "Zoe"])

    def test_grade_for_unknown_grade_number(self):
        school = School()
        school.add_student("Jim", 5)
        self.assertEqual(school.grade(6), [])

    def test_grade_returns_new_list(self):
        school = School()
        school.add_student("Jim", 2)
        grade = school.grade(2)
        grade.append("Hacker")
        self.assertNotIn("Hacker", school.grade(2))

    # --- Adding students ---

    def test_add_student_to_grade(self):
        school = School()
        school.add_student("Jim", 2)
        self.assertEqual(school.grade(2), ["Jim"])

    def test_multiple_students_in_same_grade(self):
        school = School()
        school.add_student("Jim", 2)
        school.add_student("Blair", 2)
        school.add_student("James", 2)
        self.assertEqual(school.grade(2), ["Blair", "James", "Jim"])

    def test_same_student_added_to_same_grade_is_rejected(self):
        school = School()
        school.add_student("Jim", 2)
        school.add_student("Jim", 2)
        self.assertEqual(school.grade(2), ["Jim"])

    def test_adding_duplicate_does_not_change_roster(self):
        school = School()
        school.add_student("Jim", 2)
        school.add_student("Jim", 2)
        self.assertEqual(school.roster(), ["Jim"])

    def test_added_indicates_rejection_of_duplicate(self):
        school = School()
        self.assertTrue(school.added() in (True, False, None) or True)  # just callable
        school.add_student("Jim", 2)
        first_result = school.added()
        school.add_student("Jim", 2)
        second_result = school.added()
        # The second (duplicate) attempt must be indicated as incorrect; the
        # first (successful) attempt must be indicated differently.
        self.assertNotEqual(first_result, second_result)

    def test_added_after_successful_add(self):
        school = School()
        school.add_student("Jim", 2)
        self.assertEqual(school.added(), True)

    def test_added_after_duplicate_add(self):
        school = School()
        school.add_student("Jim", 2)
        school.add_student("Jim", 2)
        self.assertEqual(school.added(), False)

    # --- Same name in different grades ---

    def test_same_student_name_in_two_grades_not_allowed(self):
        school = School()
        school.add_student("Jim", 2)
        school.add_student("Jim", 3)
        self.assertEqual(school.roster(), ["Jim"])

    def test_added_false_when_name_reused_across_grades(self):
        school = School()
        school.add_student("Jim", 2)
        school.add_student("Jim", 3)
        self.assertEqual(school.added(), False)

    # --- Independence between schools ---

    def test_new_school_is_independent(self):
        school1 = School()
        school2 = School()
        school1.add_student("Jim", 3)
        self.assertEqual(school2.roster(), [])
        self.assertEqual(school2.grade(3), [])

    # --- Edge cases ---

    def test_grade_zero(self):
        school = School()
        school.add_student("Jim", 0)
        self.assertEqual(school.grade(0), ["Jim"])
        self.assertEqual(school.roster(), ["Jim"])

    def test_many_students_ordering(self):
        school = School()
        names = ["alice", "bob", "carol", "dave", "eve"]
        for i, name in enumerate(names):
            school.add_student(name, i % 2 + 1)
        self.assertEqual(school.roster(), ["alice", "carol", "eve", "bob", "dave"])


if __name__ == "__main__":
    unittest.main()
