class School:
    def __init__(self):
        self._students = {}

    def add_student(self, name, grade):
        if name in self._students:
            return False
        self._students[name] = grade
        return True

    def roster(self):
        grades = sorted(set(self._students.values()))
        return [name for grade in grades for name in self.grade(grade)]

    def grade(self, grade_number):
        return sorted(
            name for name, grade in self._students.items() if grade == grade_number
        )

    def added(self):
        return self._students
