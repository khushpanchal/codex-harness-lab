import unittest

from grade_school import School


class GradeSchoolTest(unittest.TestCase):
    def test_roster_is_empty_when_no_student_is_added(self):
        school = School()
        expected = []
        self.assertEqual(school.roster(), expected)

    # --- adding students ---

    def test_add_student(self):
        school = School()
        school.add_student("Aimee", 2)
        expected = [True]
        self.assertEqual(school.added(), expected)

    def test_add_students_to_same_grade(self):
        school = School()
        school.add_student("Blair", 2)
        school.add_student("James", 2)
        school.add_student("Paul", 2)
        expected = [True, True, True]
        self.assertEqual(school.added(), expected)

    def test_student_added_to_multiple_grades(self):
        school = School()
        school.add_student("Aimee", 3)
        school.add_student("Aimee", 7)
        expected = [True, False]
        self.assertEqual(school.added(), expected)

    def test_grade_returns_students_in_grade(self):
        school = School()
        school.add_student("Franklin", 5)
        school.add_student("Bradley", 5)
        school.add_student("Jeff", 1)
        expected = ["Bradley", "Franklin"]
        self.assertEqual(school.grade(5), expected)

    # --- duplicate handling ---

    def test_duplicate_student_in_grade(self):
        school = School()
        school.add_student("Aimee", 3)
        school.add_student("Aimee", 3)
        expected = [True, False]
        self.assertEqual(school.added(), expected)

    def test_duplicate_student_added_same_grade_returns_false(self):
        school = School()
        school.add_student("Jim", 2)
        school.add_student("Jim", 2)
        self.assertEqual(school.grade(2), ["Jim"])

    # --- grade ---

    def test_empty_grade(self):
        school = School()
        self.assertEqual(school.grade(1), [])

    def test_students_in_grade_are_sorted_alphabetically(self):
        school = School()
        school.add_student("Franklin", 5)
        school.add_student("Bradley", 5)
        school.add_student("Jeff", 1)
        expected = ["Bradley", "Franklin"]
        self.assertEqual(school.grade(5), expected)

    def test_grade_after_rejected_add_does_not_change(self):
        school = School()
        school.add_student("Aimee", 3)
        school.add_student("Aimee", 3)
        self.assertEqual(school.grade(3), ["Aimee"])

    def test_adding_student_in_one_grade_does_not_affect_other_grades(self):
        school = School()
        school.add_student("Jim", 2)
        school.add_student("Zoe", 3)
        self.assertEqual(school.grade(2), ["Jim"])
        self.assertEqual(school.grade(3), ["Zoe"])

    # --- roster ---

    def test_roster_sorted_by_grade_then_name(self):
        school = School()
        school.add_student("Peter", 2)
        school.add_student("Anna", 1)
        school.add_student("Barb", 1)
        school.add_student("Zoe", 2)
        school.add_student("Alex", 2)
        school.add_student("Jim", 5)
        expected = ["Anna", "Barb", "Alex", "Peter", "Zoe", "Jim"]
        self.assertEqual(school.roster(), expected)

    def test_roster_matches_grade_lists(self):
        school = School()
        school.add_student("Jim", 3)
        self.assertEqual(school.roster(), school.grade(3))

    def test_roster_is_sorted_within_each_grade(self):
        school = School()
        school.add_student("Peter", 2)
        school.add_student("Alex", 2)
        school.add_student("Zoe", 2)
        expected = ["Alex", "Peter", "Zoe"]
        self.assertEqual(school.roster(), expected)

    def test_roster_grades_sorted_numerically_not_lexicographically(self):
        school = School()
        school.add_student("Jim", 10)
        school.add_student("Anna", 2)
        expected = ["Anna", "Jim"]
        self.assertEqual(school.roster(), expected)

    def test_roster_after_rejected_adds(self):
        school = School()
        school.add_student("Aimee", 3)
        school.add_student("Aimee", 3)
        school.add_student("Aimee", 7)
        expected = ["Aimee"]
        self.assertEqual(school.roster(), expected)

    def test_roster_multiple_students_multiple_grades(self):
        school = School()
        school.add_student("Jim", 3)
        school.add_student("Zoe", 1)
        school.add_student("Alex", 3)
        expected = ["Zoe", "Alex", "Jim"]
        self.assertEqual(school.roster(), expected)

    def test_new_school_is_independent(self):
        school1 = School()
        school1.add_student("Jim", 2)
        school2 = School()
        self.assertEqual(school2.roster(), [])
        self.assertEqual(school2.grade(2), [])


if __name__ == "__main__":
    unittest.main()
