import io
import unittest
from unittest import mock

from grep import grep

FILE_TEXT = {
    "iliad.txt": """Achilles sing, O Goddess! Peleus' son;
His wrath pernicious, who ten thousand woes
Caused to Achaia's host, sent many a soul
Illustrious into Ades premature,
And Heroes gave (so stood the will of Jove)
To dogs and to all ravening fowls a prey,
When fierce dispute had separated once
The noble Chief Achilles from the son
Of Atreus, Agamemnon, King of men.
""",
    "midsummer-night.txt": """I do entreat your grace to pardon me.
I know not by what power I am made bold,
Nor how it may concern my modesty,
In such a presence here to plead my thoughts;
But I beseech your grace that I may know
The worst that may befall me in this case,
If I refuse to wed Demetrius.
""",
    "paradise-lost.txt": """Of Mans First Disobedience, and the Fruit
Of that Forbidden Tree, whose mortal tast
Brought Death into the World, and all our woe,
With loss of Eden, till one greater Man
Restore us, and regain the blissful Seat,
Sing Heav'nly Muse, that on the secret top
Of Oreb, or of Sinai, didst inspire
That Shepherd, who first taught the chosen Seed
""",
}


def open_mock(fname, *args, **kwargs):
    try:
        return io.StringIO(FILE_TEXT[fname])
    except KeyError:
        raise RuntimeError(
            "Expected one of {0!r}: got {1!r}".format(list(FILE_TEXT.keys()), fname)
        )


@mock.patch("grep.open", name="open", side_effect=open_mock, create=True)
@mock.patch("io.StringIO", name="StringIO", wraps=io.StringIO)
class GrepTest(unittest.TestCase):
    # Single file, no flags
    def test_one_file_one_match_no_flags(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "", ["iliad.txt"]),
            "Of Atreus, Agamemnon, King of men.\n",
        )

    def test_one_file_one_match_case_insensitive(self, mock_file, mock_open):
        self.assertEqual(
            grep("AGAMEMNON", "-i", ["iliad.txt"]),
            "Of Atreus, Agamemnon, King of men.\n",
        )

    def test_one_file_no_matches_no_flags(self, mock_file, mock_open):
        self.assertEqual(grep("Gandalf", "", ["iliad.txt"]), "")

    def test_one_file_multiple_matches_no_flags(self, mock_file, mock_open):
        self.assertEqual(
            grep("may", "", ["midsummer-night.txt"]),
            "Nor how it may concern my modesty,\n"
            "The worst that may befall me in this case,\n",
        )

    def test_one_file_match_entire_line(self, mock_file, mock_open):
        self.assertEqual(
            grep("But I beseech your grace that I may know", "-x", ["midsummer-night.txt"]),
            "But I beseech your grace that I may know\n",
        )

    def test_one_file_partial_line_does_not_match_entire_line(self, mock_file, mock_open):
        self.assertEqual(
            grep("beseech your grace", "-x", ["midsummer-night.txt"]), ""
        )

    def test_one_file_inverted_match(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "-v", ["iliad.txt"]),
            "Achilles sing, O Goddess! Peleus' son;\n"
            "His wrath pernicious, who ten thousand woes\n"
            "Caused to Achaia's host, sent many a soul\n"
            "Illustrious into Ades premature,\n"
            "And Heroes gave (so stood the will of Jove)\n"
            "To dogs and to all ravening fowls a prey,\n"
            "When fierce dispute had separated once\n"
            "The noble Chief Achilles from the son\n",
        )

    def test_one_file_line_numbers(self, mock_file, mock_open):
        self.assertEqual(
            grep("may", "-n", ["midsummer-night.txt"]),
            "3:Nor how it may concern my modesty,\n"
            "6:The worst that may befall me in this case,\n",
        )

    def test_one_file_list_matching_files(self, mock_file, mock_open):
        self.assertEqual(grep("may", "-l", ["midsummer-night.txt"]), "midsummer-night.txt\n")

    def test_one_file_list_non_matching_files(self, mock_file, mock_open):
        self.assertEqual(grep("May", "-l", ["midsummer-night.txt"]), "")

    def test_one_file_combined_flags_invert_and_line_numbers(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "-n -v", ["iliad.txt"]),
            "1:Achilles sing, O Goddess! Peleus' son;\n"
            "2:His wrath pernicious, who ten thousand woes\n"
            "3:Caused to Achaia's host, sent many a soul\n"
            "4:Illustrious into Ades premature,\n"
            "5:And Heroes gave (so stood the will of Jove)\n"
            "6:To dogs and to all ravening fowls a prey,\n"
            "7:When fierce dispute had separated once\n"
            "8:The noble Chief Achilles from the son\n",
        )

    def test_one_file_entire_line_case_insensitive(self, mock_file, mock_open):
        self.assertEqual(
            grep("IF I REFUSE TO WED DEMETRIUS.", "-i -x", ["midsummer-night.txt"]),
            "If I refuse to wed Demetrius.\n",
        )

    # Multiple files, no flags
    def test_multiple_files_one_match_no_flags(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "", ["iliad.txt", "midsummer-night.txt"]),
            "iliad.txt:Of Atreus, Agamemnon, King of men.\n",
        )

    def test_multiple_files_matches_in_order(self, mock_file, mock_open):
        self.assertEqual(
            grep("the", "", ["midsummer-night.txt", "paradise-lost.txt"]),
            "midsummer-night.txt:I know not by what power I am made bold,\n"
            "midsummer-night.txt:But I beseech your grace that I may know\n"
            "paradise-lost.txt:Of that Forbidden Tree, whose mortal tast\n"
            "paradise-lost.txt:With loss of Eden, till one greater Man\n"
            "paradise-lost.txt:Sing Heav'nly Muse, that on the secret top\n",
        )

    def test_multiple_files_no_matches(self, mock_file, mock_open):
        self.assertEqual(grep("Gandalf", "", ["iliad.txt", "paradise-lost.txt"]), "")

    def test_multiple_files_line_numbers(self, mock_file, mock_open):
        self.assertEqual(
            grep("may", "-n", ["midsummer-night.txt", "paradise-lost.txt"]),
            "midsummer-night.txt:3:Nor how it may concern my modesty,\n"
            "midsummer-night.txt:6:The worst that may befall me in this case,\n",
        )

    def test_multiple_files_file_and_line_number_order(self, mock_file, mock_open):
        self.assertEqual(
            grep("who", "-n", ["iliad.txt", "paradise-lost.txt"]),
            "iliad.txt:2:His wrath pernicious, who ten thousand woes\n"
            "iliad.txt:8:The noble Chief Achilles from the son\n"
            "paradise-lost.txt:8:That Shepherd, who first taught the chosen Seed\n",
        )

    def test_multiple_files_case_insensitive(self, mock_file, mock_open):
        self.assertEqual(
            grep("ACHILLES", "-i", ["iliad.txt", "midsummer-night.txt"]),
            "iliad.txt:Achilles sing, O Goddess! Peleus' son;\n"
            "iliad.txt:The noble Chief Achilles from the son\n",
        )

    def test_multiple_files_inverted(self, mock_file, mock_open):
        result = grep("Achilles", "-v", ["midsummer-night.txt"])
        self.assertEqual(
            result,
            "midsummer-night.txt:I do entreat your grace to pardon me.\n"
            "midsummer-night.txt:I know not by what power I am made bold,\n"
            "midsummer-night.txt:Nor how it may concern my modesty,\n"
            "midsummer-night.txt:In such a presence here to plead my thoughts;\n"
            "midsummer-night.txt:But I beseech your grace that I may know\n"
            "midsummer-night.txt:The worst that may befall me in this case,\n"
            "midsummer-night.txt:If I refuse to wed Demetrius.\n",
        )

    def test_multiple_files_entire_line(self, mock_file, mock_open):
        self.assertEqual(
            grep("But I beseech your grace that I may know", "-x", ["iliad.txt", "midsummer-night.txt"]),
            "midsummer-night.txt:But I beseech your grace that I may know\n",
        )

    def test_multiple_files_list_matching_files(self, mock_file, mock_open):
        self.assertEqual(
            grep("Achilles", "-l", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]),
            "iliad.txt\n",
        )

    def test_multiple_files_list_matching_files_multiple(self, mock_file, mock_open):
        self.assertEqual(
            grep("may", "-l", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]),
            "midsummer-night.txt\n",
        )

    def test_multiple_files_combined_flags_i_n_x(self, mock_file, mock_open):
        self.assertEqual(
            grep("THE WORST THAT MAY BEFALL ME IN THIS CASE,", "-i -n -x", ["midsummer-night.txt"]),
            "midsummer-night.txt:6:The worst that may befall me in this case,\n",
        )

    def test_flags_combined_list_and_line_numbers(self, mock_file, mock_open):
        self.assertEqual(
            grep("may", "-l -n", ["midsummer-night.txt"]),
            "midsummer-night.txt\n",
        )

    def test_pattern_with_special_regex_chars_is_fixed_string(self, mock_file, mock_open):
        self.assertEqual(grep("Peleus' son;", "", ["iliad.txt"]),
                         "Achilles sing, O Goddess! Peleus' son;\n")

    def test_pattern_dot_is_literal(self, mock_file, mock_open):
        # '.' should not act as a regex wildcard
        self.assertEqual(grep("men.", "", ["iliad.txt"]),
                         "Of Atreus, Agamemnon, King of men.\n")

    def test_files_read_in_specified_order(self, mock_file, mock_open):
        result = grep("Of", "", ["paradise-lost.txt", "iliad.txt"])
        self.assertEqual(
            result,
            "paradise-lost.txt:Of Mans First Disobedience, and the Fruit\n"
            "paradise-lost.txt:Of that Forbidden Tree, whose mortal tast\n"
            "iliad.txt:Illustrious into Ades premature,\n"
            "iliad.txt:To dogs and to all ravening fowls a prey,\n"
            "iliad.txt:Of Atreus, Agamemnon, King of men.\n",
        )
        # files opened in the order given
        opened = [c.args[0] for c in mock_open.call_args_list]
        self.assertEqual(opened, ["paradise-lost.txt", "iliad.txt"])


if __name__ == "__main__":
    unittest.main()
