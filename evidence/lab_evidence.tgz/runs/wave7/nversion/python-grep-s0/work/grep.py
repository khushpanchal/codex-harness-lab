def grep(pattern, flags, files):
    line_numbers = "-n" in flags
    names_only = "-l" in flags
    case_insensitive = "-i" in flags
    invert = "-v" in flags
    whole_line = "-x" in flags

    if case_insensitive:
        pattern = pattern.casefold()

    output = []
    matched_files = set()

    for filename in files:
        with open(filename) as source:
            for line_number, line in enumerate(source, start=1):
                candidate = line.rstrip("\n")
                haystack = candidate.casefold() if case_insensitive else candidate

                if whole_line:
                    matched = haystack == pattern
                else:
                    matched = pattern in haystack

                if matched if not invert else not matched:
                    if names_only:
                        if filename not in matched_files:
                            matched_files.add(filename)
                            output.append(filename)
                        continue

                    prefix = ""
                    if len(files) > 1:
                        prefix += filename + ":"
                    if line_numbers:
                        prefix += str(line_number) + ":"
                    output.append(prefix + candidate)

    if not output:
        return ""

    return "\n".join(output) + "\n"
