import unittest

from poker import best_hands


class PokerTest(unittest.TestCase):
    def test_single_hand_always_wins(self):
        self.assertEqual(best_hands(["4S 5S 7H 8D JC"]), ["4S 5S 7H 8D JC"])

    # Highest card
    def test_highest_card_of_all_hands_wins(self):
        self.assertEqual(
            best_hands(["4D 5S 6S 8D 3C", "2S 4C 7S 9H 10H", "3S 4S 5D 6H JH"]),
            ["3S 4S 5D 6H JH"],
        )

    def test_tie_has_multiple_winners(self):
        self.assertEqual(
            best_hands(
                [
                    "4D 5S 6S 8D 3C",
                    "2S 4C 7S 9H 10H",
                    "3S 4S 5D 6H JH",
                    "3H 4H 5C 6C JD",
                ]
            ),
            ["3S 4S 5D 6H JH", "3H 4H 5C 6C JD"],
        )

    def test_multiple_hands_with_the_same_high_cards_tie_compares_next_highest_ranked_down_to_last(self):
        self.assertEqual(
            best_hands(["3S 5H 6S 8D 7H", "2S 5D 6D 8S 7S"]),
            ["3S 5H 6S 8D 7H"],
        )

    # One pair
    def test_winning_high_card_hand_also_has_the_lowest_card_so_is_aliased_as_one_pair_hand(self):
        self.assertEqual(
            best_hands(["2S 5H 6S 8D 7H", "3S 4D 6D 9S 7S", "2H 3H 3D 4D 4S"]),
            ["2H 3H 3D 4D 4S"],
        )

    def test_one_pair_beats_high_card(self):
        self.assertEqual(
            best_hands(["4S 5H 6S 8D 7H", "2S 4D 6D 9S 7S", "3H 4H 3D 4D 5S"]),
            ["3H 4H 3D 4D 5S"],
        )

    def test_one_pair_wins_by_rank(self):
        self.assertEqual(
            best_hands(["4S 5S 6S 8D 3C", "2S 4C 7S 9H 10H", "3S 3H 5D 6H JH"]),
            ["3S 3H 5D 6H JH"],
        )

    def test_one_pair_beats_hands_with_two_pairs_of_different_ranks(self):
        self.assertEqual(
            best_hands(["4S 5H 6S 8D 7H", "2S 4D 6D 9S 7S", "3S 3D 4D 4S 5S"]),
            ["3S 3D 4D 4S 5S"],
        )

    # Two pair
    def test_two_pairs_beats_one_pair(self):
        self.assertEqual(
            best_hands(["2S 8C 9S 7C 5C", "3S 3D 4D 4S 5S"]),
            ["3S 3D 4D 4S 5S"],
        )

    def test_both_hands_have_the_same_pair_compares_kickers(self):
        self.assertEqual(
            best_hands(["4S 5S 6S 8D 3C", "2S 2C 7S 9H 10H", "3S 3H 5D 6H JH"]),
            ["3S 3H 5D 6H JH"],
        )

    def test_two_pair_beats_one_pair(self):
        self.assertEqual(
            best_hands(["8C 2S 9S 7C 5C", "2S 3D 4D 4S 5S"]),
            ["2S 3D 4D 4S 5S"],
        )

    def test_two_pair_rank(self):
        self.assertEqual(
            best_hands(["2S 2C 9S 7C 5C", "3S 3D 4D 4S 5S"]),
            ["3S 3D 4D 4S 5S"],
        )

    def test_two_pair_second_pair_compare(self):
        self.assertEqual(
            best_hands(["2S 2C 5S 7C 5C", "2S 2C 6S 7C 6C"]),
            ["2S 2C 6S 7C 6C"],
        )

    def test_two_pair_3_pair_kicker_compare(self):
        self.assertEqual(
            best_hands(["2S 2C 5S 7C 5C", "2S 2C 5S 6C 5C"]),
            ["2S 2C 5S 6C 5C"],
        )

    # Three of a kind
    def test_three_of_a_kind_beats_two_pair(self):
        self.assertEqual(
            best_hands(["2S 2C 9S 7C 5C", "2S 2C 2D 4S 5S"]),
            ["2S 2C 2D 4S 5S"],
        )

    def test_three_of_a_kind_aces_beats_three_of_a_kind_kings(self):
        self.assertEqual(
            best_hands(["AS AC 3S 7C 5C", "KS KC 2D 4S 5S"]),
            ["AS AC 3S 7C 5C"],
        )

    # Straight
    def test_straight_beats_three_of_a_kind(self):
        self.assertEqual(
            best_hands(["2S 2C 3C 3S 5C", "2S 3C 4S 5D 6C"]),
            ["2S 3C 4S 5D 6C"],
        )

    def test_aces_can_end_a_straight_high(self):
        self.assertEqual(
            best_hands(["2S 2C 3C 3S 5C", "10S JH QS KD AC"]),
            ["10S JH QS KD AC"],
        )

    def test_straight_higher_rank(self):
        self.assertEqual(
            best_hands(["4S 5C 7H 8S 6C", "2S 3C 4H 5S 6C"]),
            ["4S 5C 7H 8S 6C"],
        )

    def test_aces_can_start_a_straight_low(self):
        self.assertEqual(
            best_hands(["AS 2C 3H 4S 5C", "3S 4C 5H 6S 7C"]),
            ["3S 4C 5H 6S 7C"],
        )

    def test_aces_cannot_be_in_the_middle_of_a_straight(self):
        self.assertEqual(
            best_hands(["2C 4D 7H AC 3S", "3H 5D 8S 9D 10C"]),
            ["3H 5D 8S 9D 10C"],
        )

    # Flush
    def test_flush_beats_a_straight(self):
        self.assertEqual(
            best_hands(["2S 2C 3C 3S 5C", "2S 4C 6S 8D 10C"]),
            ["2S 4C 6S 8D 10C"],
        )

    def test_flush_higher_rank(self):
        self.assertEqual(
            best_hands(["4H 5H 7H 8H 6H", "2S 4S 6S 8S 10S"]),
            ["4H 5H 7H 8H 6H"],
        )

    # Full house
    def test_full_house_beats_a_flush(self):
        self.assertEqual(
            best_hands(["2H 4C 6H 8H 10H", "3S 3C 3H 9S 9D"]),
            ["3S 3C 3H 9S 9D"],
        )

    def test_full_house_higher_rank(self):
        self.assertEqual(
            best_hands(["4H 4S 4D 9S 9D", "3H 3S 3D 9S 9D"]),
            ["4H 4S 4D 9S 9D"],
        )

    # Four of a kind
    def test_four_of_a_kind_beats_a_full_house(self):
        self.assertEqual(
            best_hands(["4S 5H 4D 5S 4H", "3S 3H 2S 2D 3D"]),
            ["4S 5H 4D 5S 4H"],
        )

    def test_four_of_a_kind_higher_rank(self):
        self.assertEqual(
            best_hands(["2S 2H 2D 5S 2C", "3S 3H 3D 5S 3C"]),
            ["3S 3H 3D 5S 3C"],
        )

    # Straight flush
    def test_straight_flush_beats_four_of_a_kind(self):
        self.assertEqual(
            best_hands(["4S 5H 5C 5H 4H", "3S 3H 2S 2D 3D"]),
            ["4S 5H 5C 5H 4H"],
        )

    def test_aces_can_end_a_straight_flush(self):
        self.assertEqual(
            best_hands(["KH QS JD 10C 10S", "10C JH QD KS AC"]),
            ["10C JH QD KS AC"],
        )

    def test_aces_can_start_a_straight_flush(self):
        self.assertEqual(
            best_hands(["KH QS JD 10C 10S", "AC 2H 3D 4S 5C"]),
            ["AC 2H 3D 4S 5C"],
        )

    def test_straight_flush_higher_rank(self):
        self.assertEqual(
            best_hands(["4C 5C 6C 7C 8C", "3C 4C 5C 6C 7C"]),
            ["4C 5C 6C 7C 8C"],
        )

    # Ties among equal best hands
    def test_tied_straight_flushes_both_win(self):
        self.assertEqual(
            best_hands(["2C 3C 4C 5C 6C", "2S 3S 4S 5S 6S"]),
            ["2C 3C 4C 5C 6C", "2S 3S 4S 5S 6S"],
        )

    def test_a_hand_has_five_cards(self):
        with self.assertRaises(ValueError):
            best_hands(["2D 4C 5D"])

    def test_multiple_hand_errors(self):
        with self.assertRaises(ValueError):
            best_hands(["2D 4C 5D", "4D 5D 6D 7D 8D"])


if __name__ == "__main__":
    unittest.main()
