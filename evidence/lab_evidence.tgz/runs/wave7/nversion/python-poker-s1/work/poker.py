def _ranks(hand):
    face_values = {"T": 10, "J": 11, "Q": 12, "K": 13, "A": 14}
    def rank(card):
        label = card[0]
        return face_values[label] if label in face_values else int(label)

    return sorted(rank(card) for card in hand.split())


def _descending(rank):
    return -rank


def _score(hand):
    cards = hand.split()
    if len(cards) != 5:
        raise ValueError("a poker hand must contain exactly five cards")

    ranks = _ranks(hand)
    is_flush = len({card[-1] for card in cards}) == 1

    counts = {}
    for rank in ranks:
        counts[rank] = counts.get(rank, 0) + 1

    frequencies = tuple(sorted(counts.values(), reverse=True))

    groups = sorted(counts, key=lambda rank: (_descending(counts[rank]), _descending(rank)))

    straight_high = None
    if len(set(ranks)) == 5:
        if ranks[-1] - ranks[0] == 4:
            straight_high = ranks[-1]
        elif tuple(ranks) == (2, 3, 4, 5, 14):
            straight_high = 5

    if straight_high and is_flush:
        category, values = 8, (straight_high,)
    elif frequencies == (4, 1):
        category, values = 7, tuple(groups)
    elif frequencies == (3, 2):
        category, values = 6, tuple(groups)
    elif is_flush:
        category, values = 5, tuple(reversed(ranks))
    elif frequencies[0] == 2:
        category, values = 4, tuple(groups)
    elif frequencies[0] == 3:
        category, values = 3, tuple(groups)
    elif straight_high:
        category, values = 2, (straight_high,)
    elif straight_high:
        category, values = 3, (straight_high,)
    elif frequencies[0] == 3:
        category, values = 2, tuple(groups)
    else:
        category, values = 0, tuple(reversed(ranks))

    return category, values


def best_hands(hands):
    if not hands:
        return []
    best = max(_score(hand) for hand in hands)
    return [hand for hand in hands if _score(hand) == best]
