def grep(pattern, flags, files):
    case_insensitive = "-i" in flags
    invert = "-v" in flags
    whole_line = "-x" in flags
    show_numbers = "-n" in flags
    filenames_only = "-l" in flags
    multiple_files = len(files) > 1

    if case_insensitive:
        pattern = pattern.lower()

    matches = []
    seen_files = set()
    for filename in files:
        with open(filename) as file:
            for line_number, line in enumerate(file, start=1):
                text = line.rstrip("\n")
                needle = text.lower() if case_insensitive else text

                if whole_line:
                    is_match = needle == pattern
                else:
                    is_match = pattern in needle

                if is_match == invert:
                    continue

                if filenames_only:
                    if filename not in seen_files:
                        matches.append(filename)
                        seen_files.add(filename)
                else:
                    output = ""
                    if multiple_files:
                        output += filename + ":"
                    if show_numbers:
                        output += str(line_number) + ":"
                    matches.append(output + text)

    return "\n".join(matches) + "\n" if matches else ""
