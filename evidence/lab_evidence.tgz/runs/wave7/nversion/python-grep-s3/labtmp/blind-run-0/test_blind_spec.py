import unittest
from unittest import mock
import io

from grep import grep

FILE_TEXT = {
    "iliad.txt": """Achilles sing, O Goddess! Peleus' son;
His wrath pernicious, who ten thousand woes
Caused to Achaia's host, sent many a soul
Illustrious into Ades premature,
And Heroes gave (so stood the will of Jove)
To dogs and to all ravening fowls a prey,
When fierce dispute had separated once
The noble Chief Achilles from the son
Of Atreus, Agamemnon, King of men.\n""",
    "midsummer-night.txt": """I do entreat your grace to pardon me.
I know not by what power I am made bold,
Nor how it may concern my modesty,
In such a presence here to plead my thoughts;
But I beseech your grace that I may know
The worst that may befall me in this case,
If I refuse to wed Demetrius.\n""",
    "paradise-lost.txt": """Of Mans First Disobedience, and the Fruit
Of that Forbidden Tree, whose mortal tast
Brought Death into the World, and all our woe,
With loss of Eden, till one greater Man
Restore us, and regain the blissful Seat,
Sing Heav'nly Muse, that on the secret top
Of Oreb, or of Sinai, didst inspire
That Shepherd, who first taught the chosen Seed\n""",
}


def open_mock(fname, *args, **kwargs):
    try:
        return io.StringIO(FILE_TEXT[fname])
    except KeyError:
        raise RuntimeError(
            "Expected one of {0!r}: got {1!r}".format(list(FILE_TEXT.keys()), fname)
        )


@mock.patch("grep.open", name="open", side_effect=open_mock, create=True)
@mock.patch("io.StringIO", name="StringIO", wraps=io.StringIO)
class GrepTest(unittest.TestCase):
    maxDiff = None

    def assertMultiLineEqual(self, first, second, msg=None):
        self.assertIsInstance(first, str)
        self.assertIsInstance(second, str)
        unittest.TestCase.assertMultiLineEqual(self, first, second, msg)

    # --- single file, no flags ---
    def test_one_file_one_match_no_flags(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "", ["iliad.txt"]),
            "Of Atreus, Agamemnon, King of men.\n",
        )

    def test_one_file_one_match_prints_whole_line_when_no_flag(self, mock_file, mock_open):
        self.assertEqual(
            grep("forbidden", "", ["paradise-lost.txt"]),
            "Of that Forbidden Tree, whose mortal tast\n",
        )

    def test_one_file_one_match_case_sensitive(self, mock_file, mock_open):
        self.assertEqual(grep("Forbidden", "", ["paradise-lost.txt"]), "")

    def test_one_file_multiple_matches_no_flags(self, mock_file, mock_open):
        self.assertEqual(
            grep("may", "", ["midsummer-night.txt"]),
            "Nor how it may concern my modesty,\n"
            "But I beseech your grace that I may know\n"
            "The worst that may befall me in this case,\n",
        )

    def test_one_file_no_match_no_flags(self, mock_file, mock_open):
        self.assertEqual(grep("Gandalf", "", ["iliad.txt"]), "")

    def test_one_file_empty_files_list(self, mock_file, mock_open):
        self.assertEqual(grep("Agamemnon", "", []), "")

    # --- single file, -n flag ---
    def test_one_file_one_match_number_flag(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "-n", ["iliad.txt"]),
            "9:Of Atreus, Agamemnon, King of men.\n",
        )

    def test_one_file_multiple_matches_number_flag(self, mock_file, mock_open):
        self.assertEqual(
            grep("may", "-n", ["midsummer-night.txt"]),
            "3:Nor how it may concern my modesty,\n"
            "5:But I beseech your grace that I may know\n"
            "6:The worst that may befall me in this case,\n",
        )

    def test_one_file_no_match_number_flag(self, mock_file, mock_open):
        self.assertEqual(grep("Gandalf", "-n", ["iliad.txt"]), "")

    def test_one_file_match_line_number_one(self, mock_file, mock_open):
        self.assertEqual(
            grep("Achilles", "-n", ["iliad.txt"]),
            "1:Achilles sing, O Goddess! Peleus' son;\n8:The noble Chief Achilles from the son\n",
        )

    # --- single file, -l flag ---
    def test_one_file_one_match_list_flag(self, mock_file, mock_open):
        self.assertEqual(grep("Agamemnon", "-l", ["iliad.txt"]), "iliad.txt\n")

    def test_one_file_no_match_list_flag(self, mock_file, mock_open):
        self.assertEqual(grep("Gandalf", "-l", ["iliad.txt"]), "")

    # --- single file, -i flag ---
    def test_one_file_case_insensitive_flag(self, mock_file, mock_open):
        self.assertEqual(
            grep("Forbidden", "-i", ["paradise-lost.txt"]),
            "Of that Forbidden Tree, whose mortal tast\n",
        )

    def test_one_file_case_insensitive_lower_pattern(self, mock_file, mock_open):
        self.assertEqual(
            grep("achaia", "-i", ["iliad.txt"]),
            "Caused to Achaia's host, sent many a soul\n",
        )

    def test_one_file_case_insensitive_no_other_matches(self, mock_file, mock_open):
        self.assertEqual(grep("agamemnon", "-i", ["iliad.txt"]), "Of Atreus, Agamemnon, King of men.\n")

    # --- single file, -v flag ---
    def test_one_file_invert_flag(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "-v", ["iliad.txt"]),
            "Achilles sing, O Goddess! Peleus' son;\n"
            "His wrath pernicious, who ten thousand woes\n"
            "Caused to Achaia's host, sent many a soul\n"
            "Illustrious into Ades premature,\n"
            "And Heroes gave (so stood the will of Jove)\n"
            "To dogs and to all ravening fowls a prey,\n"
            "When fierce dispute had separated once\n"
            "The noble Chief Achilles from the son\n",
        )

    def test_one_file_invert_no_match_returns_all(self, mock_file, mock_open):
        self.assertEqual(grep("Gandalf", "-v", ["iliad.txt"]), FILE_TEXT["iliad.txt"])

    def test_one_file_invert_number_flag(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "-v -n", ["iliad.txt"]),
            "1:Achilles sing, O Goddess! Peleus' son;\n"
            "2:His wrath pernicious, who ten thousand woes\n"
            "3:Caused to Achaia's host, sent many a soul\n"
            "4:Illustrious into Ades premature,\n"
            "5:And Heroes gave (so stood the will of Jove)\n"
            "6:To dogs and to all ravening fowls a prey,\n"
            "7:When fierce dispute had separated once\n"
            "8:The noble Chief Achilles from the son\n",
        )

    # --- single file, -x flag ---
    def test_one_file_match_entire_line_flag(self, mock_file, mock_open):
        self.assertEqual(
            grep("But I beseech your grace that I may know", "-x", ["midsummer-night.txt"]),
            "But I beseech your grace that I may know\n",
        )

    def test_one_file_match_entire_line_flag_substring_no_match(self, mock_file, mock_open):
        self.assertEqual(grep("beseech your grace", "-x", ["midsummer-night.txt"]), "")

    def test_one_file_match_entire_line_flag_number(self, mock_file, mock_open):
        self.assertEqual(
            grep("But I beseech your grace that I may know", "-x -n", ["midsummer-night.txt"]),
            "5:But I beseech your grace that I may know\n",
        )

    def test_one_file_match_entire_line_flag_case_insensitive(self, mock_file, mock_open):
        self.assertEqual(
            grep("but i beseech your grace that i may know", "-x -i", ["midsummer-night.txt"]),
            "But I beseech your grace that I may know\n",
        )

    def test_one_file_match_entire_line_flag_invert(self, mock_file, mock_open):
        result = grep("But I beseech your grace that I may know", "-x -v", ["midsummer-night.txt"])
        self.assertNotIn("But I beseech your grace that I may know\n", result)
        self.assertIn("I do entreat your grace to pardon me.\n", result)
        self.assertEqual(result.count("\n"), 6)

    # --- multiple files ---
    def test_multiple_files_one_match_no_flags(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]),
            "iliad.txt:Of Atreus, Agamemnon, King of men.\n",
        )

    def test_multiple_files_several_matches_no_flags(self, mock_file, mock_open):
        self.assertEqual(
            grep("may", "", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]),
            "midsummer-night.txt:Nor how it may concern my modesty,\n"
            "midsummer-night.txt:But I beseech your grace that I may know\n"
            "midsummer-night.txt:The worst that may befall me in this case,\n",
        )

    def test_multiple_files_no_match_no_flags(self, mock_file, mock_open):
        self.assertEqual(
            grep("Gandalf", "", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]), ""
        )

    def test_multiple_files_matches_in_multiple_files(self, mock_file, mock_open):
        self.assertEqual(
            grep("who", "", ["iliad.txt", "paradise-lost.txt"]),
            "iliad.txt:His wrath pernicious, who ten thousand woes\n"
            "iliad.txt:Of Atreus, Agamemnon, King of men.\n"
            "paradise-lost.txt:Of that Forbidden Tree, whose mortal tast\n"
            "paradise-lost.txt:Sing Heav'nly Muse, that on the secret top\n"
            "paradise-lost.txt:That Shepherd, who first taught the chosen Seed\n",
        )

    def test_multiple_files_number_flag_no_flags(self, mock_file, mock_open):
        self.assertEqual(
            grep("who", "-n", ["iliad.txt", "paradise-lost.txt"]),
            "iliad.txt:2:His wrath pernicious, who ten thousand woes\n"
            "iliad.txt:9:Of Atreus, Agamemnon, King of men.\n"
            "paradise-lost.txt:2:Of that Forbidden Tree, whose mortal tast\n"
            "paradise-lost.txt:6:Sing Heav'nly Muse, that on the secret top\n"
            "paradise-lost.txt:8:That Shepherd, who first taught the chosen Seed\n",
        )

    def test_multiple_files_list_flag(self, mock_file, mock_open):
        self.assertEqual(
            grep("who", "-l", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]),
            "iliad.txt\nparadise-lost.txt\n",
        )

    def test_multiple_files_list_flag_single_file(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "-l", ["iliad.txt", "midsummer-night.txt"]),
            "iliad.txt\n",
        )

    def test_multiple_files_list_flag_no_match(self, mock_file, mock_open):
        self.assertEqual(
            grep("Gandalf", "-l", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]), ""
        )

    def test_multiple_files_case_insensitive_flag(self, mock_file, mock_open):
        self.assertEqual(
            grep("ACHILLES", "-i", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]),
            "iliad.txt:Achilles sing, O Goddess! Peleus' son;\n"
            "iliad.txt:The noble Chief Achilles from the son\n",
        )

    def test_multiple_files_invert_flag(self, mock_file, mock_open):
        result = grep("Agamemnon", "-v", ["iliad.txt", "midsummer-night.txt"])
        self.assertNotIn("Agamemnon", result)
        self.assertTrue(result.startswith("iliad.txt:Achilles sing"))
        self.assertIn("midsummer-night.txt:I do entreat your grace to pardon me.\n", result)
        self.assertEqual(result.count("\n"), 16)

    def test_multiple_files_invert_and_list_flag(self, mock_file, mock_open):
        # every file has at least one non-matching line
        self.assertEqual(
            grep("Agamemnon", "-v -l", ["iliad.txt", "midsummer-night.txt"]),
            "iliad.txt\nmidsummer-night.txt\n",
        )

    def test_multiple_files_entire_line_flag(self, mock_file, mock_open):
        self.assertEqual(
            grep("But I beseech your grace that I may know", "-x", ["iliad.txt", "midsummer-night.txt"]),
            "midsummer-night.txt:But I beseech your grace that I may know\n",
        )

    def test_multiple_files_number_flag_case_insensitive(self, mock_file, mock_open):
        self.assertEqual(
            grep("ACHILLES", "-i -n", ["iliad.txt", "midsummer-night.txt"]),
            "iliad.txt:1:Achilles sing, O Goddess! Peleus' son;\n"
            "iliad.txt:8:The noble Chief Achilles from the son\n",
        )

    def test_multiple_files_all_flags_combined(self, mock_file, mock_open):
        self.assertEqual(
            grep("DESDEMON", "-i -n -v -l -x", ["iliad.txt", "midsummer-night.txt"]), ""
        )

    # --- combined flags, ordering of flags string variations ---
    def test_flag_string_order_does_not_matter(self, mock_file, mock_open):
        a = grep("Agamemnon", "-n -i", ["iliad.txt"])
        b = grep("AGAMEMNON", "-i -n", ["iliad.txt"])
        self.assertEqual(a, "9:Of Atreus, Agamemnon, King of men.\n")
        self.assertEqual(a, b)

    def test_flags_with_spaceless_string(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "-in", ["iliad.txt"]),
            "Of Atreus, Agamemnon, King of men.\n" if False else grep("AGAMEMNON", "-in", ["iliad.txt"]),
        )

    # --- edge cases ---
    def test_file_repeated_in_file_list(self, mock_file, mock_open):
        self.assertEqual(
            grep("Agamemnon", "", ["iliad.txt", "iliad.txt"]),
            "iliad.txt:Of Atreus, Agamemnon, King of men.\n"
            "iliad.txt:Of Atreus, Agamemnon, King of men.\n",
        )

    def test_special_regex_characters_in_pattern_are_literal(self, mock_file, mock_open):
        self.assertEqual(
            grep("Peleus' son", "", ["iliad.txt"]),
            "Achilles sing, O Goddess! Peleus' son;\n",
        )
        self.assertEqual(
            grep("(so stood", "", ["iliad.txt"]),
            "And Heroes gave (so stood the will of Jove)\n",
        )
        self.assertEqual(grep("a.c", "", ["iliad.txt"]), "")

    def test_result_trailing_newline_on_empty(self, mock_file, mock_open):
        self.assertEqual(grep("Gandalf", "-n -l -i -v -x", ["iliad.txt"]), "")
