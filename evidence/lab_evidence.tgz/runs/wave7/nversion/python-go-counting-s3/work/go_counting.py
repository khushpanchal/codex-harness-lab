
WHITE = "W"
BLACK = "B"
NONE = ""


class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        self.board = board
        self.width = len(board[0]) if board else 0
        self.height = len(board)

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not (0 <= x < self.width and 0 <= y < self.height):
            raise ValueError("Invalid coordinate")

        if self.board[y][x] in (WHITE, BLACK):
            return NONE, set()

        empty = {(x, y)}
        stack = [(x, y)]
        neighbours = {WHITE: False, BLACK: False}

        while stack:
            current_x, current_y = stack.pop()
            for next_x, next_y in self._neighbours(current_x, current_y):
                value = self.board[next_y][next_x]
                if value in neighbours:
                    neighbours[value] = True
                elif (next_x, next_y) not in empty:
                    empty.add((next_x, next_y))
                    stack.append((next_x, next_y))

        owner = next(
            (player for player in (WHITE, BLACK) if neighbours[player]),
            NONE,
        )
        return owner, empty

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        result = {WHITE: set(), BLACK: set(), NONE: set()}
        for y in range(self.height):
            for x in range(self.width):
                if self.board[y][x] not in (WHITE, BLACK):
                    owner, coordinates = self.territory(x, y)
                    result[owner] |= coordinates
        return result

    def _neighbours(self, x, y):
        return (
            (next_x, next_y)
            for next_x, next_y in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1))
            if 0 <= next_x < self.width and 0 <= next_y < self.height
        )
