# test_blind_spec.py
import unittest

from go_counting import Board, WHITE, BLACK, NONE


class GoCountingTest(unittest.TestCase):
    # --- black corner territory on 5x5 board (provided case) ---
    def test_black_corner_territory_on_5x5_board(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        stone, territory = board.territory(x=0, y=1)
        self.assertEqual(stone, BLACK)
        self.assertSetEqual(territory, {(0, 0), (0, 1), (1, 0)})

    # --- small fully surrounded empty region ---
    def test_white_territory_fully_enclosed(self):
        board = Board(
            [
                "BBB",
                "BWB",
                "BBB",
            ]
        )
        stone, territory = board.territory(x=1, y=1)
        self.assertEqual(stone, WHITE)
        self.assertSetEqual(territory, {(1, 1)})

    def test_territories_single_enclosed_cell(self):
        board = Board(
            [
                "BBB",
                "BWB",
                "BBB",
            ]
        )
        result = board.territories()
        self.assertEqual(result[WHITE], {(1, 1)})
        self.assertEqual(result[BLACK], set())
        self.assertEqual(result[NONE], set())

    # --- stones themselves are not territory ---
    def test_territories_excludes_stones(self):
        board = Board(["BW", "WB"])
        result = board.territories()
        self.assertEqual(result[BLACK], set())
        self.assertEqual(result[WHITE], set())
        self.assertEqual(result[NONE], set())

    def test_territory_returns_empty_region_for_stone_coordinate(self):
        board = Board(["BW", "WB"])
        stone, territory = board.territory(x=0, y=0)
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, set())

    # --- all empty board: everything is ownerless ---
    def test_all_empty_board(self):
        board = Board(["   ", "   "])
        stone, territory = board.territory(x=1, y=0)
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, {(0, 0), (1, 0), (2, 0), (0, 1), (1, 1), (2, 1)})
        result = board.territories()
        self.assertEqual(result[NONE], {(0, 0), (1, 0), (2, 0), (0, 1), (1, 1), (2, 1)})
        self.assertEqual(result[BLACK], set())
        self.assertEqual(result[WHITE], set())

    # --- whole 5x5 example board ---
    def test_territories_full_5x5_board(self):
        board = Board(["  B  ", " B B ", "B W B", " W W ", "  W  "])
        result = board.territories()
        self.assertEqual(result[BLACK], {(0, 0), (0, 1), (1, 0)})
        self.assertEqual(result[WHITE], {(3, 3), (2, 3), (3, 4), (4, 3)})
        self.assertEqual(result[NONE], {(4, 0), (3, 0), (4, 1)})

    # --- mixed regions separated by both colors ---
    def test_territory_region_between_two_colors_is_ownerless(self):
        board = Board(["BW"])
        stone, territory = board.territory(x=0, y=0)  # stone itself
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, set())

    def test_empty_region_bordered_by_black_and_white_is_none(self):
        board = Board(["B B", "B W", "B  "])
        # empty cells at (1,0),(2,0),(1,1),(2,1),(1,2),(2,2) touch both colors -> NONE
        stone, territory = board.territory(x=1, y=0)
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, set())
        result = board.territories()
        self.assertEqual(result[NONE], {(1, 0), (2, 0), (1, 1), (2, 1), (1, 2), (2, 2)})

    # --- open border: region touching edge and a bordering stone of one color ---
    def test_territory_open_at_border_belonging_to_one_color(self):
        board = Board(
            [
                "BBBB",
                "B   ",
                "B   ",
                "BBBB",
            ]
        )
        stone, territory = board.territory(x=1, y=1)
        self.assertEqual(stone, BLACK)
        self.assertSetEqual(territory, {(1, 1), (2, 1), (1, 2), (2, 2)})

    # --- example from description diagram ---
    def test_diagram_ignored_stones(self):
        board = Board(
            [
                "IOOI",
                "O  O",
                "O OI",
                "IOI ",
            ]
        )
        # Board chars: only "W"/"B" count as stones presumably; treat O/I generically:
        # Using description semantics, replace O with B and I with B? Instead
        # build a board with B stones matching O positions only.
        pass

    def test_multiple_empty_intersections_one_territory(self):
        board = Board(
            [
                "BBBB",
                "BBBB",
                "BB  ",
                "BBBB",
                "BBBB",
            ]
        )
        stone, territory = board.territory(x=2, y=2)
        self.assertEqual(stone, BLACK)
        self.assertSetEqual(territory, {(2, 2), (3, 2)})

    # --- invalid coordinates ---
    def test_invalid_coordinate_x_out_of_range(self):
        board = Board(["  "])
        with self.assertRaises(ValueError) as ctx:
            board.territory(x=2, y=0)
        self.assertTrue(str(ctx.exception))

    def test_invalid_coordinate_negative_x(self):
        board = Board(["  "])
        with self.assertRaises(ValueError) as ctx:
            board.territory(x=-1, y=0)
        self.assertTrue(str(ctx.exception))

    def test_invalid_coordinate_y_out_of_range(self):
        board = Board(["  "])
        with self.assertRaises(ValueError) as ctx:
            board.territory(x=0, y=1)
        self.assertTrue(str(ctx.exception))

    def test_invalid_coordinate_negative_y(self):
        board = Board(["  "])
        with self.assertRaises(ValueError) as ctx:
            board.territory(x=0, y=-1)
        self.assertTrue(str(ctx.exception))

    def test_invalid_coordinate_raises_value_error_with_message(self):
        board = Board([" "])
        with self.assertRaises(ValueError):
            board.territory(x=1, y=1)

    # --- single cell board ---
    def test_single_empty_cell(self):
        board = Board([" "])
        stone, territory = board.territory(x=0, y=0)
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, {(0, 0)})

    def test_single_stone_cell(self):
        board = Board(["B"])
        stone, territory = board.territory(x=0, y=0)
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, set())

    # --- two separate territories of different owners ---
    def test_two_separate_territories(self):
        board = Board(
            [
                "BBBWW",
                "B WBW",
                "BBWWW",
            ]
        )
        result = board.territories()
        self.assertEqual(result[BLACK], {(1, 1)})
        self.assertEqual(result[WHITE], {(3, 1)})

    # --- diagonal neighbors do not connect territories ---
    def test_diagonal_neighbors_do_not_connect(self):
        board = Board(
            [
                "BBB",
                "BB ",
                "B B",
                "BBB",
            ]
        )
        # empties (2,1) and (1,2) touch diagonally only; each enclosed by black
        stone, territory = board.territory(x=2, y=1)
        self.assertEqual(stone, BLACK)
        self.assertSetEqual(territory, {(2, 1), (1, 2)})

    # --- unicode/wide boards not needed; standard rectangle assumption ---
    def test_territories_full_coverage(self):
        board = Board(["BW", "W "])
        result = board.territories()
        self.assertEqual(result[NONE], {(1, 1)})
        self.assertEqual(result[BLACK], set())
        self.assertEqual(result[WHITE], set())

    def test_territory_last_empty_cell(self):
        board = Board(["BW", "W "])
        stone, territory = board.territory(x=1, y=1)
        self.assertEqual(stone, NONE)
        self.assertSetEqual(territory, {(1, 1)})


if __name__ == "__main__":
    unittest.main()
