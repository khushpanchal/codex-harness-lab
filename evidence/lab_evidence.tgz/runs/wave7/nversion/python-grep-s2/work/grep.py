def grep(pattern, flags, files):
    if isinstance(flags, str):
        enabled = {flag for group in flags.split() for flag in group.lstrip("-")}
    else:
        enabled = {flag.lstrip("-") for flag in flags}

    ignore_case = "i" in enabled
    line_numbers = "n" in enabled
    files_with_matches = "l" in enabled
    invert = "v" in enabled
    entire_line = "x" in enabled

    def matches(line):
        left = line.casefold() if ignore_case else line
        right = pattern.casefold() if ignore_case else pattern
        if entire_line:
            return left == right
        return right in left

    output = []
    for filename in files:
        found_in_file = False
        with open(filename) as current_file:
            for number, line in enumerate(current_file, start=1):
                line = line.rstrip("\n")
                if matches(line) == invert:
                    continue

                found_in_file = True
                if files_with_matches:
                    break

                result = line
                if line_numbers:
                    result = f"{number}:{result}"
                if len(files) > 1:
                    result = f"{filename}:{result}"
                output.append(result)

        if files_with_matches and found_in_file:
            output.append(filename)

    return "".join(f"{line}\n" for line in output)
