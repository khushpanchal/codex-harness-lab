import io
import unittest

from grep import grep
from unittest import mock

FILE_TEXT = {
    "iliad.txt": """Achilles sing, O Goddess! Peleus' son;
His wrath pernicious, who ten thousand woes
Caused to Achaia's host, sent many a soul
Illustrious into Ades premature,
And Heroes gave (so stood the will of Jove)
To dogs and to all ravening fowls a prey,
When fierce dispute had separated once
The noble Chief Achilles from the son
Of Atreus, Agamemnon, King of men.\n""",
    "midsummer-night.txt": """I do entreat your grace to pardon me.
I know not by what power I am made bold,
Nor how it may concern my modesty,
In such a presence here to plead my thoughts;
But I beseech your grace that I may know
The worst that may befall me in this case,
If I refuse to wed Demetrius.\n""",
    "paradise-lost.txt": """Of Mans First Disobedience, and the Fruit
Of that Forbidden Tree, whose mortal tast
Brought Death into the World, and all our woe,
With loss of Eden, till one greater Man
Restore us, and regain the blissful Seat,
Sing Heav'nly Muse, that on the secret top
Of Oreb, or of Sinai, didst inspire
That Shepherd, who first taught the chosen Seed\n""",
}


def open_mock(fname, *args, **kwargs):
    try:
        return io.StringIO(FILE_TEXT[fname])
    except KeyError:
        raise RuntimeError(
            "Expected one of {0!r}: got {1!r}".format(list(FILE_TEXT.keys()), fname)
        )


@mock.patch("grep.open", name="open", side_effect=open_mock, create=True)
@mock.patch("io.StringIO", name="StringIO", wraps=io.StringIO)
class GrepTest(unittest.TestCase):
    def assertMultiLineEqual(self, first, second, msg=None):
        unittest.TestCase.assertMultiLineEqual(self, first, second, msg)

    # Single file, no flags
    def test_one_file_one_match_no_flags(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("Agamemnon", "", ["iliad.txt"]), "Of Atreus, Agamemnon, King of men.\n"
        )

    def test_one_file_one_match_case_insensitive(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("AGAMEMNON", "-i", ["iliad.txt"]),
            "Of Atreus, Agamemnon, King of men.\n",
        )

    def test_one_file_no_matches_no_flags(self, mock_file, mock_open):
        self.assertEqual(grep("Goethe", "", ["iliad.txt"]), "")

    def test_one_file_multiple_matches_no_flags(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("may", "", ["midsummer-night.txt"]),
            "Nor how it may concern my modesty,\n"
            "But I beseech your grace that I may know\n"
            "The worst that may befall me in this case,\n",
        )

    # Multiple files
    def test_multiple_files_one_match_no_flags(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("Agamemnon", "", ["iliad.txt", "midsummer-night.txt"]),
            "iliad.txt:Of Atreus, Agamemnon, King of men.\n",
        )

    def test_multiple_files_several_matches_no_flags(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("may", "", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]),
            "midsummer-night.txt:Nor how it may concern my modesty,\n"
            "midsummer-night.txt:But I beseech your grace that I may know\n"
            "midsummer-night.txt:The worst that may befall me in this case,\n",
        )

    def test_multiple_files_matches_in_multiple_files(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("who", "", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]),
            "iliad.txt:His wrath pernicious, who ten thousand woes\n"
            "iliad.txt:The noble Chief Achilles from the son\n"
            "iliad.txt:Of Atreus, Agamemnon, King of men.\n"
            "paradise-lost.txt:Of that Forbidden Tree, whose mortal tast\n"
            "paradise-lost.txt:Sing Heav'nly Muse, that on the secret top\n"
            "paradise-lost.txt:That Shepherd, who first taught the chosen Seed\n",
        )

    # -n flag
    def test_one_file_one_match_number_flag(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("Forbidden", "-n", ["paradise-lost.txt"]),
            "2:Of that Forbidden Tree, whose mortal tast\n",
        )

    def test_one_file_multiple_matches_number_flag(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("may", "-n", ["midsummer-night.txt"]),
            "3:Nor how it may concern my modesty,\n"
            "5:But I beseech your grace that I may know\n"
            "6:The worst that may befall me in this case,\n",
        )

    def test_one_file_no_matches_number_flag(self, mock_file, mock_open):
        self.assertEqual(grep("Gandalf", "-n", ["iliad.txt"]), "")

    def test_multiple_files_one_match_number_flag(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("Forbidden", "-n", ["iliad.txt", "paradise-lost.txt"]),
            "paradise-lost.txt:2:Of that Forbidden Tree, whose mortal tast\n",
        )

    def test_multiple_files_several_matches_number_flag(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("may", "-n", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]),
            "midsummer-night.txt:3:Nor how it may concern my modesty,\n"
            "midsummer-night.txt:5:But I beseech your grace that I may know\n"
            "midsummer-night.txt:6:The worst that may befall me in this case,\n",
        )

    def test_multiple_files_matches_in_multiple_files_number_flag(
        self, mock_file, mock_open
    ):
        self.assertMultiLineEqual(
            grep(
                "who",
                "-n",
                ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"],
            ),
            "iliad.txt:2:His wrath pernicious, who ten thousand woes\n"
            "iliad.txt:8:The noble Chief Achilles from the son\n"
            "iliad.txt:9:Of Atreus, Agamemnon, King of men.\n"
            "paradise-lost.txt:2:Of that Forbidden Tree, whose mortal tast\n"
            "paradise-lost.txt:6:Sing Heav'nly Muse, that on the secret top\n"
            "paradise-lost.txt:8:That Shepherd, who first taught the chosen Seed\n",
        )

    # -l flag
    def test_one_file_match_prints_filename_only(self, mock_file, mock_open):
        self.assertMultiLineEqual(grep("Agamemnon", "-l", ["iliad.txt"]), "iliad.txt\n")

    def test_one_file_no_match_prints_nothing(self, mock_file, mock_open):
        self.assertEqual(grep("Gandalf", "-l", ["iliad.txt"]), "")

    def test_multiple_files_match_prints_filenames_only(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("Agamemnon", "-l", ["iliad.txt", "midsummer-night.txt"]),
            "iliad.txt\n",
        )

    def test_multiple_files_multiple_matches_prints_filenames_only(
        self, mock_file, mock_open
    ):
        self.assertMultiLineEqual(
            grep("may", "-l", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]),
            "midsummer-night.txt\n",
        )

    def test_multiple_files_several_files_match_prints_filenames_only(
        self, mock_file, mock_open
    ):
        self.assertMultiLineEqual(
            grep("who", "-l", ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"]),
            "iliad.txt\nparadise-lost.txt\n",
        )

    def test_multiple_files_no_match_prints_nothing(self, mock_file, mock_open):
        self.assertEqual(grep("Gandalf", "-l", ["iliad.txt", "midsummer-night.txt"]), "")

    # -i flag
    def test_one_file_match_case_insensitive(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("AGAMEMNON", "-i", ["iliad.txt"]),
            "Of Atreus, Agamemnon, King of men.\n",
        )

    def test_one_file_multiple_matches_case_insensitive(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("ACHILLES", "-i", ["iliad.txt"]),
            "Achilles sing, O Goddess! Peleus' son;\n"
            "The noble Chief Achilles from the son\n",
        )

    def test_multiple_files_matches_case_insensitive(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep(
                "ACHILLES",
                "-i",
                ["iliad.txt", "midsummer-night.txt", "paradise-lost.txt"],
            ),
            "iliad.txt:Achilles sing, O Goddess! Peleus' son;\n"
            "iliad.txt:The noble Chief Achilles from the son\n",
        )

    # -v flag
    def test_one_file_match_invert(self, mock_file, mock_open):
        expected = "\n".join(
            line + "\n"
            for line in FILE_TEXT["iliad.txt"].splitlines()
            if "Agamemnon" not in line
        )
        self.assertMultiLineEqual(grep("Agamemnon", "-v", ["iliad.txt"]), expected)

    def test_one_file_no_match_invert(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("Agamemnon", "-v", ["midsummer-night.txt"]),
            FILE_TEXT["midsummer-night.txt"],
        )

    def test_multiple_files_match_invert(self, mock_file, mock_open):
        expected = "".join(
            "iliad.txt:" + line + "\n"
            for line in FILE_TEXT["iliad.txt"].splitlines()
            if "Agamemnon" not in line
        )
        self.assertMultiLineEqual(
            grep("Agamemnon", "-v", ["iliad.txt", "midsummer-night.txt"]), expected
        )

    # -x flag
    def test_one_file_match_entire_line(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("Of Atreus, Agamemnon, King of men.", "-x", ["iliad.txt"]),
            "Of Atreus, Agamemnon, King of men.\n",
        )

    def test_one_file_no_match_entire_line(self, mock_file, mock_open):
        self.assertEqual(grep("Agamemnon", "-x", ["iliad.txt"]), "")

    def test_multiple_files_match_entire_line(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep(
                "But I beseech your grace that I may know",
                "-x",
                ["iliad.txt", "midsummer-night.txt"],
            ),
            "midsummer-night.txt:But I beseech your grace that I may know\n",
        )

    def test_one_file_match_entire_line_case_insensitive(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("OF ATREUS, AGAMEMNON, KING OF MEN.", "-x", "-i", ["iliad.txt"]),
            "Of Atreus, Agamemnon, King of men.\n",
        )

    # Combined flags
    def test_number_and_invert_flags(self, mock_file, mock_open):
        expected = "".join(
            "{}:{}\n".format(i, line)
            for i, line in enumerate(FILE_TEXT["iliad.txt"].splitlines(), 1)
            if "Agamemnon" not in line
        )
        self.assertMultiLineEqual(
            grep("Agamemnon", "-n -v", ["iliad.txt"]), expected
        )

    def test_number_and_list_flags(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("Agamemnon", "-n -l", ["iliad.txt"]), "iliad.txt\n"
        )

    def test_list_and_invert_flags(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("Agamemnon", "-l -v", ["iliad.txt", "midsummer-night.txt"]),
            "iliad.txt\nmidsummer-night.txt\n",
        )

    def test_case_insensitive_with_invert(self, mock_file, mock_open):
        expected = "".join(
            "midsummer-night.txt:" + line + "\n"
            for line in FILE_TEXT["midsummer-night.txt"].splitlines()
            if "demetrius" not in line.lower()
        )
        self.assertMultiLineEqual(
            grep("DEMETRIUS", "-i -v", ["midsummer-night.txt"]), expected
        )

    def test_invert_whole_line_match(self, mock_file, mock_open):
        expected = "".join(
            line + "\n"
            for line in FILE_TEXT["midsummer-night.txt"].splitlines()
            if line != "If I refuse to wed Demetrius."
        )
        self.assertMultiLineEqual(
            grep("If I refuse to wed Demetrius.", "-x -v", ["midsummer-night.txt"]),
            expected,
        )

    # Files read in order specified
    def test_files_searched_in_order_given(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("who", "-l", ["paradise-lost.txt", "iliad.txt"]),
            "paradise-lost.txt\niliad.txt\n",
        )

    # Special / edge patterns
    def test_pattern_with_special_regex_chars_treated_as_fixed_string(
        self, mock_file, mock_open
    ):
        self.assertMultiLineEqual(
            grep("Peleus' son;", "", ["iliad.txt"]),
            "Achilles sing, O Goddess! Peleus' son;\n",
        )

    def test_pattern_matching_punctuation(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("(", "", ["iliad.txt"]),
            "And Heroes gave (so stood the will of Jove)\n",
        )

    def test_case_insensitive_whole_line_with_line_numbers_multiple_files(
        self, mock_file, mock_open
    ):
        self.assertMultiLineEqual(
            grep(
                "IF I REFUSE TO WED DEMETRIUS.",
                "-n -i -x",
                ["iliad.txt", "midsummer-night.txt"],
            ),
            "midsummer-night.txt:7:If I refuse to wed Demetrius.\n",
        )

    def test_multiple_files_one_match_number_flag_no_match_in_one_file(
        self, mock_file, mock_open
    ):
        self.assertMultiLineEqual(
            grep("Demetrius", "-n", ["iliad.txt", "midsummer-night.txt"]),
            "midsummer-night.txt:7:If I refuse to wed Demetrius.\n",
        )

    def test_list_flag_deduplicates_filename(self, mock_file, mock_open):
        self.assertMultiLineEqual(
            grep("the", "-l", ["iliad.txt", "midsummer-night.txt"]),
            "iliad.txt\nmidsummer-night.txt\n",
        )


if __name__ == "__main__":
    unittest.main()
