
BLACK = "B"
WHITE = "W"
NONE = ""


class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        self.board = board
        self.height = len(board)
        self.width = len(board[0]) if board else 0

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not 0 <= x < self.width or not 0 <= y < self.height:
            raise ValueError("Invalid coordinate")

        stone = self.board[y][x]
        if stone in (BLACK, WHITE):
            return stone, set()

        region = set()
        boundary = set()
        pending = [(x, y)]

        while pending:
            point = pending.pop()
            if point in region:
                continue
            region.add(point)
            point_x, point_y = point

            for neighbor in self.neighbors(point_x, point_y):
                stone = self.board[neighbor[1]][neighbor[0]]
                if stone == " ":
                    pending.append(neighbor)
                else:
                    boundary.add(stone)

        if len(boundary) == 1:
            owner = boundary.pop()
        else:
            owner = NONE
        return owner, region

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        result = {BLACK: set(), WHITE: set(), NONE: set()}
        seen = set()

        for y in range(self.height):
            for x in range(self.width):
                if self.board[y][x] != NONE or (x, y) in seen:
                    continue
                owner, region = self.territory(x, y)
                result[owner].update(region)
                seen.update(region)

        return result

    def neighbors(self, x, y):
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            neighbor_x = x + dx
            neighbor_y = y + dy
            if 0 <= neighbor_x < self.width and 0 <= neighbor_y < self.height:
                yield neighbor_x, neighbor_y
