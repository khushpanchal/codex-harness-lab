BLACK = "B"
WHITE = "W"
NONE = ""
EMPTY = " "


class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        self.board = board
        self.height = len(board)
        self.width = len(board[0]) if self.height else 0

        if any(len(row) != self.width for row in self.board):
            raise ValueError("All board rows must have the same length")

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on the board"""
        if not (0 <= x < self.width and 0 <= y < self.height):
            raise ValueError("Invalid coordinate")

        if self.board[y][x] != EMPTY:
            return NONE, set()

        owner = None
        territory = set()
        to_visit = [(x, y)]
        visited = {(x, y)}

        while to_visit:
            point = to_visit.pop()
            territory.add(point)

            for neighbor in self._neighbors(point):
                stone = self.board[neighbor[1]][neighbor[0]]
                if stone == BLACK:
                    owner = NONE if owner == WHITE else BLACK
                elif stone == WHITE:
                    owner = NONE if owner == BLACK else WHITE
                elif neighbor not in visited:
                    visited.add(neighbor)
                    to_visit.append(neighbor)

        return owner or NONE, territory

    def territories(self):
        """Find the owners and the territories of the whole board"""
        result = {BLACK: set(), WHITE: set(), NONE: set()}

        for y in range(self.height):
            for x in range(self.width):
                if self.board[y][x] == EMPTY:
                    owner, territory = self.territory(x, y)
                    result[owner].update(territory)

        return result

    def _neighbors(self, point):
        x, y = point
        candidates = ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1))
        return (
            candidate
            for candidate in candidates
            if 0 <= candidate[0] < self.width and 0 <= candidate[1] < self.height
        )
