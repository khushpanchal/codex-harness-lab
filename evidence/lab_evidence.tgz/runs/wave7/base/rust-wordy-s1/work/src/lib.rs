#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Operation {
    Add,
    Subtract,
    Multiply,
    Divide,
}

fn parse_number(word: &str) -> Option<i32> {
    word.parse::<i32>().ok()
}

fn parse_operation(words: &[&str], start: usize) -> Option<(Operation, usize)> {
    let words = words.get(start..)?;
    let consumed = match words.first()? {
        &"plus" => 1,
        &"minus" => 1,
        &"multiplied" if words.get(1) == Some(&"by") => 2,
        &"divided" if words.get(1) == Some(&"by") => 2,
        _ => return None,
    };
    Some((operation_for(words[0]), consumed))
}

fn operation_for(word: &str) -> Operation {
    match word {
        "plus" => Operation::Add,
        "minus" => Operation::Subtract,
        "multiplied" => Operation::Multiply,
        "divided" => Operation::Divide,
        _ => Operation::Add,
    }
}

fn checked(lhs: i32, rhs: i32, operation: Operation) -> Option<i32> {
    match operation {
        Operation::Add => lhs.checked_add(rhs),
        Operation::Subtract => lhs.checked_sub(rhs),
        Operation::Multiply => lhs.checked_mul(rhs),
        Operation::Divide => lhs.checked_div(rhs),
    }
}

pub fn answer(command: &str) -> Option<i32> {
    let command = command.strip_suffix('?').unwrap_or(command);
    let words: Vec<_> = command.split_whitespace().collect();
    if words.first() != Some(&"What") || words.get(1) != Some(&"is") {
        return None;
    }

    let mut index = 2;
    let mut value = parse_number(*words.get(index)?)?;
    index += 1;
    while index < words.len() {
        let (operation, operation_words) = parse_operation(&words, index)?;
        index += operation_words;
        let rhs = parse_number(*words.get(index)?)?;
        index += 1;
        value = checked(value, rhs, operation)?;
    }

    Some(value)
}
