def grep(pattern, flags, files):
    flag_set = set(flags)
    case_insensitive = "-i" in flag_set
    invert = "-v" in flag_set
    whole_line = "-x" in flag_set

    if case_insensitive:
        pattern = pattern.lower()

    matches = []
    for filename in files:
        file_matches = []
        with open(filename) as file:
            lines = iter(file)
            line_number = 0
            while True:
                line = next(lines, None)
                if line is None:
                    break
                line_number += 1
                content = line.rstrip("\n")
                haystack = content.lower() if case_insensitive else content
                is_match = haystack == pattern if whole_line else pattern in haystack
                if is_match != invert:
                    file_matches.append((line_number, content))

        if not file_matches:
            continue

        if "-l" in flag_set:
            matches.append(filename)
        else:
            include_filename = len(files) > 1
            for line_number, content in file_matches:
                if include_filename:
                    content = f"{filename}:{content}"
                if "-n" in flag_set:
                    prefix = f"{line_number}"
                    if include_filename:
                        prefix = f"{filename}:{prefix}"
                    content = f"{prefix}:{content}"
                matches.append(content)

    return "".join(f"{match}\n" for match in matches)
