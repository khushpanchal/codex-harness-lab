class School:
    def __init__(self):
        self._roster = {}

    def add_student(self, name, grade):
        if any(name in students for students in self._roster.values()):
            return False
        students = self._roster.setdefault(grade, [])
        students.append(name)
        students.sort()
        return True

    def roster(self):
        return [
            name
            for grade in sorted(self._roster.copy())
            for name in self._roster[grade]
        ]

    def grade(self, grade_number):
        return self._roster.get(grade_number, []).copy()

    def added(self):
        return True
