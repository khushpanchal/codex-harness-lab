def _parse(hand):
    cards = hand.split()
    if len(cards) != 5:
        raise ValueError("a poker hand must contain five cards")

    values = {
        "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
        "10": 10, "T": 10, "J": 11, "Q": 12, "K": 13, "A": 14,
    }
    ranks = []
    suits = []
    for card in cards:
        if len(card) < 2:
            raise ValueError(f"invalid card: {card}")
        value, suit = card[:-1], card[-1]
        if value not in values or suit not in "CDHS":
            raise ValueError(f"invalid card: {card}")
        ranks.append(values[value])
        suits.append(suit)
    if len(set(cards)) != 5:
        raise ValueError("duplicate card in hand")
    return ranks, suits


def _rank_hand(hand):
    ranks, suits = _parse(hand)
    ranks_desc = sorted(ranks, reverse=True)
    counts = sorted(((ranks.count(rank), rank) for rank in set(ranks)), reverse=True)
    grouped_ranks = [rank for count, rank in counts]

    straight_high = None
    if len(counts) == 5:
        if ranks_desc[0] - ranks_desc[-1] == 4:
            straight_high = ranks_desc[0]
        elif ranks_desc == [14, 5, 4, 3, 2]:
            straight_high = 5

    flush = len(set(suits)) == 1
    if straight_high is not None and flush:
        category = 8
    elif counts[0][0] == 4:
        category = 7
    elif counts[0][0] == 3 and counts[1][0] == 2:
        category = 6
    elif flush:
        category = 5
    elif straight_high is not None:
        category = 4
    elif counts[0][0] == 3:
        category = 3
    elif counts[0][0] == 2 and counts[1][0] == 2:
        category = 2
    elif counts[0][0] == 2:
        category = 1
    else:
        category = 0

    if category == 8 or category == 4:
        significant_ranks = [straight_high]
    elif category in (5, 0):
        significant_ranks = ranks_desc
    else:
        significant_ranks = grouped_ranks

    return category, significant_ranks


def best_hands(hands):
    if not hands:
        return []
    best_rank = max(_rank_hand(hand) for hand in hands)
    return [hand for hand in hands if _rank_hand(hand) == best_rank]
