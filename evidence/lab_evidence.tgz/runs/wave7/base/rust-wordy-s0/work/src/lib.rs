pub fn answer(command: &str) -> Option<i32> {
    let command = command.strip_prefix("What is ")?;
    let command = command
        .strip_suffix('?')
        .or_else(|| command.strip_suffix('.'))
        .unwrap_or(command);
    let tokens: Vec<_> = command.split_whitespace().collect();
    let mut tokens = tokens.iter().copied();

    let mut value = parse_number(tokens.next()?)?;

    if tokens.next().is_none() {
        return Some(value);
    }

    loop {
        match tokens.next()? {
            "plus" => value = value.checked_add(next_operand(&mut tokens)?)?,
            "minus" => value = value.checked_sub(next_operand(&mut tokens)?)?,
            "multiplied" => {
                expect(&mut tokens, "by")?;
                value = value.checked_mul(next_operand(&mut tokens)?)?;
            }
            "divided" => {
                expect(&mut tokens, "by")?;
                value = value.checked_div(next_operand(&mut tokens)?)?;
            }
            "raised" => {
                expect(&mut tokens, "to")?;
                expect(&mut tokens, "the")?;
                let exponent = parse_ordinal(tokens.next()?)?;
                expect(&mut tokens, "power")?;
                let exponent = u32::try_from(exponent).ok()?;
                value = power(value, exponent)?;
            }
            _ => return None,
        }

        if tokens.next().is_none() {
            return Some(value);
        }
    }
}

fn next_operand<'a, I>(tokens: &mut I) -> Option<i32>
where
    I: Iterator<Item = &'a str>,
{
    parse_number(tokens.next()?)
}

fn expect<'a, I>(tokens: &mut I, expected: &'a str) -> Option<()>
where
    I: Iterator<Item = &'a str>,
{
    if tokens.next()? == expected {
        Some(())
    } else {
        None
    }
}

fn parse_number(token: &str) -> Option<i32> {
    token.parse().ok()
}

fn parse_ordinal(token: &str) -> Option<i32> {
    let digits = token.strip_suffix(['s', 't', 'n', 'r', 'd', 'h'])?;
    digits.parse().ok()
}

fn power(value: i32, exponent: u32) -> Option<i32> {
    match (value, exponent) {
        (0, 32..) => Some(0),
        (1, 32..) => Some(1),
        (-1, 32..) => Some(if exponent % 2 == 0 { 1 } else { -1 }),
        (_, 32..) => None,
        _ => value.checked_pow(exponent),
    }
}
