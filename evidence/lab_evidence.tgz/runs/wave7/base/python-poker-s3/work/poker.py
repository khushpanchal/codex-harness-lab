_RANKS = {
    "2": 2,
    "3": 3,
    "4": 4,
    "5": 5,
    "6": 6,
    "7": 7,
    "8": 8,
    "9": 9,
    "10": 10,
    "J": 11,
    "Q": 12,
    "K": 13,
    "A": 14,
}
_SUITS = {"S", "H", "D", "C"}


def _parse(hand):
    cards = []
    for card in hand.split():
        if not 2 <= len(card) <= 3:
            raise ValueError(f"invalid card: {card!r}")
        rank_text, suit = card[:-1], card[-1]
        if rank_text.upper() not in _RANKS or suit.upper() not in _SUITS:
            raise ValueError(f"invalid card: {card!r}")
        cards.append((_RANKS[rank_text.upper()], suit.upper()))
    if len(cards) != 5:
        raise ValueError("a hand must contain exactly five cards")
    if len({(rank, suit) for rank, suit in cards}) != 5:
        raise ValueError("a hand must not contain duplicate cards")
    return cards


def _rank_counts(cards):
    counts = {}
    for rank, _ in cards:
        counts[rank] = counts.get(rank, 0) + 1
    return sorted(counts.items(), key=lambda item: (-item[1], -item[0]))


def _straight(rank_set):
    if len(rank_set) != 5:
        return None
    ordered = sorted(rank_set)
    if ordered[-1] - ordered[0] == 4:
        return ordered[-1]
    # A-2-3-4-5 counts as a straight, with five as its high card.
    if ordered == [2, 3, 4, 5, 14]:
        return 5
    return None


def _category(cards):
    ranks = [rank for rank, _ in cards]
    rank_set = set(ranks)
    counts = _rank_counts(cards)
    flush = len({suit for _, suit in cards}) == 1
    straight_high = _straight(rank_set)

    if flush and straight_high:
        return (8, straight_high)
    if counts[0][1] == 4:
        return (7, counts[0][0], counts[1][0])
    if counts[0][1] == 3 and counts[1][1] == 2:
        return (6, counts[0][0], counts[1][0])
    if flush:
        return (5, tuple(sorted(ranks, reverse=True)))
    if straight_high:
        return (4, straight_high)
    if counts[0][1] == 3:
        return (3, counts[0][0], tuple(r for r, c in counts[1:] for _ in range(c)))
    if counts[0][1] == 2 and counts[1][1] == 2:
        return (2, counts[0][0], counts[1][0], counts[2][0])
    if counts[0][1] == 2:
        return (1, counts[0][0], tuple(r for r, c in counts[1:] for _ in range(c)))
    return (0, tuple(sorted(ranks, reverse=True)))


def best_hands(hands):
    if not hands:
        return []
    parsed = [(hand, _parse(hand)) for hand in hands]
    best = max(_category(cards) for _, cards in parsed)
    return [hand for hand, cards in parsed if _category(cards) == best]
