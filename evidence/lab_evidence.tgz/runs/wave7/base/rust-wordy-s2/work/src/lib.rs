pub fn answer(command: &str) -> Option<i32> {
    let command = command.strip_suffix('?')?;
    let command = command.strip_prefix("What is ")?;

    // An empty expression, or whitespace-only padding, has no valid value.
    if command.trim().is_empty() {
        return None;
    }

    let mut tokens = command.split_whitespace();
    let mut value = parse_number(tokens.next()?)?;

    loop {
        let Some(operator) = tokens.next() else {
            return Some(value);
        };

        if operator == "multiplied" {
            if tokens.next()? != "by" {
                return None;
            }
            value = value.checked_mul(parse_number(tokens.next()?)?)?;
            continue;
        }

        if operator == "divided" {
            if tokens.next()? != "by" {
                return None;
            }
            let divisor = parse_number(tokens.next()?)?;
            value = value.checked_div(divisor)?;
            continue;
        }

        match operator {
            "plus" => value = value.checked_add(parse_number(tokens.next()?)?)?,
            "minus" => value = value.checked_sub(parse_number(tokens.next()?)?)?,
            _ => return None,
        }
    }
}

fn parse_number(token: &str) -> Option<i32> {
    token.parse().ok()
}
