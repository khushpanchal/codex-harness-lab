class School:
    def __init__(self):
        self._students = {}
        self._last_add_succeeded = False

    def add_student(self, name, grade):
        names = self._students.setdefault(grade, [])
        self._last_add_succeeded = name not in names
        if self._last_add_succeeded:
            names.append(name)
        return self._last_add_succeeded

    def roster(self):
        return [
            name
            for grade in sorted(self._students)
            for name in self.grade(grade)
        ]

    def grade(self, grade_number):
        return sorted(self._students.get(grade_number, []))

    def added(self):
        return self._last_add_succeeded
