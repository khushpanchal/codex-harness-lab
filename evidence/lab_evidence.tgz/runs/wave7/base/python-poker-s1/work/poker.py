def best_hands(hands):
    pass
from itertools import combinations


CATEGORY_NAMES = (
    "high card",
    "one pair",
    "two pairs",
    "three of a kind",
    "straight",
    "flush",
    "full house",
    "four of a kind",
    "straight flush",
)


def _rank_value(rank):
    return "23456789TJQKA".index(rank) + 2


def _categories_for_five(cards):
    """Return all categories to which a five-card hand belongs.

    Each category is represented by a comparable tuple, so lexicographic
    comparison handles both the category and its tie-breaking ranks.
    """
    ranks = sorted((_rank_value(card[0]) for card in cards), reverse=True)
    suits = {card[1] for card in cards}
    grouped = {}
    for rank in ranks:
        grouped[rank] = grouped.get(rank, 0) + 1

    groups = sorted(grouped.items(), key=lambda item: (item[1], item[0]), reverse=True)
    group_signature = tuple(rank for rank, count in groups for _ in range(count))
    group_shape = tuple(count for _, count in groups)

    is_flush = len(suits) == 1
    is_straight = False
    straight_high = None
    if len(grouped) == 5:
        if ranks[0] - ranks[-1] == 4:
            is_straight = True
            straight_high = ranks[0]
        # The ace-low wheel is A-5-4-3-2, with five as its high card.
        elif ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            straight_high = 5

    categories = []

    if group_shape == (4, 1):
        categories.append((7, group_signature))
    elif group_shape == (3, 2):
        categories.append((6, group_signature))
    elif group_shape == (3, 1, 1):
        categories.append((3, group_signature))
    elif group_shape == (2, 2, 1):
        categories.append((2, group_signature))
    elif group_shape == (2, 1, 1, 1):
        categories.append((1, group_signature))
    else:
        categories.append((0, group_signature))

    if is_flush:
        categories.append((5, tuple(ranks)))
    if is_straight:
        categories.append((4, (straight_high,)))
        if is_flush:
            categories.append((8, (straight_high,)))

    return categories


def best_hands(hands):
    if not hands:
        return []

    def evaluate(hand):
        cards = hand.split()
        if len(cards) < 5:
            raise ValueError("a poker hand must contain at least five cards")
        possible = (
            _categories_for_five(cards)
            if len(cards) == 5
            else [category for choice in combinations(cards, 5) for category in _categories_for_five(choice)]
        )
        return max(possible)

    evaluated = [(evaluate(hand), hand) for hand in hands]
    best_value = max(value for value, _ in evaluated)
    return [hand for value, hand in evaluated if value == best_value]
