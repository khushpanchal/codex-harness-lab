#[derive(Clone, Copy)]
enum Operation {
    Plus,
    Minus,
    Times,
    DividedBy,
    #[cfg(feature = "exponentials")]
    Power,
}

pub fn answer(command: &str) -> Option<i32> {
    let command = command.strip_prefix("What is ")?;
    let command = command.strip_suffix('?').unwrap_or(command);
    if command.is_empty() {
        return None;
    }

    let mut words = command.split_whitespace();
    let mut value = parse_number(words.next()?)?;

    while let Some(operator) = words.next() {
        let operation = match operator {
            "plus" => Operation::Plus,
            "minus" => Operation::Minus,
            "multiplied" => {
                if words.next()? != "by" {
                    return None;
                }
                Operation::Times
            }
            "divided" => {
                if words.next()? != "by" {
                    return None;
                }
                Operation::DividedBy
            }
            #[cfg(feature = "exponentials")]
            "raised" => {
                for expected in ["to", "the"] {
                    if words.next()? != expected {
                        return None;
                    }
                }
                if !is_ordinal(words.next()?) || words.next()? != "power" {
                    return None;
                }
                Operation::Power
            }
            _ => return None,
        };

        let rhs = parse_number(words.next()?)?;
        value = match operation {
            Operation::Plus => value.checked_add(rhs)?,
            Operation::Minus => value.checked_sub(rhs)?,
            Operation::Times => value.checked_mul(rhs)?,
            Operation::DividedBy => value.checked_div(rhs)?,
            #[cfg(feature = "exponentials")]
            Operation::Power => checked_power(value, rhs)?,
        };
    }

    Some(value)
}

fn parse_number(word: &str) -> Option<i32> {
    if word.is_empty() {
        return None;
    }
    let digits = word.strip_prefix('-').unwrap_or(word);
    if digits.is_empty() || !digits.bytes().all(|byte| byte.is_ascii_digit()) {
        return None;
    }
    word.parse().ok()
}

#[cfg(feature = "exponentials")]
fn is_ordinal(word: &str) -> bool {
    let split = word.find(|byte: char| !byte.is_ascii_digit());
    if let Some(split) = split {
        let (digits, suffix) = word.split_at(split);
        if digits.is_empty() {
            return false;
        }
        let Some(last) = digits.chars().next_back().and_then(|c| c.to_digit(10)) else {
            return false;
        };
        let expected = match last {
            1 => "st",
            2 => "nd",
            3 => "rd",
            _ => "th",
        };
        return suffix == expected;
    }
    false
}

#[cfg(feature = "exponentials")]
fn checked_power(base: i32, exponent: i32) -> Option<i32> {
    if exponent < 0 {
        return None;
    }
    let mut result: i32 = 1;
    let mut factor: i32 = base;
    let mut remaining: i32 = exponent;
    while remaining > 0 {
        if remaining % 2 == 1 {
            result = result.checked_mul(factor)?;
        }
        remaining /= 2;
        if remaining > 0 {
            factor = factor.checked_mul(factor)?;
        }
    }
    Some(result)
}
