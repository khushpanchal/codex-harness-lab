def grep(pattern, flags, files):
    flags = {
        letter
        for flag in flags.split()
        for letter in flag.removeprefix("-")
    }
    case_insensitive = "i" in flags
    invert = "v" in flags
    whole_line = "x" in flags
    line_numbers = "n" in flags
    names_only = "l" in flags
    multiple_files = len(files) > 1
    needle = pattern.casefold() if case_insensitive else pattern
    output = []

    for filename in files:
        with open(filename, encoding="utf-8") as file:
            for line_number, line in enumerate(file.read().splitlines(), start=1):
                candidate = line.rstrip("\r\n")
                target = candidate.casefold() if case_insensitive else candidate
                matched = target == needle if whole_line else needle in target
                if matched == invert:
                    continue

                if names_only:
                    output.append(filename + "\n")
                    continue
                text = candidate
                if line_numbers:
                    text = str(line_number) + ":" + text
                if multiple_files:
                    text = filename + ":" + text
                output.append(text + "\n")

    return "".join(output)
