def grep(pattern, flags, files):
    if isinstance(flags, str):
        enabled = set(flags)
    else:
        enabled = {flag for value in flags for flag in value}

    case_insensitive = "i" in enabled
    invert = "v" in enabled
    whole_line = "x" in enabled
    number_lines = "n" in enabled
    names_only = "l" in enabled

    matches = []
    matching_files = set()
    single_file = len(files) == 1

    for filename in files:
        with open(filename) as file:
            for line_number, line in enumerate(file, start=1):
                candidate = line.rstrip("\n")
                needle = pattern if not case_insensitive else pattern.lower()
                haystack = candidate if not case_insensitive else candidate.lower()

                if whole_line:
                    matched = haystack == needle
                else:
                    matched = needle in haystack

                if matched == (not invert):
                    matching_files.add(filename)
                    if names_only:
                        continue

                    prefix = ""
                    if not single_file:
                        prefix += f"{filename}:"
                    if number_lines:
                        prefix += f"{line_number}:"
                    matches.append(prefix + candidate)

    if names_only:
        matches = [filename for filename in files if filename in matching_files]

    return "\n".join(matches) + "\n" if matches else ""
