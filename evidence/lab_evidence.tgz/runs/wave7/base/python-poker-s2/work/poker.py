from collections import Counter


STRAIGHTS = {
    (14, 5, 4, 3, 2): 5,
    (14, 13, 12, 11, 10): 14,
    (13, 12, 11, 10, 9): 13,
    (12, 11, 10, 9, 8): 12,
    (11, 10, 9, 8, 7): 11,
    (10, 9, 8, 7, 6): 10,
    (9, 8, 7, 6, 5): 9,
    (8, 7, 6, 5, 4): 8,
    (7, 6, 5, 4, 3): 7,
    (6, 5, 4, 3, 2): 6,
}


class Hand:
    def __init__(self, text):
        self.text = text
        cards = text.split()
        if len(cards) != 5:
            raise ValueError("a poker hand must have five cards")

        values = []
        suits = []
        for card in cards:
            if len(card) < 2:
                raise ValueError(f"invalid card: {card!r}")
            rank, suit = card[:-1], card[-1]
            if suit not in "HCSD":
                raise ValueError(f"invalid suit: {card!r}")
            values.append(_rank_value(rank))
            suits.append(suit)
        if len(set(cards)) != 5:
            raise ValueError(f"duplicate card in hand: {text!r}")

        ranks_by_count = sorted(
            ((count, value) for value, count in Counter(values).items()),
            reverse=True,
        )
        ordered_ranks = tuple(sorted(values, reverse=True))
        is_flush = len(set(suits)) == 1
        straight_high = STRAIGHTS.get(ordered_ranks)

        if straight_high and is_flush:
            self.score = (8, straight_high, ())
        elif ranks_by_count[0][0] == 4:
            self.score = (7, ranks_by_count[0][1], (ranks_by_count[1][1],))
        elif ranks_by_count[0][0] == 3 and ranks_by_count[1][0] == 2:
            self.score = (6, ranks_by_count[0][1], ())
        elif is_flush:
            self.score = (5, ordered_ranks, ())
        elif straight_high:
            self.score = (4, straight_high, ())
        elif ranks_by_count[0][0] == 3:
            self.score = (
                3,
                ranks_by_count[0][1],
                (ranks_by_count[1][1], ranks_by_count[2][1]),
            )
        elif ranks_by_count[0][0] == 2 and ranks_by_count[1][0] == 2:
            self.score = (
                2,
                (ranks_by_count[0][1], ranks_by_count[1][1]),
                (ranks_by_count[2][1],),
            )
        elif ranks_by_count[0][0] == 2:
            self.score = (
                1,
                ranks_by_count[0][1],
                tuple(value for _, value in ranks_by_count[1:]),
            )
        else:
            self.score = (0, ordered_ranks, ())


def _rank_value(rank):
    values = {"2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
              "T": 10, "J": 11, "Q": 12, "K": 13, "A": 14}
    if rank not in values:
        raise ValueError(f"invalid rank: {rank!r}")
    return values[rank]


def best_hands(hands):
    parsed = [Hand(hand) for hand in hands]
    if not parsed:
        return []
    best = max(hand.score for hand in parsed)
    return [hand.text for hand in parsed if hand.score == best]
