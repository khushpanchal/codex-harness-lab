
WHITE = "W"
BLACK = "B"
NONE = ""


class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        if not isinstance(board, list) or not all(
            isinstance(row, str) for row in board
        ):
            raise ValueError("Board must be a list of strings")

        if len({len(row) for row in board}) > 1:
            raise ValueError("All board rows must have the same length")

        if any(char not in " .BW" for row in board for char in row):
            raise ValueError("Board may only contain spaces, '.', 'B', and 'W'")

        self.board = board
        self.height = len(board)
        self.width = len(board[0]) if board else 0

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not isinstance(x, int) or not isinstance(y, int):
            raise ValueError("Invalid coordinate")

        if not (0 <= x < self.width and 0 <= y < self.height):
            raise ValueError("Invalid coordinate")

        if self.board[y][x] not in " .":
            return NONE, set()

        empty = {(x, y)}
        frontier = [(x, y)]
        owners = set()

        while frontier:
            cell_x, cell_y = frontier.pop()
            for neighbour_x, neighbour_y in self._neighbours(cell_x, cell_y):
                contents = self.board[neighbour_y][neighbour_x]
                if contents in " .":
                    neighbour = (neighbour_x, neighbour_y)
                    if neighbour not in empty:
                        empty.add(neighbour)
                        frontier.append(neighbour)
                else:
                    owners.add(contents)

        if len(owners) == 1:
            return owners.pop(), empty
        return NONE, set()

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        territories = {WHITE: set(), BLACK: set(), NONE: set()}
        visited = set()

        for y in range(self.height):
            for x in range(self.width):
                if self.board[y][x] not in " ." or (x, y) in visited:
                    continue

                owner, territory = self.territory(x, y)
                visited.update(territory)
                territories[owner].update(territory)

        return territories

    def _neighbours(self, x, y):
        if x > 0:
            yield x - 1, y
        if x + 1 < self.width:
            yield x + 1, y
        if y > 0:
            yield x, y - 1
        if y + 1 < self.height:
            yield x, y + 1
