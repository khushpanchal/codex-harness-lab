
BLACK = "B"
WHITE = "W"
NONE = ""


class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        if not isinstance(board, list) or not all(isinstance(row, str) for row in board):
            raise ValueError("Board must be a list of strings")
        if not board or not all(len(row) == len(board[0]) for row in board):
            raise ValueError("Board rows must be non-empty and equal length")
        if not all(cell in {BLACK, WHITE, " "} for row in board for cell in row):
            raise ValueError("Board contains an invalid cell")
        self.board = board
        self.width = len(board[0])
        self.height = len(board)

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not isinstance(x, int) or not isinstance(y, int):
            raise ValueError("Invalid coordinate")
        if not 0 <= x < self.height or not 0 <= y < self.width:
            raise ValueError("Invalid coordinate")
        if self.board[x][y] != " ":
            return NONE, set()

        seen = {(x, y)}
        to_visit = [(x, y)]
        neighbors = set()

        while to_visit:
            point_x, point_y = to_visit.pop()
            for next_x, next_y in self._neighbors(point_x, point_y):
                cell = self.board[next_x][next_y]
                if cell != " ":
                    neighbors.add(cell)
                elif (next_x, next_y) not in seen:
                    seen.add((next_x, next_y))
                    to_visit.append((next_x, next_y))

        if len(neighbors) == 1:
            owner = next(iter(neighbors))
        else:
            owner = NONE
            seen = set()
        return owner, seen

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        results = {BLACK: set(), WHITE: set(), NONE: set()}
        for x in range(self.height):
            for y in range(self.width):
                if self.board[x][y] != " ":
                    continue
                owner, territory = self.territory(x, y)
                results[owner].update(territory)
        return results

    def _neighbors(self, x, y):
        for next_x, next_y in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
            if 0 <= next_x < self.height and 0 <= next_y < self.width:
                yield next_x, next_y
