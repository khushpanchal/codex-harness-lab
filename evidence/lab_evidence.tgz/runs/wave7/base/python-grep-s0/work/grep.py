def grep(pattern, flags, files):
    number_lines = "-n" in flags
    list_files = "-l" in flags
    ignore_case = "-i" in flags
    invert_match = "-v" in flags
    match_entire_line = "-x" in flags

    if ignore_case:
        pattern = pattern.casefold()

    output = []
    for filename in files:
        has_match = False
        with open(filename) as source:
            for line_number, line in enumerate(source, start=1):
                candidate = line.casefold() if ignore_case else line
                if match_entire_line:
                    # Strip exactly one trailing newline, if present.
                    if candidate.endswith("\n"):
                        candidate = candidate[:-1]
                    matches = candidate == pattern
                else:
                    matches = pattern in candidate

                if invert_match:
                    matches = not matches

                if not matches:
                    continue

                has_match = True
                if list_files:
                    break

                prefix = ""
                if len(files) > 1:
                    prefix += filename + ":"
                if number_lines:
                    prefix += str(line_number) + ":"
                output.append(prefix + line)

        if has_match and list_files:
            output.append(filename + "\n")

    return "".join(output)
