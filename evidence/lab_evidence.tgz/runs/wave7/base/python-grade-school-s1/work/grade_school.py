class School:
    def __init__(self):
        self._students_by_grade = {}
        self._grades_by_student = {}
        self._added = 0

    def add_student(self, name, grade):
        if name in self._grades_by_student:
            return False

        self._students_by_grade.setdefault(grade, []).append(name)
        self._grades_by_student[name] = grade
        self._added += 1
        return True

    def roster(self):
        return [
            name
            for grade in sorted(self._students_by_grade)
            for name in self.grade(grade)
        ]

    def grade(self, grade_number):
        return sorted(self._students_by_grade.get(grade_number, []))

    def added(self):
        return self._added
