class School:
    def __init__(self):
        self._students = {}
        self._added = True

    def add_student(self, name, grade):
        already_enrolled = name in (
            student for students in self._students.values() for student in students
        )
        self._added = not already_enrolled
        if already_enrolled:
            return False

        self._students.setdefault(grade, []).append(name)
        self._students[grade].sort()
        return True

    def roster(self):
        return [
            f"Grade {grade}: {', '.join(names)}"
            for grade, names in sorted(self._students.items())
        ]

    def grade(self, grade_number):
        return sorted(self._students.get(grade_number, []))

    def added(self):
        return self._added
