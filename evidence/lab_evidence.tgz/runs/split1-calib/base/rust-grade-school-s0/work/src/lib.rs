use std::collections::BTreeMap;

#[derive(Debug, Default, PartialEq, Eq)]
pub struct School {
    roster: BTreeMap<u32, Vec<String>>,
}

impl School {
    pub fn new() -> School {
        School::default()
    }

    #[allow(clippy::result_unit_err)]
    pub fn add(&mut self, grade: u32, student: &str) -> Result<(), ()> {
        if self.all().contains(&student.to_string()) {
            return Err(());
        }
        let grade_roster = self.roster.entry(grade).or_default();
        grade_roster.push(student.to_string());
        grade_roster.sort();
        Ok(())
    }

    pub fn grades(&self) -> Vec<u32> {
        self.roster.keys().copied().collect()
    }

    // If `grade` returned a reference, `School` would be forced to keep a `Vec<String>`
    // internally to lend out. By returning an owned vector of owned `String`s instead,
    // the internal structure can be completely arbitrary. The tradeoff is that some data
    // must be copied each time `grade` is called.
    pub fn grade(&self, grade: u32) -> Vec<String> {
        self.roster.get(&grade).cloned().unwrap_or_default()
    }

    pub fn all(&self) -> Vec<String> {
        self.roster.values().flatten().cloned().collect()
    }

    pub fn roster(&self) -> Vec<(u32, String)> {
        self.roster
            .iter()
            .flat_map(|(grade, students)| {
                students
                    .iter()
                    .map(move |student| (*grade, student.clone()))
            })
            .collect()
    }
}
