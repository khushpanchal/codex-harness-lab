pub mod graph {
    use std::collections::HashMap;

    pub mod graph_items {
        pub mod edge {
            #[derive(Debug, Default, Clone, PartialEq, Eq)]
            pub struct Edge {
                pub left: String,
                pub right: String,
                pub attrs: std::collections::HashMap<String, String>,
            }

            impl Edge {
                pub fn new(left: impl Into<String>, right: impl Into<String>) -> Self {
                    Self {
                        left: left.into(),
                        right: right.into(),
                        attrs: std::collections::HashMap::new(),
                    }
                }

                pub fn attrs(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
                    self.attrs.insert(key.into(), value.into());
                    self
                }

                pub fn attr(self, key: impl Into<String>, value: impl Into<String>) -> Self {
                    self.attrs(key, value)
                }
            }
        }

        pub mod node {
            #[derive(Debug, Default, Clone, PartialEq, Eq)]
            pub struct Node {
                pub id: String,
                pub attrs: std::collections::HashMap<String, String>,
            }

            impl Node {
                pub fn new(id: impl Into<String>) -> Self {
                    Self {
                        id: id.into(),
                        attrs: std::collections::HashMap::new(),
                    }
                }

                pub fn attrs(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
                    self.attrs.insert(key.into(), value.into());
                    self
                }

                pub fn attr(self, key: impl Into<String>, value: impl Into<String>) -> Self {
                    self.attrs(key, value)
                }
            }
        }
    }

    #[derive(Debug, Default, Clone, PartialEq, Eq)]
    pub struct Graph {
        pub nodes: Vec<Node>,
        pub edges: Vec<Edge>,
        pub attrs: HashMap<String, String>,
    }

    pub trait IntoNode {
        fn into_node(self) -> Node;
    }

    impl IntoNode for Node {
        fn into_node(self) -> Node {
            self
        }
    }

    impl<T: Into<String>> IntoNode for T {
        fn into_node(self) -> Node {
            Node::new(self)
        }
    }

    pub trait IntoEdge {
        fn into_edge(self) -> Edge;
    }

    impl IntoEdge for Edge {
        fn into_edge(self) -> Edge {
            self
        }
    }

    impl<T: Into<String>> IntoEdge for (T, T) {
        fn into_edge(self) -> Edge {
            Edge::new(self.0, self.1)
        }
    }

    impl Graph {
        pub fn new() -> Self {
            Self::default()
        }

        pub fn attrs(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
            self.attrs.insert(key.into(), value.into());
            self
        }

        pub fn attr(self, key: impl Into<String>, value: impl Into<String>) -> Self {
            self.attrs(key, value)
        }

        pub fn node(mut self, node: impl IntoNode) -> Self {
            self.nodes.push(node.into_node());
            self
        }

        pub fn edge(mut self, edge: impl IntoEdge) -> Self {
            self.edges.push(edge.into_edge());
            self
        }
    }

    pub use graph_items::edge::Edge;
    pub use graph_items::node::Node;
}

pub use graph::{Edge, Graph, Node};
