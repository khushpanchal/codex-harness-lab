# Game status categories
# Change the values as you see fit
STATUS_WIN = 'win'
STATUS_LOSE = 'lose'
STATUS_ONGOING = 'ongoing'


class Hangman:
    def __init__(self, word):
        if not word:
            raise ValueError("The word to guess must not be empty.")

        self.word = word
        self._guessed_chars = frozenset()
        self.remaining_guesses = 9
        self.status = STATUS_ONGOING

    def _transition(self, char):
        if self.status != STATUS_ONGOING:
            raise ValueError("The game has already ended.")

        guessed_chars = self._guessed_chars | {char}
        is_new_guess = char not in self._guessed_chars
        is_correct = char in self.word
        remaining_guesses = self.remaining_guesses
        status = STATUS_ONGOING

        if is_new_guess and not is_correct:
            remaining_guesses -= 1

        masked_word = "".join(
            char if char in guessed_chars else "_"
            for char in self.word
        )
        if masked_word == self.word:
            status = STATUS_WIN
        elif remaining_guesses == 0:
            status = STATUS_LOSE

        return guessed_chars, remaining_guesses, status

    def guess(self, char):
        (
            self._guessed_chars,
            self.remaining_guesses,
            self.status,
        ) = self._transition(char)

    def get_masked_word(self):
        return "".join(
            char if char in self._guessed_chars else "_"
            for char in self.word
        )

    def get_status(self):
        return self.status
