from functools import lru_cache

GROUP_DISCOUNTS = (0, 0, 5, 10, 20, 25)
GROUP_PRICES = tuple(
    size * 800 * (100 - discount) // 100
    for size, discount in enumerate(GROUP_DISCOUNTS)
)


def total(basket):
    counts = [0] * 5
    for title in basket:
        counts[title - 1] += 1
    return cheapest(tuple(sorted(counts, reverse=True)))


@lru_cache
def cheapest(remaining):
    if all(count == 0 for count in remaining):
        return 0

    best = None
    for size in range(1, len(remaining) + 1):
        if remaining[size - 1] == 0:
            continue
        next_remaining = list(remaining)
        for title in range(size):
            next_remaining[title] -= 1
        candidate = GROUP_PRICES[size] + cheapest(tuple(sorted(next_remaining, reverse=True)))
        if best is None or candidate < best:
            best = candidate

    return best
