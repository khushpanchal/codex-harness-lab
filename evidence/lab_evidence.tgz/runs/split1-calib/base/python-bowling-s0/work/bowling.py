class BowlingGame:
    def __init__(self):
        self.rolls = []
        self.frames = []

    def roll(self, pins):
        if self.game_is_over():
            raise IndexError("cannot roll after the game is over")
        if pins < 0 or pins > 10:
            raise ValueError("pins must be between 0 and 10")
        if pins > self.pins_standing():
            raise ValueError("cannot knock down more pins than are standing")

        if self.frames and not self.current_frame_is_complete():
            self.frames[-1].append(len(self.rolls))
        else:
            self.frames.append([len(self.rolls)])

        self.rolls.append(pins)

    def score(self):
        if not self.game_is_over():
            raise IndexError("cannot calculate the score of an incomplete game")

        total = 0
        for frame_number, frame in enumerate(self.frames):
            first_roll_index = frame[0]
            first_roll = self.rolls[first_roll_index]

            if frame_number < 9 and first_roll == 10:
                total += 10 + sum(self.rolls[first_roll_index + 1:first_roll_index + 3])
            elif (
                frame_number < 9
                and len(frame) == 2
                and first_roll + self.rolls[frame[1]] == 10
            ):
                total += 10 + self.rolls[first_roll_index + 2]
            else:
                total += sum(self.rolls[index] for index in frame)

        return total

    def current_frame_is_complete(self):
        if not self.frames:
            return False

        frame = self.frames[-1]
        if len(self.frames) == 10:
            if len(frame) < 2:
                return False
            if len(frame) == 2:
                return sum(self.rolls[index] for index in frame) < 10
            return True

        return len(frame) == 2 or self.rolls[frame[0]] == 10

    def pins_standing(self):
        if not self.frames or self.current_frame_is_complete():
            return 10

        frame = self.frames[-1]
        if len(self.frames) == 10 and len(frame) == 2:
            # Spare and strike fill balls begin with a full rack.
            return 10

        return 10 - sum(self.rolls[index] for index in frame)

    def game_is_over(self):
        return len(self.frames) == 10 and self.current_frame_is_complete()
