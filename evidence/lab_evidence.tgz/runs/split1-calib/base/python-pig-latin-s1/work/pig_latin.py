import re


_VOWELS = "aeiou"
_CONSONANTS = "bcdfghjklmnpqrstvwxz"


def _translate_word(word):
    if not word:
        return word

    first = word[0]
    if first in _VOWELS or word.startswith(("xr", "yt")):
        return word + "ay"

    # A q is normally followed by u, and they move as one unit.
    match = re.match(rf"[{_CONSONANTS}]*qu", word)
    if match:
        return word[match.end():] + match.group() + "ay"

    # The initial consonant cluster before y also moves as one unit.
    match = re.match(rf"[{_CONSONANTS}]+y", word)
    if match:
        return "y" + word[match.end():] + match.group()[:-1] + "ay"

    match = re.match(rf"[{_CONSONANTS}]+", word)
    if match:
        return word[match.end():] + match.group() + "ay"

    return word + "ay"


def translate(text):
    parts = re.split(r"(\s+)", text)
    return "".join(part if not part or part.isspace() else _translate_word(part) for part in parts)
