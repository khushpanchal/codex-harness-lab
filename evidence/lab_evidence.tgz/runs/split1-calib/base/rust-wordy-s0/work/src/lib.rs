pub fn answer(command: &str) -> Option<i32> {
    let question = command.strip_suffix('?')?;
    let expression = question.strip_prefix("What is ")?;
    if expression.is_empty() {
        return None;
    }

    let mut tokens = expression.split_whitespace();
    let mut value: i32 = parse_number(tokens.next()?)?;
    let mut operation = tokens.next();

    while let Some(word) = operation {
        let (operator, next) = parse_operation(&mut tokens, word)?;
        let operand = parse_number(tokens.next()?)?;
        value = apply(value, operator, operand)?;
        operation = next;
    }

    Some(value)
}

#[derive(Clone, Copy)]
enum Operator {
    Add,
    Subtract,
    Multiply,
    Divide,
    #[allow(dead_code)]
    Power,
}

fn parse_number(token: &str) -> Option<i32> {
    token.parse().ok()
}

fn parse_operation<'a, I>(tokens: &mut I, first: &'a str) -> Option<(Operator, Option<&'a str>)>
where
    I: Iterator<Item = &'a str>,
{
    match first {
        "plus" => Some((Operator::Add, tokens.next())),
        "minus" => Some((Operator::Subtract, tokens.next())),
        "multiplied" => match tokens.next()? {
            "by" => Some((Operator::Multiply, tokens.next())),
            _ => None,
        },
        "divided" => match tokens.next()? {
            "by" => Some((Operator::Divide, tokens.next())),
            _ => None,
        },
        "raised" => parse_exponent_tail(tokens),
        "to" => parse_exponent_tail_from_power(tokens),
        _ => None,
    }
}

#[cfg(feature = "exponentials")]
fn parse_exponent_tail<'a, I>(tokens: &mut I) -> Option<(Operator, Option<&'a str>)>
where
    I: Iterator<Item = &'a str>,
{
    if tokens.next()? != "to" {
        return None;
    }
    parse_exponent_tail_from_power(tokens)
}

#[cfg(not(feature = "exponentials"))]
fn parse_exponent_tail<'a, I>(tokens: &mut I) -> Option<(Operator, Option<&'a str>)>
where
    I: Iterator<Item = &'a str>,
{
    let _ = tokens;
    None
}

#[cfg(feature = "exponentials")]
fn parse_exponent_tail_from_power<'a, I>(tokens: &mut I) -> Option<(Operator, Option<&'a str>)>
where
    I: Iterator<Item = &'a str>,
{
    if tokens.next()? != "the" {
        return None;
    }

    let ordinal = match tokens.next()? {
        "power" => match tokens.next()? {
            "of" => tokens.next()?,
            _ => return None,
        },
        token => token,
    };
    parse_ordinal_exponent(ordinal)?;

    if tokens.next()? != "power" {
        return None;
    }
    Some((Operator::Power, tokens.next()))
}

#[cfg(not(feature = "exponentials"))]
fn parse_exponent_tail_from_power<'a, I>(tokens: &mut I) -> Option<(Operator, Option<&'a str>)>
where
    I: Iterator<Item = &'a str>,
{
    let _ = tokens;
    None
}

#[cfg(feature = "exponentials")]
fn parse_ordinal_exponent(token: &str) -> Option<()> {
    let split = token
        .find(|character: char| character.is_ascii_alphabetic())
        .filter(|index| *index > 0)?;
    let digits = &token[..split];
    let suffix = &token[split..];

    if digits.parse::<u32>().is_err() {
        return None;
    }

    let expected = match digits {
        "1" => "st",
        "2" => "nd",
        "3" => "rd",
        "11" | "12" | "13" => "th",
        _ => match digits.as_bytes()[digits.len() - 1] {
            b'1' => "st",
            b'2' => "nd",
            b'3' => "rd",
            _ => "th",
        },
    };

    if suffix == expected {
        Some(())
    } else {
        None
    }
}

fn apply(left: i32, operator: Operator, right: i32) -> Option<i32> {
    match operator {
        Operator::Add => left.checked_add(right),
        Operator::Subtract => left.checked_sub(right),
        Operator::Multiply => left.checked_mul(right),
        Operator::Divide => left.checked_div(right),
        #[cfg(feature = "exponentials")]
        Operator::Power => checked_power(left, right),
        #[cfg(not(feature = "exponentials"))]
        Operator::Power => None,
    }
}

#[cfg(feature = "exponentials")]
fn checked_power(base: i32, exponent: i32) -> Option<i32> {
    match (base, exponent) {
        (_, 0) => Some(1),
        (0, _) => Some(0),
        (1, _) => Some(1),
        (-1, _) => Some(if exponent % 2 == 0 { 1 } else { -1 }),
        _ if exponent < 0 => None,
        _ => {
            let exponent = u32::try_from(exponent).ok()?;
            checked_pow(base, exponent)
        }
    }
}

#[cfg(feature = "exponentials")]
fn checked_pow(mut base: i32, mut exponent: u32) -> Option<i32> {
    let mut result: i32 = 1;
    while exponent > 0 {
        if exponent % 2 == 1 {
            result = result.checked_mul(base)?;
        }
        exponent /= 2;
        if exponent > 0 {
            base = base.checked_mul(base)?;
        }
    }
    Some(result)
}
