import re


_NUMBER = r"-?\d+"
_OPERATION = r"plus|minus|multiplied by|divided by"
_KNOWN_WORDS = ("plus", "minus", "multiplied", "divided")


def answer(question):
    question = question.strip()
    if not question.lower().startswith("what is "):
        raise ValueError("syntax error")

    expression = question[len("What is ") :]
    if not expression.endswith("?") or "?" in expression[:-1]:
        raise ValueError("syntax error")
    expression = expression[:-1]

    words = expression.split(" ")
    if any(not word for word in words):
        raise ValueError("syntax error")

    tokens = []
    index = 0
    expect_operand = True
    while index < len(words):
        word = words[index]
        if expect_operand:
            if re.fullmatch(_NUMBER, word):
                tokens.append(int(word))
                index += 1
                expect_operand = False
                continue
            if re.fullmatch(r"[a-zA-Z]+", word):
                if word.lower() in _KNOWN_WORDS:
                    raise ValueError("syntax error")
                raise ValueError("unknown operation")
            raise ValueError("syntax error")

        for operation in ("plus", "minus"):
            if word.lower() == operation:
                tokens.append(operation)
                index += 1
                expect_operand = True
                break
        else:
            if word.lower() in ("multiplied", "divided") and index + 1 < len(words):
                operation = f"{word.lower()} by"
                tokens.append(operation)
                index += 2
                expect_operand = True
            elif re.fullmatch(r"[a-zA-Z]+", word):
                raise ValueError("unknown operation")
            else:
                raise ValueError("syntax error")

    if len(tokens) % 2 == 0:
        raise ValueError("syntax error")

    result = tokens[0]
    operations = {
        "plus": lambda left, right: left + right,
        "minus": lambda left, right: left - right,
        "multiplied by": lambda left, right: left * right,
        "divided by": lambda left, right: left / right,
    }

    for operation, operand in zip(tokens[1::2], tokens[2::2]):
        if operation not in operations:
            raise ValueError("unknown operation")
        try:
            result = operations[operation](result, operand)
        except ZeroDivisionError as error:
            raise ValueError("syntax error") from error

    if result % 1 != 0:
        raise ValueError("syntax error")
    return int(result)
