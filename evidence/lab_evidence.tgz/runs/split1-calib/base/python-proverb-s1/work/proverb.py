def proverb(*items, qualifier=None):
    verses = [
        f"For want of a {cause} the {effect} was lost."
        for cause, effect in zip(items, items[1:])
    ]

    if items:
        final_item = items[0]
        final_verse = f"And all for the want of a {final_item}."
        if qualifier:
            final_verse = f"And all for the want of a {qualifier} {final_item}."
        verses.append(final_verse)
    return verses
