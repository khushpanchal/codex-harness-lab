class School:
    def __init__(self):
        self._students_by_grade = {}
        self._all_students = {}
        self._last_addition_accepted = False

    def add_student(self, name, grade):
        if name in self._all_students:
            self._last_addition_accepted = False
            return

        self._students_by_grade.setdefault(grade, []).append(name)
        self._all_students[name] = grade
        self._last_addition_accepted = True

    def roster(self):
        return [
            name
            for grade in sorted(self._students_by_grade)
            for name in sorted(self._students_by_grade[grade])
        ]

    def grade(self, grade_number):
        return sorted(self._students_by_grade.get(grade_number, []))

    def added(self):
        return self._last_addition_accepted
