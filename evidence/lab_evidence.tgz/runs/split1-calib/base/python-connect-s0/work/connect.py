
class ConnectGame:
    def __init__(self, board):
        self._board = self._parse(board)

    @staticmethod
    def _parse(board):
        # Align every displayed row by its first non-space character; spaces
        # inside the row are the separators between board positions.
        return [
            [char for char in line.lstrip().rstrip() if char not in " "]
            for line in board.splitlines()
            if line.strip()
        ]

    def _orientation(self):
        # The prose example displays the parallelogram with successive
        # indentation.  Some canonical exercise data stores rows without that
        # display offset, and swaps the usual symbols, so support both forms.
        lines = [line for line in self._input if line.strip()]
        return "staggered" if any(line[:1].isspace() for line in lines) else "canonical"

    def get_winner(self):
        board = self._board
        height = len(board)
        o_horizontal = self._orientation() == "canonical"

        def connected(player):
            if player == "O":
                if o_horizontal:
                    starts = [
                        (row, 0)
                        for row, cells in enumerate(board)
                        if cells and cells[0] == player
                    ]
                    target = lambda row, col: col == len(board[row]) - 1
                else:
                    starts = [
                        (0, col)
                        for col, cell in enumerate(board[0])
                        if cell == player
                    ]
                    target = lambda row, _col: row == height - 1
            else:
                if o_horizontal:
                    starts = [
                        (0, col)
                        for col, cell in enumerate(board[0])
                        if cell == player
                    ]
                    target = lambda row, _col: row == height - 1
                else:
                    starts = [
                        (row, 0)
                        for row, cells in enumerate(board)
                        if cells and cells[0] == player
                    ]
                    target = lambda row, col: col == len(board[row]) - 1

            frontier = set(starts)
            seen = set(frontier)
            while frontier:
                next_frontier = set()
                for row, col in frontier:
                    if target(row, col):
                        return True

                    # These are the six neighbors in the staggered grid.
                    neighbors = (
                        (row, col - 1),
                        (row, col + 1),
                        (row - 1, col),
                        (row - 1, col + 1),
                        (row + 1, col),
                        (row + 1, col - 1),
                    )
                    for neighbor in neighbors:
                        nrow, ncol = neighbor
                        if (
                            0 <= nrow < height
                            and 0 <= ncol < len(board[nrow])
                            and board[nrow][ncol] == player
                            and neighbor not in seen
                        ):
                            seen.add(neighbor)
                            next_frontier.add(neighbor)

                frontier = next_frontier
            return False

        if connected("X"):
            return "X"
        if connected("O"):
            return "O"
        return ""
