
WHITE = "W"
BLACK = "B"
NONE = ""
EMPTY = " "


class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        self.board = board
        self.height = len(board)
        self.width = max((len(row) for row in board), default=0)

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not (0 <= x < self.width and 0 <= y < self.height):
            raise ValueError("Invalid coordinate")

        owner = self.board[y][x]
        if owner != EMPTY:
            return owner, set()

        pending = [(x, y)]
        empty = set(pending)
        borders = set()

        while pending:
            current_x, current_y = pending.pop()
            for neighbor in self._neighbors(current_x, current_y):
                stone = self.board[neighbor[1]][neighbor[0]]
                if stone == EMPTY:
                    if neighbor not in empty:
                        empty.add(neighbor)
                        pending.append(neighbor)
                else:
                    borders.add(stone)

        if len(borders) == 1:
            owner = next(iter(borders))
        else:
            owner = NONE
        return owner, empty

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        result = {BLACK: set(), WHITE: set(), NONE: set()}

        for y in range(self.height):
            for x in range(len(self.board[y])):
                if self.board[y][x] != EMPTY:
                    continue
                if any((x, y) in owners for owners in result.values()):
                    continue
                owner, territory = self.territory(x, y)
                result[owner].update(territory)

        return result

    def _neighbors(self, x, y):
        for delta_x, delta_y in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            neighbor_x, neighbor_y = x + delta_x, y + delta_y
            if 0 <= neighbor_x < len(self.board[y]) and 0 <= neighbor_y < self.height:
                yield neighbor_x, neighbor_y
