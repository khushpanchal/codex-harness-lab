import json
from decimal import Decimal


class RestAPI:
    def __init__(self, database=None):
        self.database = {"users": []} if database is None else database

    def get(self, url, payload=None):
        if url != "/users":
            return None

        all_users = {user["name"]: user for user in self.database["users"]}
        if payload is not None:
            names = json.loads(payload)["users"]
        else:
            names = sorted(all_users)
        return json.dumps({"users": [self._user(all_users[name]) for name in sorted(names)]})

    def post(self, url, payload=None):
        data = json.loads(payload)
        if url == "/add":
            user = {"name": data["user"], "owes": {}, "owed_by": {}}
            self.database["users"].append(user)
            return json.dumps(self._user(user))

        if url == "/iou":
            lender = self._find(data["lender"])
            borrower = self._find(data["borrower"])
            self._record(lender, borrower, data["amount"])
            users = sorted((lender, borrower), key=lambda user: user["name"])
            return json.dumps({"users": [self._user(user) for user in users]})

        return None

    def _find(self, name):
        for user in self.database["users"]:
            if user["name"] == name:
                return user
        raise KeyError(f"Unknown user: {name}")

    def _record(self, lender, borrower, amount):
        amount = Decimal(str(amount))
        self._increment(lender, "owed_by", borrower["name"], amount)
        self._increment(borrower, "owes", lender["name"], amount)

    @staticmethod
    def _increment(user, field, other, amount):
        balances = user[field]
        result = Decimal(str(balances.get(other, 0))) + amount
        if result:
            balances[other] = float(result)
        else:
            balances.pop(other, None)

    @staticmethod
    def _user(user):
        owed_by = sum(Decimal(str(amount)) for amount in user["owed_by"].values())
        owes = sum(Decimal(str(amount)) for amount in user["owes"].values())
        return {
            "name": user["name"],
            "owes": user["owes"],
            "owed_by": user["owed_by"],
            "balance": float(owed_by - owes),
        }
