#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Bucket {
    One,
    Two,
}

/// A struct to hold your results in.
#[derive(PartialEq, Eq, Debug)]
pub struct BucketStats {
    /// The total number of "moves" it should take to reach the desired number of liters, including
    /// the first fill.
    pub moves: u8,
    /// Which bucket should end up with the desired number of liters? (Either "one" or "two")
    pub goal_bucket: Bucket,
    /// How many liters are left in the other bucket?
    pub other_bucket: u8,
}

/// Solve the bucket problem
pub fn solve(
    capacity_1: u8,
    capacity_2: u8,
    goal: u8,
    start_bucket: &Bucket,
) -> Option<BucketStats> {
    if capacity_1 == 0 || capacity_2 == 0 || goal == 0 || goal > capacity_1 || goal > capacity_2 {
        return None;
    }

    let (source_capacity, destination_capacity) = match start_bucket {
        Bucket::One => (capacity_1, capacity_2),
        Bucket::Two => (capacity_2, capacity_1),
    };

    let mut gcd = source_capacity;
    let mut remainder = destination_capacity;
    while remainder > 0 {
        let next = gcd % remainder;
        gcd = remainder;
        remainder = next;
    }
    if !goal.is_multiple_of(gcd) {
        return None;
    }

    let mut source_amount = source_capacity;
    let mut destination_amount = 0;
    let mut moves = 1;

    loop {
        if source_amount == goal {
            return Some(BucketStats {
                moves: moves as u8,
                goal_bucket: *start_bucket,
                other_bucket: destination_amount,
            });
        }
        if destination_amount == goal {
            let goal_bucket = match start_bucket {
                Bucket::One => Bucket::Two,
                Bucket::Two => Bucket::One,
            };
            return Some(BucketStats {
                moves: moves as u8,
                goal_bucket,
                other_bucket: source_amount,
            });
        }

        if destination_amount == destination_capacity {
            destination_amount = 0;
        } else if source_amount == 0 {
            source_amount = source_capacity;
        } else {
            let transferred = source_amount.min(destination_capacity - destination_amount);
            if transferred == source_amount
                && destination_amount + transferred == destination_capacity
            {
                return None;
            }

            source_amount -= transferred;
            destination_amount += transferred;
        }

        moves += 1;
        if moves == 65_792 {
            return None;
        }
    }
}
