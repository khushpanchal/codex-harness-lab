#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    IncompleteNumber,
}

/// Convert a list of numbers to a stream of bytes encoded with variable length encoding.
pub fn to_bytes(values: &[u32]) -> Vec<u8> {
    let mut encoded = Vec::new();

    for &value in values {
        let mut groups = [0_u8; 5];
        let mut count = 1;
        groups[4] = (value & 0x7f) as u8;

        let mut remaining = value >> 7;
        while remaining != 0 {
            count += 1;
            groups[5 - count] = ((remaining & 0x7f) as u8) | 0x80;
            remaining >>= 7;
        }

        encoded.extend_from_slice(&groups[5 - count..]);
    }

    encoded
}

/// Given a stream of bytes, extract all numbers which are encoded in there.
pub fn from_bytes(bytes: &[u8]) -> Result<Vec<u32>, Error> {
    let mut values = Vec::new();
    let mut value = 0_u32;
    let mut started = false;

    for &byte in bytes {
        started = true;
        value = (value << 7) | u32::from(byte & 0x7f);

        if byte & 0x80 == 0 {
            values.push(value);
            value = 0;
            started = false;
        }
    }

    if started {
        return Err(Error::IncompleteNumber);
    }

    Ok(values)
}
