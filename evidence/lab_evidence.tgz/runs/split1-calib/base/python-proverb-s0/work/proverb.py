def proverb(*input_data, qualifier=None):
    verses = [
        f"For want of a {current} the {next_} was lost."
        for current, next_ in zip(input_data, input_data[1:])
    ]
    if input_data:
        last = input_data[0]
        if qualifier is not None:
            last = f"{qualifier} {last}"
        verses.append(f"And all for the want of a {last}.")
    return verses
