def transpose(text):
    rows = text.split("\n")
    width = max(map(len, rows))
    # Absent characters are to the right of each original row. The
    # transpose keeps internal blanks, but does not extend past the input.
    padded = [row.ljust(width) for row in rows]
    return "\n".join("".join(row[column] for row in padded).rstrip(" ")
                     for column in range(width))
