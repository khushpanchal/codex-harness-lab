// This exercise is deprecated.
// Consider working on protein-translation instead.

pub struct CodonsInfo<'a> {
    names: Vec<(&'a str, &'a str)>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Error;

impl<'a> CodonsInfo<'a> {
    pub fn name_for(&self, codon: &str) -> Result<&'a str, Error> {
        let codons = expand_codon(codon)?;
        let mut names = codons.iter().filter_map(|expanded| self.find(expanded));
        let Some(name) = names.next() else {
            return Err(Error);
        };
        if names.all(|other| other == name) {
            Ok(name)
        } else {
            Err(Error)
        }
    }

    pub fn of_rna(&self, rna: &str) -> Result<Vec<&'a str>, Error> {
        let mut names = Vec::new();
        for chunk in rna.as_bytes().chunks_exact(3) {
            let codon = std::str::from_utf8(chunk).map_err(|_| Error)?;
            names.push(self.name_for(codon)?);
        }
        if !rna.is_empty() && rna.len() % 3 != 0 {
            return Err(Error);
        }
        Ok(names)
    }
}

pub fn parse<'a>(pairs: Vec<(&'a str, &'a str)>) -> CodonsInfo<'a> {
    CodonsInfo { names: pairs }
}

const NUCLEOTIDES: [char; 4] = ['A', 'C', 'G', 'T'];

fn expand_codon(codon: &str) -> Result<Vec<String>, Error> {
    if codon.is_empty() || codon.len() > 3 {
        return Err(Error);
    }

    let mut expanded = vec![String::new()];
    for character in codon.chars() {
        let identity = [character];
        let possibilities = match character {
            'U' => ['T'].as_slice(),
            'A' | 'C' | 'G' | 'T' => identity.as_slice(),
            'R' => ['A', 'G'].as_slice(),
            'Y' => ['C', 'T'].as_slice(),
            'S' => ['C', 'G'].as_slice(),
            'W' => ['A', 'T'].as_slice(),
            'K' => ['G', 'T'].as_slice(),
            'M' => ['A', 'C'].as_slice(),
            'B' => ['C', 'G', 'T'].as_slice(),
            'D' => ['A', 'G', 'T'].as_slice(),
            'H' => ['A', 'C', 'T'].as_slice(),
            'V' => ['A', 'C', 'G'].as_slice(),
            'N' => NUCLEOTIDES.as_slice(),
            _ => return Err(Error),
        };

        expanded = expanded
            .into_iter()
            .flat_map(|prefix| {
                possibilities
                    .iter()
                    .map(move |possibility| format!("{prefix}{possibility}"))
            })
            .collect();
    }

    Ok(expanded)
}

impl<'a> CodonsInfo<'a> {
    fn find(&self, codon: &str) -> Option<&'a str> {
        self.names
            .iter()
            .find(|(known, _)| known.eq_ignore_ascii_case(codon))
            .map(|(_, name)| *name)
    }
}
