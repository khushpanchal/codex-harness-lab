use nucleotide_codons::parse;

fn main() {
    let pairs = vec![("TTT","phenylalanine"),("TAT","tyrosine"),("TAA","stop"),("TAG","stop")];
    let info = parse(pairs);
    assert_eq!(info.name_for("TAT"), Ok("tyrosine"));
    assert_eq!(info.name_for("UAT"), Ok("tyrosine"));
    assert_eq!(info.name_for("TAR"), Ok("stop"));
    assert_eq!(info.name_for("TA"), Err(nucleotide_codons::Error));
    assert_eq!(info.of_rna("UATAA"), Ok(vec!["tyrosine", "stop"]));
    assert_eq!(info.of_rna("UATA"), Err(nucleotide_codons::Error));
    println!("verification passed");
}
