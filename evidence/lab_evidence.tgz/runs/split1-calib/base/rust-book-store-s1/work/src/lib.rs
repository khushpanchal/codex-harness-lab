use std::collections::HashMap;

/// Prices are in cents to avoid floating-point rounding.
fn group_price(size: u32) -> u32 {
    let discount_percent = match size {
        1 => 0,
        2 => 5,
        3 => 10,
        4 => 20,
        5 => 25,
        _ => unreachable!("groups are limited to the five books in the series"),
    };

    size * 800 * (100 - discount_percent) / 100
}

fn lowest_price_for_counts(counts: &[u32; 5], cache: &mut HashMap<[u32; 5], u32>) -> u32 {
    let mut counts = *counts;
    counts.sort_unstable();
    counts.reverse();

    if counts == [0; 5] {
        return 0;
    }

    if let Some(&price) = cache.get(&counts) {
        return price;
    }

    let distinct = counts.iter().filter(|&&count| count > 0).count() as u32;
    let mut best = u32::MAX;

    // Every grouping can be represented by repeatedly removing a distinct set
    // of titles, so branching on each possible group size is complete. Titles
    // are already ordered from most copies to fewest, which keeps equivalent
    // states together.
    for size in 1..=distinct.min(5) {
        let mut next = counts;
        next.iter_mut()
            .take(size as usize)
            .for_each(|count| *count -= 1);
        best = best.min(group_price(size) + lowest_price_for_counts(&next, cache));
    }

    cache.insert(counts, best);
    best
}

pub fn lowest_price(books: &[u32]) -> u32 {
    let mut counts = [0_u32; 5];
    for &book in books {
        counts[(book - 1) as usize] += 1;
    }

    lowest_price_for_counts(&counts, &mut HashMap::new())
}
