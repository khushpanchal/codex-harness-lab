def measure(bucket_one, bucket_two, goal, start_bucket):
    if bucket_one <= 0 or bucket_two <= 0:
        raise ValueError("Bucket sizes must be positive integers.")
    if goal <= 0 or goal > max(bucket_one, bucket_two):
        raise ValueError("Goal must be positive and no larger than a bucket.")
    if start_bucket not in ("one", "two"):
        raise ValueError("Starting bucket must be either 'one' or 'two'.")

    if start_bucket == "one":
        initial = (bucket_one, 0)
        forbidden = (0, bucket_two)
    else:
        initial = (0, bucket_two)
        forbidden = (bucket_one, 0)

    states = {initial}
    queue = [(initial, 1)]
    while queue:
        current, actions = queue.pop(0)
        if goal in current:
            other = (current[1] if current[0] == goal else current[0])
            winning_bucket = "one" if current[0] == goal else "two"
            return actions, winning_bucket, other

        x, y = current
        moves = (
            (bucket_one, y),
            (x, bucket_two),
            (0, y),
            (x, 0),
            (x - min(x, bucket_two - y), y + min(x, bucket_two - y)),
            (x + min(y, bucket_one - x), y - min(y, bucket_one - x)),
        )

        for state in moves:
            if state not in states and state != forbidden:
                states.add(state)
                queue.append((state, actions + 1))

    raise ValueError("The goal cannot be measured with these bucket sizes.")
