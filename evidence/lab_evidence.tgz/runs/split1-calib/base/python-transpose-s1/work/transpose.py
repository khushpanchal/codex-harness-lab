def transpose(text):
    rows = text.split("\n")
    width = max(map(len, rows))
    padded = [row.rjust(width) for row in rows]

    return "\n".join(
        "".join(
            character
            if character != " " or column_number >= len(row)
            else ""
            for row, character in zip(padded, column)
        )
        for column, column_number in zip(zip(*padded), range(width))
    )
