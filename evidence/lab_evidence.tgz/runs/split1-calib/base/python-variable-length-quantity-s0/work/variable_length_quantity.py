def encode(numbers):
    encoded = []

    for number in numbers:
        if not 0 <= number <= 0xFFFFFFFF:
            raise ValueError("number must fit in a 32-bit unsigned integer")

        groups = []
        while True:
            groups.append(number & 0x7F)
            number >>= 7
            if number == 0:
                break

        # Every group except the final one is a continuation byte.
        for group in reversed(groups[1:]):
            encoded.append(0x80 | group)
        encoded.append(groups[0])

    return encoded


def decode(bytes_):
    decoded = []
    number = 0
    started = False

    for byte in bytes_:
        if not 0 <= byte <= 0x7F and not 0x80 <= byte <= 0xFF:
            raise ValueError("byte must be an unsigned 8-bit integer")

        started = True
        number = (number << 7) | (byte & 0x7F)
        if byte & 0x80:
            if number > 0xFFFFFFFF:
                raise ValueError("decoded number does not fit in a 32-bit unsigned integer")
            continue

        decoded.append(number)
        number = 0
        started = False

    if started:
        raise ValueError("incomplete sequence")

    return decoded
