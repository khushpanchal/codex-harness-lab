number_words = [
    "no", "one", "two", "three", "four", "five", "six",
    "seven", "eight", "nine", "ten",
]


def _bottle_phrase(count, capitalized=False):
    bottles = "bottle" if count == 1 else "bottles"
    word = number_words[count].capitalize() if capitalized else number_words[count]
    return f"{word} green {bottles}"


def recite(start, take=1):
    verses = []
    for count in range(start, start - take, -1):
        phrase = _bottle_phrase(count, capitalized=True)
        remaining = _bottle_phrase(count - 1)
        verses.extend([
            f"{phrase} hanging on the wall,",
            f"{phrase} hanging on the wall,",
            "And if one green bottle should accidentally fall,",
            f"There'll be {remaining} hanging on the wall.",
        ])
    return verses
