
class ConnectGame:
    def __init__(self, board):
        if isinstance(board, str):
            raw_lines = board.splitlines()
        else:
            raw_lines = list(board)

        parsed_rows = []
        for line in raw_lines:
            if not line.strip():
                continue
            indent = len(line) - len(line.lstrip(" "))
            stripped_line = line.lstrip(" ")
            if any(char not in ".XO " for char in stripped_line):
                raise ValueError("board may contain only spaces, periods, X, and O")
            parsed_rows.append((indent, stripped_line))

        self.cells = {}

        if parsed_rows:
            for row, (_, cells) in enumerate(parsed_rows):
                for offset, char in enumerate(cells):
                    if char in "XO":
                        self.cells[(row, offset)] = char

        self._min_row = 0
        self._max_row = len(parsed_rows) - 1
        self._min_column = 0
        self._max_column = 0
        if parsed_rows:
            board_width = sum(char != " " for char in parsed_rows[0][1])
            first_indent = parsed_rows[0][0]
            self._min_column = first_indent
            self._max_column = first_indent + 2 * (board_width - 1)

    def _neighbors(self, coordinate):
        row, column = coordinate
        candidates = (
            (row, column - 1),
            (row, column + 1),
            (row - 1, column - 1),
            (row - 1, column),
            (row + 1, column),
            (row + 1, column + 1),
        )
        return (candidate for candidate in candidates if candidate in self.cells)

    def _has_span(self, player):
        def is_first_side(coordinate):
            row, _ = coordinate
            return row == self._min_row

        def is_second_side(coordinate):
            row, _ = coordinate
            return row == self._max_row

        if player == "X":
            def is_first_side(coordinate):
                _, column = coordinate
                return column == self._min_column

            def is_second_side(coordinate):
                _, column = coordinate
                return column == self._max_column

        pending = [
            coordinate
            for coordinate, cell_player in self.cells.items()
            if cell_player == player and is_first_side(coordinate)
        ]
        visited = set(pending)

        while pending:
            coordinate = pending.pop()
            if is_second_side(coordinate):
                return True
            for neighbor in self._neighbors(coordinate):
                if (
                    neighbor not in visited
                    and self.cells.get(neighbor) == player
                ):
                    visited.add(neighbor)
                    pending.append(neighbor)

        return False

    def get_winner(self):
        if self._has_span("O"):
            return "O"
        if self._has_span("X"):
            return "X"
        return ""
