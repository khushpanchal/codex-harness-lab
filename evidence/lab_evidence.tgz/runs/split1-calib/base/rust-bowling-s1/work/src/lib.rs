#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    NotEnoughPinsLeft,
    GameComplete,
}

pub struct BowlingGame {
    rolls: Vec<u16>,
}

impl BowlingGame {
    pub fn new() -> Self {
        Self { rolls: Vec::new() }
    }

    pub fn roll(&mut self, pins: u16) -> Result<(), Error> {
        if self.is_complete() {
            return Err(Error::GameComplete);
        }

        if pins > self.pins_remaining() {
            return Err(Error::NotEnoughPinsLeft);
        }

        self.rolls.push(pins);
        Ok(())
    }

    pub fn score(&self) -> Option<u16> {
        if !self.is_complete() {
            return None;
        }

        let mut score = 0;
        let mut roll = 0;

        for _frame in 0..10 {
            if self.rolls[roll] == 10 {
                score += 10 + self.rolls[roll + 1] + self.rolls[roll + 2];
                roll += 1;
            } else if self.rolls[roll] + self.rolls[roll + 1] == 10 {
                score += 10 + self.rolls[roll + 2];
                roll += 2;
            } else {
                score += self.rolls[roll] + self.rolls[roll + 1];
                roll += 2;
            }
        }

        Some(score)
    }

    fn is_complete(&self) -> bool {
        self.rolls.len() == self.required_rolls()
    }

    fn pins_remaining(&self) -> u16 {
        let rolls = self.rolls.len();

        if self.is_in_tenth_frame() {
            if self.is_complete() {
                0
            } else if rolls == self.rolls_before_tenth() + 1 {
                10 - self.rolls[self.rolls_before_tenth()]
            } else if rolls == self.rolls_before_tenth() + 2 {
                if self.rolls[self.rolls_before_tenth()] == 10
                    && self.rolls[self.rolls_before_tenth() + 1] != 10
                {
                    10 - self.rolls[self.rolls_before_tenth() + 1]
                } else {
                    10
                }
            } else {
                10
            }
        } else {
            10 - self.rolls.last().copied().unwrap_or(0)
        }
    }

    fn is_in_tenth_frame(&self) -> bool {
        self.rolls.len() >= self.rolls_before_tenth()
    }

    fn rolls_before_tenth(&self) -> usize {
        if self.rolls.is_empty() {
            return 0;
        }

        let mut frame = 0;
        let mut roll = 0;

        while frame < 9 {
            if self.rolls[roll] == 10 {
                roll += 1;
            } else {
                roll += 2;
            }
            frame += 1;
        }

        roll
    }

    fn required_rolls(&self) -> usize {
        if self.rolls.is_empty() || !self.is_in_tenth_frame() {
            return 20;
        }

        let start = self.rolls_before_tenth();
        match (self.rolls[start], self.rolls.get(start + 1).copied()) {
            (first, Some(second)) if first == 10 || first + second == 10 => {
                if self.rolls.len() >= start + 2 {
                    start + 3
                } else {
                    start + 2
                }
            }
            (_, Some(_)) => start + 2,
            _ => start + 1,
        }
    }
}
