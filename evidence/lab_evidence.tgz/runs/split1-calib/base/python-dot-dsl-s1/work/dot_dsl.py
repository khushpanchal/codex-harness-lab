NODE, EDGE, ATTR = range(3)


class Node:
    def __init__(self, name, attrs):
        self.name = name
        self.attrs = attrs

    def __eq__(self, other):
        return self.name == other.name and self.attrs == other.attrs


class Edge:
    def __init__(self, src, dst, attrs):
        self.src = src
        self.dst = dst
        self.attrs = attrs

    def __eq__(self, other):
        return (self.src == other.src and
                self.dst == other.dst and
                self.attrs == other.attrs)


class Graph:
    def __init__(self, data=None):
        self.nodes = []
        self.edges = []
        self.attrs = {}

        if data is None:
            return

        if not isinstance(data, list):
            raise TypeError("Graph data malformed")

        for item in data:
            if not isinstance(item, tuple) or len(item) < 2:
                raise TypeError("Graph data malformed")

            kind = item[0]
            if kind == ATTR:
                if len(item) != 2 or not isinstance(item[1], tuple) or len(item[1]) != 2:
                    raise TypeError("Graph data malformed")
                key, value = item[1]
                self.attrs[key] = value
            elif kind == NODE:
                if len(item) != 3 or not isinstance(item[2], list):
                    raise TypeError("Graph data malformed")
                attrs = self._validate_attrs(item[2], "Node malformed")
                if not isinstance(item[1], str):
                    raise TypeError("Graph data malformed")
                name = item[1]
                self.nodes.append(Node(name, attrs))
            elif kind == EDGE:
                if len(item) != 4 or not isinstance(item[3], list):
                    raise TypeError("Graph data malformed")
                attrs = self._validate_attrs(item[3], "EDGE malformed")
                if not isinstance(item[1], str) or not isinstance(item[2], str):
                    raise TypeError("Graph data malformed")
                src, dst = item[1], item[2]
                self.edges.append(Edge(src, dst, attrs))
            else:
                raise TypeError("Graph data malformed")

    @staticmethod
    def _validate_attrs(attrs, message):
        if not all(isinstance(attr, tuple) and len(attr) == 2 for attr in attrs):
            raise ValueError(message)
        return dict(attrs)
