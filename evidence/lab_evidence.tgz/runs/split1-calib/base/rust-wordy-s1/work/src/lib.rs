use std::borrow::Cow;
use std::str::FromStr;

#[cfg_attr(not(feature = "exponentials"), allow(dead_code))]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Operation {
    Add,
    Subtract,
    Multiply,
    Divide,
    Power,
    Square,
    Cube,
}

#[derive(Debug, PartialEq, Eq)]
enum Token {
    Number(i32),
    Operation(Operation),
}

/// Returns an integer answer, or `None` for malformed, unsupported, or
/// overflowing questions. Evaluation is left-to-right, as required by the
/// verbal style of these problems.
pub fn answer(command: &str) -> Option<i32> {
    let command = command.strip_suffix('?').unwrap_or(command);
    #[allow(unused_mut)]
    let mut command = Cow::Borrowed(command.trim().strip_prefix("What is")?.trim());

    // The optional exponentials bonus uses several natural-language forms.
    #[cfg(feature = "exponentials")]
    if let Some(rest) = command
        .strip_prefix("raised to the ")
        .or_else(|| command.strip_prefix("to the "))
    {
        let rest = rest.strip_suffix(" power")?;
        if let Some(exponent) = ordinal_exponent(rest) {
            command = Cow::Owned(format!("{command} to_the_power {exponent}"));
        } else {
            return None;
        }
    }

    let tokens = tokens(&command)?;
    let mut pieces = tokens.into_iter().peekable();
    let mut result = match pieces.next()? {
        Token::Number(value) => value,
        Token::Operation(_) => return None,
    };

    while let Some(operation) = pieces.next() {
        let Token::Operation(operation) = operation else {
            return None;
        };
        result = apply(result, operation, &mut pieces)?;
    }

    Some(result)
}

#[cfg(feature = "exponentials")]
fn ordinal_exponent(input: &str) -> Option<i32> {
    let (number, suffix) = input.split_at(input.len().saturating_sub(2));
    let exponent = number.parse().ok()?;
    let valid_suffix = matches!(
        suffix,
        "st" | "nd" | "rd" | "th" | "first" | "second" | "third" | "fourth" | "fifth"
    );
    valid_suffix.then_some(exponent)
}

fn tokens(input: &str) -> Option<Vec<Token>> {
    let mut tokens = Vec::new();
    let mut input = input.trim();

    while !input.is_empty() {
        if let Some(rest) = input
            .strip_prefix("plus ")
            .or_else(|| input.strip_prefix("plus"))
        {
            tokens.push(Token::Operation(Operation::Add));
            input = rest.trim_start();
            continue;
        }
        if let Some(rest) = input
            .strip_prefix("minus ")
            .or_else(|| input.strip_prefix("minus"))
        {
            tokens.push(Token::Operation(Operation::Subtract));
            input = rest.trim_start();
            continue;
        }
        if let Some(rest) = input
            .strip_prefix("multiplied by ")
            .or_else(|| input.strip_prefix("multiplied by"))
        {
            tokens.push(Token::Operation(Operation::Multiply));
            input = rest.trim_start();
            continue;
        }
        if let Some(rest) = input
            .strip_prefix("divided by ")
            .or_else(|| input.strip_prefix("divided by"))
        {
            tokens.push(Token::Operation(Operation::Divide));
            input = rest.trim_start();
            continue;
        }
        #[cfg(feature = "exponentials")]
        {
            if let Some(rest) = input
                .strip_prefix("to the power of ")
                .or_else(|| input.strip_prefix("to the power of"))
            {
                tokens.push(Token::Operation(Operation::Power));
                input = rest.trim_start();
                continue;
            }
            if let Some(rest) = input.strip_prefix("squared") {
                tokens.push(Token::Operation(Operation::Square));
                input = rest.trim_start();
                continue;
            }
            if let Some(rest) = input.strip_prefix("cubed") {
                tokens.push(Token::Operation(Operation::Cube));
                input = rest.trim_start();
                continue;
            }
        }

        let end = input
            .split(|character: char| character.is_whitespace())
            .next()?
            .len();
        let (word, rest) = input.split_at(end);
        let word = word.replace(',', "");
        let number = i32::from_str(&word).ok()?;
        tokens.push(Token::Number(number));
        input = rest.trim_start();
    }

    Some(tokens)
}

fn apply(
    left: i32,
    operation: Operation,
    pieces: &mut std::iter::Peekable<std::vec::IntoIter<Token>>,
) -> Option<i32> {
    match operation {
        Operation::Square => left.checked_mul(left),
        Operation::Cube => left.checked_mul(left)?.checked_mul(left),
        Operation::Power => {
            let Token::Number(right) = pieces.next()? else {
                return None;
            };
            exponentiate(left, right)
        }
        _ => {
            let Token::Number(right) = pieces.next()? else {
                return None;
            };
            match operation {
                Operation::Add => left.checked_add(right),
                Operation::Subtract => left.checked_sub(right),
                Operation::Multiply => left.checked_mul(right),
                Operation::Divide if right != 0 => left.checked_div(right),
                _ => None,
            }
        }
    }
}

fn exponentiate(base: i32, exponent: i32) -> Option<i32> {
    if exponent < 0 {
        // Integer answers cannot represent negative exponents except for 1^n.
        return if base == 1 { Some(1) } else { None };
    }
    match u32::try_from(exponent) {
        Ok(exponent) => base.checked_pow(exponent),
        Err(_) => None,
    }
}
