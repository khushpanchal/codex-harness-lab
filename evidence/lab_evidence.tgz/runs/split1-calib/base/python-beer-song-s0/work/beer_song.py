def recite(start, take=1):
    verses = []
    for number in range(start, start - take, -1):
        verses.append(_verse(number))
    return verses if take > 1 else verses[0]


def _verse(number):
    bottles = _bottles(number)
    next_bottles = _bottles(number - 1)
    action = "Take it down" if number == 1 else "Take one down"
    if number == 0:
        action = "Go to the store and buy some more"
        next_bottles = _bottles(99)
    return [
        f"{bottles.capitalize()} of beer on the wall, {bottles} of beer.",
        f"{action} and pass it around, {next_bottles} of beer on the wall.",
    ]


def _bottles(number):
    if number == 0:
        return "no more bottles"
    if number == 1:
        return "1 bottle"
    return f"{number} bottles"
