def recite(start, take=1):
    words = [
        "no", "one", "two", "three", "four", "five",
        "six", "seven", "eight", "nine", "ten",
    ]
    lines = []

    for count in range(start, start - take, -1):
        quantity = words[count]
        next_quantity = words[count - 1]
        bottle_word = "bottle" if count == 1 else "bottles"
        next_bottle_word = "bottle" if count - 1 == 1 else "bottles"
        lines.extend(
            [
                f"{quantity.capitalize()} green {bottle_word} hanging on the wall,",
                f"{quantity.capitalize()} green {bottle_word} hanging on the wall,",
                "And if one green bottle should accidentally fall,",
                f"There'll be {next_quantity} green {next_bottle_word} hanging on the wall.",
            ]
        )

    return lines
