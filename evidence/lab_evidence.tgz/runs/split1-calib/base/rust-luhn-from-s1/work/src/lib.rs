pub struct Luhn {
    digits: String,
}

impl Luhn {
    pub fn is_valid(&self) -> bool {
        if self.digits.len() < 2 || !self.digits.chars().all(|ch| ch.is_ascii_digit()) {
            return false;
        }

        self.digits
            .chars()
            .rev()
            .enumerate()
            .map(|(index, digit)| {
                let digit = digit.to_digit(10).expect("validated as an ASCII digit");
                if index % 2 == 1 {
                    let doubled = digit * 2;
                    if doubled > 9 {
                        doubled - 9
                    } else {
                        doubled
                    }
                } else {
                    digit
                }
            })
            .sum::<u32>()
            % 10
            == 0
    }
}

impl From<&str> for Luhn {
    fn from(input: &str) -> Self {
        Self {
            digits: input.chars().filter(|ch| !ch.is_whitespace()).collect(),
        }
    }
}

impl From<String> for Luhn {
    fn from(input: String) -> Self {
        Self::from(input.as_str())
    }
}

impl From<&String> for Luhn {
    fn from(input: &String) -> Self {
        Self::from(input.as_str())
    }
}

macro_rules! impl_luhn_from_unsigned {
    ($($type:ty),*) => {
        $(
            impl From<$type> for Luhn {
                fn from(input: $type) -> Self {
                    Self {
                        digits: input.to_string(),
                    }
                }
            }
        )*
    };
}

impl_luhn_from_unsigned!(u8, u16, u32, u64, u128, usize);

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rejects_single_digits_and_non_digits() {
        assert!(!Luhn::from("1").is_valid());
        assert!(!Luhn::from("1234a").is_valid());
    }

    #[test]
    fn validates_unsigned_values() {
        assert!(Luhn::from(4_242_424_242_424_242_u64).is_valid());
        assert!(!Luhn::from(4_242_424_242_424_243_u64).is_valid());
    }
}
