class BowlingGame:
    def __init__(self):
        self.rolls = []
        self.frame = 1
        self.standing = 10
        self.tenth_bonus_allowed = False
        self.complete = False

    def roll(self, pins):
        if not isinstance(pins, int) or isinstance(pins, bool):
            raise ValueError("pins knocked down must be an integer")
        if pins < 0 or pins > 10:
            raise ValueError("pins knocked down must be between 0 and 10")

        roll_count = len(self.rolls)

        if roll_count >= 21:
            raise ValueError("cannot roll after the game is complete")
        elif self.frame < 10:
            if pins > self.standing:
                raise ValueError("a frame cannot knock down more than ten pins")
            first_roll_in_frame = self.standing == 10
            if pins == 10 or (not first_roll_in_frame and pins == self.standing):
                self.frame += 1
                self.standing = 10
            else:
                self.standing -= pins
        else:
            rolls_in_tenth = roll_count - 19
            if rolls_in_tenth == 1:
                if pins > self.standing:
                    raise ValueError("the tenth frame cannot knock down more than ten pins")
                if self.rolls[18] == 10 or self.rolls[18] + pins == 10:
                    self.tenth_bonus_allowed = True
                else:
                    self.complete = True
                self.standing = 10 if pins == 10 else 0
            elif rolls_in_tenth == 2:
                if not self.tenth_bonus_allowed:
                    raise ValueError("cannot roll after the game is complete")
                if self.rolls[18] != 10 and self.rolls[18] + pins > 10:
                    raise ValueError("the tenth frame cannot knock down more than ten pins")
                if self.rolls[18] == 10 and self.rolls[19] != 10 and self.rolls[19] + pins > 10:
                    raise ValueError("invalid fill balls")
            else:
                raise ValueError("cannot roll after the game is complete")

        self.rolls.append(pins)

    def game_complete(self):
        return self.complete

    def score(self):
        if not self.game_complete():
            raise ValueError("the game is not yet complete")

        total = 0
        roll_index = 0

        for _ in range(9):
            if self.rolls[roll_index] == 10:
                total += 10 + self.rolls[roll_index + 1] + self.rolls[roll_index + 2]
                roll_index += 1
            else:
                frame_total = self.rolls[roll_index] + self.rolls[roll_index + 1]
                total += frame_total
                if frame_total == 10:
                    total += self.rolls[roll_index + 2]
                roll_index += 2

        total += sum(self.rolls[roll_index:])
        return total
