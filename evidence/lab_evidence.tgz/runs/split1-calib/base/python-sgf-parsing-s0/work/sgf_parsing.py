class SgfTree:
    def __init__(self, properties=None, children=None):
        self.properties = properties or {}
        self.children = children or []

    def __eq__(self, other):
        if not isinstance(other, SgfTree):
            return False
        for key, value in self.properties.items():
            if key not in other.properties:
                return False
            if other.properties[key] != value:
                return False
        for key in other.properties.keys():
            if key not in self.properties:
                return False
        if len(self.children) != len(other.children):
            return False
        for child, other_child in zip(self.children, other.children):
            if child != other_child:
                return False
        return True

    def __ne__(self, other):
        return not self == other


def parse(input_string):
    parser = Parser(input_string)
    return parser.parse_tree()


class Parser:
    def __init__(self, input_string):
        self.input = input_string
        self.pos = 0

    def parse_tree(self):
        self.skip_spaces()
        if not self.starts_with("("):
            raise ValueError("tree missing")

        self.take("(")
        self.skip_spaces()
        if not self.starts_with(";"):
            raise ValueError("tree with no nodes")

        root = self.parse_node()
        current = root
        while self.pos < len(self.input):
            if self.starts_with(";"):
                node = self.parse_node()
                current.children.append(node)
                current = node
            elif self.starts_with("("):
                current.children.append(self.parse_tree())
            else:
                break

        if not self.starts_with(")"):
            raise ValueError("tree missing")
        self.take(")")

        if self.pos < len(self.input):
            raise ValueError("tree missing")
        return root

    def parse_node(self):
        self.take(";")
        properties = {}
        while self.pos < len(self.input) and self.input[self.pos].isalpha():
            key = self.parse_key()
            values = []
            while True:
                self.skip_spaces()
                if self.starts_with("["):
                    values.append(self.parse_value())
                else:
                    break
            if not values:
                raise ValueError("properties without delimiter")
            properties[key] = values
        return SgfTree(properties, [])

    def parse_key(self):
        start = self.pos
        while self.pos < len(self.input) and self.input[self.pos].isalpha():
            self.pos += 1
        key = self.input[start:self.pos]
        if key != key.upper():
            raise ValueError("property must be in uppercase")
        return key

    def parse_value(self):
        self.take("[")
        value = []
        while self.pos < len(self.input):
            char = self.input[self.pos]
            if char == "]":
                self.pos += 1
                return "".join(value)
            if char == "\\":
                self.pos += 1
                if self.pos < len(self.input):
                    escaped = self.input[self.pos]
                    if escaped == "\n":
                        pass
                    elif escaped.isspace():
                        value.append(" ")
                    else:
                        value.append(escaped)
                    self.pos += 1
                continue
            if char != "\n":
                value.append(" " if char.isspace() else char)
            else:
                value.append(char)
            self.pos += 1
        raise ValueError("properties without delimiter")

    def skip_spaces(self):
        while self.pos < len(self.input) and self.input[self.pos].isspace():
            self.pos += 1

    def starts_with(self, prefix):
        return self.input.startswith(prefix, self.pos)

    def take(self, prefix):
        if not self.starts_with(prefix):
            raise ValueError("tree missing")
        self.pos += len(prefix)
