// The code below is a stub. Just enough to satisfy the compiler.
// In order to pass the tests you can add-to or change any of this code.

#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    InvalidRowCount(usize),
    InvalidColumnCount(usize),
}

pub fn convert(input: &str) -> Result<String, Error> {
    if input.is_empty() {
        return Err(Error::InvalidRowCount(0));
    }

    let rows: Vec<&str> = input.split('\n').collect();
    if rows.len() % 4 != 0 {
        return Err(Error::InvalidRowCount(rows.len()));
    }

    if let Some((&first, rest)) = rows.split_first() {
        let width = first.chars().count();
        if width % 3 != 0 {
            return Err(Error::InvalidColumnCount(width));
        }
        if rest.iter().any(|row| row.chars().count() != width) {
            return Err(Error::InvalidColumnCount(width));
        }
    }

    let glyphs = [
        (" _ ", "| |", "|_|", "   ", '0'),
        ("   ", "  |", "  |", "   ", '1'),
        (" _ ", " _|", "|_ ", "   ", '2'),
        (" _ ", " _|", " _|", "   ", '3'),
        ("   ", "|_|", "  |", "   ", '4'),
        (" _ ", "|_ ", " _|", "   ", '5'),
        (" _ ", "|_ ", "|_|", "   ", '6'),
        (" _ ", "  |", "  |", "   ", '7'),
        (" _ ", "|_|", "|_|", "   ", '8'),
        (" _ ", "|_|", " _|", "   ", '9'),
    ];

    let mut numbers = Vec::new();
    for block in rows.chunks_exact(4) {
        let width = block[0].chars().count();
        let mut number = String::new();
        for column in (0..width).step_by(3) {
            let digit = glyphs
                .iter()
                .find(|&glyph| {
                    glyph
                        .0
                        .chars()
                        .chain(glyph.1.chars())
                        .chain(glyph.2.chars())
                        .chain(glyph.3.chars())
                        .zip(
                            block
                                .iter()
                                .flat_map(|actual| actual.chars().skip(column).take(3)),
                        )
                        .all(|(expected, actual)| expected == actual)
                })
                .map(|glyph| glyph.4)
                .unwrap_or('?');
            number.push(digit);
        }
        numbers.push(number);
    }

    Ok(numbers.join(","))
}
