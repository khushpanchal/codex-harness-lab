// The code below is a stub. Just enough to satisfy the compiler.
// In order to pass the tests you can add-to or change any of this code.

#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    InvalidRowCount(usize),
    InvalidColumnCount(usize),
}

const DIGITS: [&str; 10] = [
    " _ \n| |\n|_|\n   ",
    "   \n  |\n  |\n   ",
    " _ \n _|\n|_ \n   ",
    " _ \n _|\n _|\n   ",
    "   \n|_|\n  |\n   ",
    " _ \n|_ \n _|\n   ",
    " _ \n|_ \n|_|\n   ",
    " _ \n  |\n  |\n   ",
    " _ \n|_|\n|_|\n   ",
    " _ \n|_|\n _|\n   ",
];

pub fn convert(input: &str) -> Result<String, Error> {
    // Treat CRLF as LF so Windows-style input has the same geometry.
    let input = input.replace("\r\n", "\n");
    let rows: Vec<&str> = input.split('\n').collect();

    if !rows.len().is_multiple_of(4) {
        return Err(Error::InvalidRowCount(rows.len()));
    }

    let width = rows.first().map_or(0, |row| row.chars().count());
    if rows.iter().any(|row| row.chars().count() != width) {
        return Err(Error::InvalidColumnCount(width));
    }
    if width == 0 || !width.is_multiple_of(3) {
        return Err(Error::InvalidColumnCount(width));
    }

    let groups = rows.chunks_exact(4).map(|group| {
        (0..width / 3)
            .map(|digit| {
                let cell = group
                    .iter()
                    .map(|row| {
                        row.chars().skip(digit * 3).take(3).collect::<String>()
                    })
                    .collect::<Vec<_>>()
                    .join("\n");
                DIGITS.iter().position(|glyph| *glyph == cell)
                    .map(|value| value.to_string())
                    .unwrap_or_else(|| "?".to_string())
            })
            .collect::<String>()
    });

    Ok(groups.collect::<Vec<_>>().join(","))
}
