use std::collections::HashMap;
use std::thread;

pub fn frequency(input: &[&str], worker_count: usize) -> HashMap<char, usize> {
    if input.is_empty() {
        return HashMap::new();
    }

    let worker_count = worker_count.max(1).min(input.len());
    let chunk_size = input.len().div_ceil(worker_count);

    thread::scope(|scope| {
        let workers: Vec<_> = input
            .chunks(chunk_size)
            .map(|texts| {
                scope.spawn(move || {
                    let mut frequencies = HashMap::new();

                    for text in texts {
                        for letter in text.chars().filter(|&letter| letter.is_alphabetic()) {
                            if let Some(lowercase) = letter.to_lowercase().next() {
                                *frequencies.entry(lowercase).or_insert(0) += 1;
                            }
                        }
                    }

                    frequencies
                })
            })
            .collect();

        let mut frequencies = HashMap::new();
        for worker in workers {
            for (letter, count) in worker.join().expect("letter-frequency worker panicked") {
                *frequencies.entry(letter).or_insert(0) += count;
            }
        }

        frequencies
    })
}
