use std::collections::HashMap;
use std::thread;

pub fn frequency(input: &[&str], worker_count: usize) -> HashMap<char, usize> {
    let worker_count = worker_count.max(1).min(input.len().max(1));
    let chunk_size = input.len().div_ceil(worker_count).max(1);

    let mut totals = LetterCounts::default();
    thread::scope(|scope| {
        let handles: Vec<_> = input
            .chunks(chunk_size)
            .map(|texts| {
                scope.spawn(move || {
                    let mut counts = LetterCounts::default();
                    for text in texts {
                        counts.add(text);
                    }
                    counts
                })
            })
            .collect();

        for handle in handles {
            totals.merge(handle.join().expect("letter-counting worker panicked"));
        }
    });

    totals.into_map()
}

#[derive(Default)]
struct LetterCounts {
    ascii: [usize; 26],
    unicode: HashMap<char, usize>,
}

impl LetterCounts {
    fn add(&mut self, text: &str) {
        for chr in text.chars().filter(|chr| chr.is_alphabetic()) {
            // There is no Unicode-aware `to_ascii_lowercase`, so branch before
            // converting. This keeps the common English text path fast.
            if chr.is_ascii() {
                let lower = chr.to_ascii_lowercase();
                if lower.is_ascii_lowercase() {
                    self.ascii[(lower as usize) - usize::from(b'a')] += 1;
                }
            } else {
                if let Some(lower) = chr.to_lowercase().next() {
                    *self.unicode.entry(lower).or_insert(0) += 1;
                }
            }
        }
    }

    fn merge(&mut self, other: LetterCounts) {
        for (index, count) in other.ascii.into_iter().enumerate() {
            self.ascii[index] += count;
        }

        for (chr, count) in other.unicode {
            *self.unicode.entry(chr).or_insert(0) += count;
        }
    }

    fn into_map(mut self) -> HashMap<char, usize> {
        let mut map = std::mem::take(&mut self.unicode);
        for (index, count) in self.ascii.into_iter().enumerate() {
            if count != 0 {
                map.insert(char::from(b'a' + index as u8), count);
            }
        }
        map
    }
}
