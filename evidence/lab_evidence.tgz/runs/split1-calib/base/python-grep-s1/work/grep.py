def grep(pattern, flags, files):
    flags = set(flags)
    case_insensitive = "i" in flags
    invert = "v" in flags
    whole_line = "x" in flags
    line_numbers = "n" in flags
    names_only = "l" in flags

    def matches(line):
        if case_insensitive:
            line = line.casefold()
            pattern_folded = pattern.casefold()
            return line == pattern_folded if whole_line else pattern_folded in line
        return line == pattern if whole_line else pattern in line

    result = []
    for filename in files:
        file_matches = []
        with open(filename) as file:
            for line_number, line in enumerate(file.read().splitlines(), start=1):
                if invert ^ matches(line):
                    if names_only:
                        break
                    prefix = ""
                    if len(files) > 1:
                        prefix += filename + ":"
                    if line_numbers:
                        prefix += str(line_number) + ":"
                    file_matches.append(prefix + line)

        if file_matches:
            result.extend([filename] if names_only else file_matches)

    return "".join(line + "\n" for line in result)
