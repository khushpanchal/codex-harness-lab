import re


_NUMBER = r"-?\d+"
_OPERATION = r"(?:(?:multiplied|divided)\s+by|[+-]|plus|minus)"
_TOKEN = rf"({_NUMBER}|{_OPERATION})"
_UNSUPPORTED_WORDS = {
    "times", "over", "cubed", "squared", "raised", "to", "the", "power",
}


def answer(question):
    if not isinstance(question, str):
        raise ValueError("syntax error")

    match = re.fullmatch(r"\s*What is (.*?)\?\s*", question, flags=re.IGNORECASE)
    if match is None:
        raise ValueError("syntax error")

    expression = match.group(1).strip()
    if not expression:
        raise ValueError("syntax error")

    tokenized = re.fullmatch(rf"(?:{_NUMBER}|{_OPERATION})(?:\s+(?:{_NUMBER}|{_OPERATION}))*", expression, flags=re.IGNORECASE)
    if tokenized is None:
        for word in expression.split():
            if word.lower() in _UNSUPPORTED_WORDS:
                raise ValueError("unknown operation")
        raise ValueError("syntax error")

    tokens = re.findall(_TOKEN, expression, flags=re.IGNORECASE)

    if not tokens or (len(tokens) != 1 and (len(tokens) < 3 or len(tokens) % 2 == 0)):
        raise ValueError("syntax error")

    try:
        value = int(tokens[0])
        for index in range(1, len(tokens), 2):
            operation = tokens[index].lower()
            operand = int(tokens[index + 1])
            if operation in ("plus", "+"):
                value += operand
            elif operation in ("minus", "-"):
                value -= operand
            elif operation == "multiplied by":
                value *= operand
            elif operation == "divided by":
                value //= operand
            else:
                raise ValueError("unknown operation")
    except (IndexError, ValueError) as error:
        if str(error) == "unknown operation":
            raise
        raise ValueError("syntax error") from None

    return value
