use fizzy::*;

#[test]
fn custom_rules_and_joined_words() {
    let actual = Fizzy::<u64>::new()
        .add_matcher(Matcher::new(|n| n % 2 == 0, "even"))
        .add_matcher(Matcher::new(|n| n % 7 == 0, "seven"))
        .apply(1..=15)
        .collect::<Vec<_>>();

    assert_eq!(
        actual,
        ["1", "even", "3", "even", "5", "even7", "7", "even"]
    );
}

#[test]
fn works_for_collatz() {
    let fizzy = fizz_buzz::<u128>();
    let collatz = std::iter::successors(Some(7u128), |n| match n % 2 {
        0 => Some(n / 2),
        _ => Some(3 * n + 1),
    });

    let actual: Vec<_> = fizzy.apply(collatz).take(7).collect();
    assert_eq!(actual, ["7", "22", "11", "fizz", "17", "52", "26"]);
}
