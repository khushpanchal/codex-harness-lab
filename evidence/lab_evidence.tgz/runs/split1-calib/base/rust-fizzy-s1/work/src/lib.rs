/// A Matcher is a single rule of fizzbuzz: given a function on T, should
/// a word be substituted in? If yes, which word?
pub struct Matcher<T> {
    matcher: Box<dyn Fn(&T) -> bool>,
    substitution: String,
}

impl<T> Matcher<T> {
    pub fn new<F, S>(matcher: F, subs: S) -> Matcher<T>
    where
        F: Fn(&T) -> bool + 'static,
        S: Into<String>,
    {
        Matcher {
            matcher: Box::new(matcher),
            substitution: subs.into(),
        }
    }
}

/// A Fizzy is a set of matchers, which may be applied to an iterator.
///
/// Strictly speaking, it's usually more idiomatic to use `iter.map()` than to
/// consume an iterator with an `apply` method. Given a Fizzy instance, it's
/// pretty straightforward to construct a closure which applies it to all
/// elements of the iterator. However, we're using the `apply` pattern
/// here because it's a simpler interface for students to implement.
///
/// Also, it's a good excuse to try out using impl trait.
pub struct Fizzy<T> {
    matchers: Vec<Matcher<T>>,
}

impl<T> Fizzy<T> {
    pub fn new() -> Self {
        Fizzy {
            matchers: Vec::new(),
        }
    }

    // feel free to change the signature to `mut self` if you like
    #[must_use]
    pub fn add_matcher(mut self, matcher: Matcher<T>) -> Self {
        self.matchers.push(matcher);
        self
    }

    /// map this fizzy onto every element of an iterator, returning a new iterator
    pub fn apply<I>(self, iter: I) -> impl Iterator<Item = String>
    where
        T: std::fmt::Display,
        I: Iterator<Item = T>,
    {
        let matchers = self.matchers;
        iter.map(move |value| {
            let words = matchers
                .iter()
                .filter(|Matcher { matcher, .. }| matcher(&value))
                .map(|Matcher { substitution, .. }| substitution.as_str())
                .collect::<Vec<_>>();

            if words.is_empty() {
                value.to_string()
            } else {
                words.join("")
            }
        })
    }
}

impl<T> Default for Fizzy<T> {
    fn default() -> Self {
        Self::new()
    }
}

/// convenience function: return a Fizzy which applies the standard fizz-buzz rules
pub fn fizz_buzz<T>() -> Fizzy<T>
where
    T: std::ops::Rem<Output = T> + PartialEq<T> + From<u8> + Clone + 'static,
{
    Fizzy::new()
        .add_matcher(matcher(3u8, "fizz"))
        .add_matcher(matcher(5u8, "buzz"))
}

/// convenience function for a rule which substitutes `word` for multiples of `multiple`
pub fn matcher<T, S>(multiple: u8, word: S) -> Matcher<T>
where
    S: Into<String>,
    T: std::ops::Rem<Output = T> + PartialEq<T> + From<u8> + Clone + 'static,
{
    let divisor = T::from(multiple);
    Matcher::new(
        move |value: &T| {
            let value = value.clone();
            value % divisor.clone() == T::from(0u8)
        },
        word,
    )
}
