class SgfTree:
    def __init__(self, properties=None, children=None):
        self.properties = properties or {}
        self.children = children or []

    def __eq__(self, other):
        if not isinstance(other, SgfTree):
            return False
        for key, value in self.properties.items():
            if key not in other.properties:
                return False
            if other.properties[key] != value:
                return False
        for key in other.properties.keys():
            if key not in self.properties:
                return False
        if len(self.children) != len(other.children):
            return False
        for child, other_child in zip(self.children, other.children):
            if child != other_child:
                return False
        return True

    def __ne__(self, other):
        return not self == other


def parse(input_string):
    parser = SgfParser(input_string)
    tree = parser.parse_tree()
    parser.expect_end()
    return tree


class SgfParser:
    def __init__(self, source):
        self.source = source
        self.position = 0

    def parse_tree(self):
        if self.at_end() or self.peek() != "(":
            raise ValueError("tree missing")
        self.advance()
        if self.at_end() or self.peek() != ";":
            raise ValueError("tree with no nodes")

        first = self.parse_node()
        children = []
        while self.position < len(self.source):
            char = self.peek()
            if char == ";":
                children.append(self.parse_node())
            elif char == "(":
                children.append(self.parse_tree())
            elif char == ")":
                break
            else:
                raise ValueError("tree missing")

        if self.at_end() or self.peek() != ")":
            raise ValueError("tree missing")
        self.advance()

        return SgfTree(first, children)

    def parse_node(self):
        self.expect_node_start()
        properties = {}
        if self.position < len(self.source) and self.peek().isalpha() and not self.peek().isupper():
            self.parse_key()

        while self.position < len(self.source) and self.peek().isupper():
            key = self.parse_key()
            values = []
            while self.position < len(self.source) and self.peek() == "[":
                values.append(self.parse_value())
            if not values:
                raise ValueError("properties without delimiter")
            properties[key] = values
        return SgfTree(properties, [])

    def expect_node_start(self):
        if self.at_end() or self.peek() != ";":
            raise ValueError("tree with no nodes")
        self.advance()

    def expect_end(self):
        if not self.at_end():
            raise ValueError("tree missing")

    def parse_key(self):
        start = self.position
        while self.position < len(self.source) and self.peek().isalpha():
            self.advance()
        key = self.source[start:self.position]
        if key != key.upper() or not key:
            raise ValueError("property must be in uppercase")
        return key

    def parse_value(self):
        if self.at_end() or self.peek() != "[":
            raise ValueError("properties without delimiter")
        self.advance()
        value = []
        while self.position < len(self.source) and self.peek() != "]":
            char = self.peek()
            if char == "\\":
                self.advance()
                if self.at_end():
                    raise ValueError("properties without delimiter")
                escaped = self.peek()
                if escaped == "\n":
                    value.append("")
                elif escaped.isspace():
                    value.append(" ")
                else:
                    value.append(escaped)
            elif char.isspace():
                value.append(" " if char != "\n" else "\n")
            else:
                value.append(char)
            self.advance()
        if self.at_end():
            raise ValueError("properties without delimiter")
        self.advance()
        return "".join(value)

    def peek(self):
        return self.source[self.position]

    def advance(self):
        self.position += 1

    def at_end(self):
        return self.position >= len(self.source)
