#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    NotEnoughPinsLeft,
    GameComplete,
}

pub struct BowlingGame {
    rolls: Vec<u16>,
}

impl BowlingGame {
    pub fn new() -> Self {
        Self { rolls: Vec::new() }
    }

    pub fn roll(&mut self, pins: u16) -> Result<(), Error> {
        if pins > 10 {
            return Err(Error::NotEnoughPinsLeft);
        }

        if self.is_complete() {
            return Err(Error::GameComplete);
        }

        let pins_remaining = self.pins_remaining_for_next_roll();
        if pins > pins_remaining {
            return Err(Error::NotEnoughPinsLeft);
        }

        self.rolls.push(pins);
        Ok(())
    }

    pub fn score(&self) -> Option<u16> {
        if !self.is_complete() {
            return None;
        }

        let mut total = 0;
        let mut roll = 0;

        for _frame in 0..10 {
            if self.rolls[roll] == 10 {
                total += 10 + self.rolls[roll + 1] + self.rolls[roll + 2];
                roll += 1;
            } else {
                total += self.rolls[roll] + self.rolls[roll + 1];
                if self.rolls[roll] + self.rolls[roll + 1] == 10 {
                    total += self.rolls[roll + 2];
                }
                roll += 2;
            }
        }

        Some(total)
    }

    fn pins_remaining_for_next_roll(&self) -> u16 {
        let mut roll = 0;

        for _frame in 0..9 {
            if roll >= self.rolls.len() {
                return 10;
            }

            if self.rolls[roll] == 10 {
                roll += 1;
            } else if roll + 1 == self.rolls.len() {
                return 10 - self.rolls[roll];
            } else {
                roll += 2;
            }
        }

        match self.rolls.len() - roll {
            0 => 10,
            1 => {
                if self.rolls[roll] == 10 {
                    10
                } else {
                    10 - self.rolls[roll]
                }
            }
            2 => {
                if self.rolls[roll] == 10 && self.rolls[roll + 1] == 10 {
                    10
                } else if self.rolls[roll] == 10 {
                    10 - self.rolls[roll + 1]
                } else if self.rolls[roll] + self.rolls[roll + 1] == 10 {
                    10
                } else {
                    // The game is complete, so this value will not be used.
                    0
                }
            }
            _ => 0,
        }
    }

    fn is_complete(&self) -> bool {
        let mut roll = 0;

        for _frame in 0..9 {
            if roll >= self.rolls.len() {
                return false;
            }
            roll += if self.rolls[roll] == 10 { 1 } else { 2 };

            if roll > self.rolls.len() {
                return false;
            }
        }

        let tenth = self.rolls.len() - roll;
        if tenth < 2 {
            return false;
        }

        let first = self.rolls[roll];
        let second = self.rolls[roll + 1];

        match (first, second) {
            (10, 10) => tenth == 3,
            (10, _) => true,
            _ if first + second == 10 => tenth == 3,
            _ => tenth == 2,
        }
    }
}
