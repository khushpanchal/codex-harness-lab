// You should change this.
//
// Depending on your implementation, there are a variety of potential errors
// which might occur. They aren't checked by the test suite in order to
// allow the greatest freedom of implementation, but real libraries should
// provide useful, descriptive errors so that downstream code can react
// appropriately.
//
// One common idiom is to define an Error enum which wraps all potential
// errors. Another common idiom is to use a helper type such as failure::Error
// which does more or less the same thing but automatically.
#[derive(Debug)]
pub struct Error;

const SHARPS: [&str; 12] = [
    "A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#",
];
const FLATS: [&str; 12] = [
    "A", "Bb", "B", "C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab",
];
const FLAT_TONICS: [&str; 6] = ["F", "Bb", "Eb", "Ab", "Db", "Gb"];

pub struct Scale(Vec<String>);

fn normalized_tonic(tonic: &str) -> Option<String> {
    let mut chars = tonic.chars();
    let letter = chars.next()?.to_ascii_uppercase();
    let accidental = match chars.next() {
        None => "",
        Some('#') if chars.next().is_none() => "#",
        Some('b') if chars.next().is_none() => "b",
        Some(_) => return None,
    };
    Some(format!("{letter}{accidental}"))
}

fn tonic_index(tonic: &str) -> Option<usize> {
    let tonic = normalized_tonic(tonic)?;
    SHARPS.iter().position(|pitch| *pitch == tonic)
}

fn pitch_names(tonic: &str) -> &'static [&'static str; 12] {
    let flats = normalized_tonic(tonic)
        .is_some_and(|tonic| FLAT_TONICS.contains(&tonic.as_str()));
    if flats {
        &FLATS
    } else {
        &SHARPS
    }
}

impl Scale {
    // Store the 12 pitch names in scale order. This makes chromatic and
    // interval-based scales share one representation.
    pub fn new(tonic: &str, intervals: &str) -> Result<Scale, Error> {
        let start = tonic_index(tonic).ok_or(Error)?;
        let pitches = pitch_names(tonic);
        let mut names = Vec::with_capacity(intervals.len());

        let mut index = start;
        names.push(pitches[index].to_string());
        for interval in intervals.chars().filter(|interval| *interval != '-') {
            let step = match interval {
                'm' => 1,
                'M' => 2,
                'A' => 3,
                _ => return Err(Error),
            };
            index = (index + step) % 12;
            names.push(pitches[index].to_string());
        }

        Ok(Scale(names))
    }

    pub fn chromatic(tonic: &str) -> Result<Scale, Error> {
        Scale::new(tonic, "mmmmmmmmmmmm")
    }

    pub fn enumerate(&self) -> Vec<String> {
        self.0.clone()
    }
}
