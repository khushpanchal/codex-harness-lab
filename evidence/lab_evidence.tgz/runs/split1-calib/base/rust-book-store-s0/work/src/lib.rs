/// Calculate the minimum price in cents for a basket of books from a
/// five-volume series.
use std::collections::HashMap;

/// Calculate the minimum price in cents for a basket of books from a
/// five-volume series.
pub fn lowest_price(books: &[u32]) -> u32 {
    let mut counts = [0_u32; 5];
    for &book in books {
        if book == 0 || book > 5 {
            panic!("book title must be between 1 and 5");
        }
        counts[(book - 1) as usize] += 1;
    }
    lowest_price_for_counts(&counts, &mut HashMap::new())
}

fn lowest_price_for_counts(counts: &[u32; 5], cache: &mut HashMap<[u32; 5], u32>) -> u32 {
    if counts.iter().all(|&count| count == 0) {
        return 0;
    }
    if let Some(&price) = cache.get(counts) {
        return price;
    }

    // A solution is a collection of groups with 1 to 5 distinct titles. Build
    // one group now, then solve the remaining multiset recursively. Sorting the
    // counts makes every equivalent grouping share a cache entry.
    let group_prices = [0, 800, 1_520, 2_160, 2_560, 3_000];
    let mut best = u32::MAX;
    for group_size in 1..=5 {
        let mut remaining = *counts;
        let mut titles_in_group = 0;
        for count in &mut remaining {
            if *count > 0 {
                *count -= 1;
                titles_in_group += 1;
            }
        }
        if titles_in_group == group_size {
            let mut sorted = remaining;
            sorted.sort_unstable();
            let candidate = group_prices[group_size] + lowest_price_for_counts(&sorted, cache);
            best = best.min(candidate);
        }
    }

    debug_assert_ne!(best, u32::MAX);
    cache.insert(*counts, best);
    best
}
