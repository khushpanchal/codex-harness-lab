def can_chain(dominoes):
    dominoes = [tuple(domino) for domino in dominoes]
    if not dominoes:
        return []

    adjacency = {value: {} for value in range(7)}
    for low, high in (tuple(sorted(domino)) for domino in dominoes):
        adjacency[low][high] = adjacency[low].get(high, 0) + 1
        if low != high:
            adjacency[high][low] = adjacency[high].get(low, 0) + 1

    used_vertices = [value for value in range(7) if adjacency[value]]
    # A self-loop contributes two endpoints to its vertex.
    if any(
        sum(adjacency[value].values()) + (adjacency[value].get(value, 0) % 2)
        for value in used_vertices
    ):
        return None

    # A quick traversal is enough to check that all used vertices are connected.
    stack = [used_vertices[0]]
    seen = {used_vertices[0]}
    while stack:
        value = stack.pop()
        for neighbor in adjacency[value]:
            if neighbor not in seen:
                seen.add(neighbor)
                stack.append(neighbor)
    if len(seen) != len(used_vertices):
        return None

    # Hierholzer's algorithm finds an Euler circuit; each circuit edge is one
    # oriented domino.
    start = used_vertices[0]
    circuit = []
    vertex_stack = [start]
    while vertex_stack:
        value = vertex_stack[-1]
        neighbor = next((item for item, count in adjacency[value].items() if count), None)
        if neighbor is None:
            circuit.append(value)
            vertex_stack.pop()
        else:
            if value == neighbor:
                # A doublet is one undirected edge represented by one counter.
                adjacency[value][value] -= 2
            else:
                adjacency[value][neighbor] -= 1
                adjacency[neighbor][value] -= 1
            vertex_stack.append(neighbor)

    circuit.reverse()
    return [(circuit[index], circuit[index + 1]) for index in range(len(circuit) - 1)]
