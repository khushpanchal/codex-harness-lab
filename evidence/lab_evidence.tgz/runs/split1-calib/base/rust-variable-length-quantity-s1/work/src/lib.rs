#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    IncompleteNumber,
}

/// Convert a list of numbers to a stream of bytes encoded with variable length encoding.
pub fn to_bytes(values: &[u32]) -> Vec<u8> {
    let mut encoded = Vec::new();

    for &value in values {
        let mut value = value;
        let start = encoded.len();

        loop {
            encoded.push((value & 0x7f) as u8);
            value >>= 7;
            if value == 0 {
                break;
            }
        }

        for byte in &mut encoded[start + 1..] {
            *byte |= 0x80;
        }
    }

    encoded
}

/// Given a stream of bytes, extract all numbers which are encoded in there.
pub fn from_bytes(bytes: &[u8]) -> Result<Vec<u32>, Error> {
    let mut values = Vec::new();
    let mut value = 0u32;
    let mut started = false;

    for &byte in bytes {
        started = true;
        let Some(shifted) = value
            .checked_mul(0x80)
            .and_then(|value| value.checked_add(u32::from(byte & 0x7f)))
        else {
            return Err(Error::IncompleteNumber);
        };
        value = shifted;

        if byte & 0x80 == 0 {
            values.push(value);
            value = 0;
            started = false;
        }
    }

    if started {
        return Err(Error::IncompleteNumber);
    }

    Ok(values)
}
