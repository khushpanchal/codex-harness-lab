class Record:
    def __init__(self, record_id, parent_id):
        self.record_id = record_id
        self.parent_id = parent_id


class Node:
    def __init__(self, node_id):
        self.node_id = node_id
        self.children = []


def BuildTree(records):
    nodes = {}
    sorted_records = sorted(records, key=lambda record: record.record_id)

    for position, record in enumerate(sorted_records):
        record_id = record.record_id
        if record_id != position:
            raise ValueError("record IDs must be unique and contiguous from 0")
        if record_id == 0:
            if record.parent_id != 0:
                raise ValueError("the root record must have parent ID 0")
        elif record.parent_id >= record_id:
            raise ValueError("a non-root record must have a parent ID lower than its own ID")

        node = Node(record_id)
        nodes[record_id] = node
        if record_id != 0:
            nodes[record.parent_id].children.append(node)

    return nodes.get(0)
