import re


def translate(text):
    VOWELS = "aeiou"
    translated_words = []

    vowels = set(VOWELS)
    for token in re.findall(r"\s+|[A-Za-z]+[^\sA-Za-z]*|[^\sA-Za-z]+", text):
        if token.isspace():
            translated_words.append(token)
            continue

        if not re.match(r"[A-Za-z]+", token):
            translated_words.append(token)
            continue

        word = re.match(r"[A-Za-z]+", token).group()
        suffix = token[len(word):]

        if word[0].lower() in vowels or word.lower().startswith(("xr", "yt")):
            translated_words.append(f"{word}ay{suffix}")
            continue

        qu_match = re.match(r"[^aeiou]*qu", word, flags=re.IGNORECASE)
        y_match = re.match(r"[^aeiou]+y", word, flags=re.IGNORECASE)

        if qu_match:
            index = qu_match.end()
        elif y_match:
            index = y_match.end() - 1
        else:
            index = 0
            while index < len(word) and word[index].lower() not in vowels:
                index += 1

        translated_words.append(f"{word[index:]}{word[:index]}ay{suffix}")

    return "".join(translated_words)
