/// Build a new vector by applying `function` to each input element in order.
pub fn map<I, O, F>(input: Vec<I>, function: F) -> Vec<O>
where
    F: Fn(I) -> O,
{
    let mut output = Vec::with_capacity(input.len());
    for element in input {
        output.push(function(element));
    }
    output
}
