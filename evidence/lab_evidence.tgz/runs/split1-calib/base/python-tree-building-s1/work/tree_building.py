class Record:
    def __init__(self, record_id, parent_id):
        self.record_id = record_id
        self.parent_id = parent_id


class Node:
    def __init__(self, node_id):
        self.node_id = node_id
        self.children = []


def BuildTree(records):
    record_count = len(records)
    if not record_count:
        return None

    nodes = [Node(node_id) for node_id in range(record_count)]
    records_by_id = {}
    for record in records:
        record_id = record.record_id
        if record_id in records_by_id:
            raise ValueError(f"Duplicate record ID: {record_id}")
        if not 0 <= record_id < record_count:
            raise ValueError(f"Record ID out of range: {record_id}")
        records_by_id[record_id] = record

    if set(records_by_id) != set(range(record_count)):
        raise ValueError("Record IDs do not form a continuous sequence")

    root_record = records_by_id[0]
    if root_record.parent_id != 0:
        raise ValueError("Root record must have parent ID 0")

    for record_id in range(1, record_count):
        record = records_by_id[record_id]
        if record.parent_id >= record_id:
            raise ValueError(
                f"Record {record_id} must have a lower parent ID"
            )
        nodes[record.parent_id].children.append(nodes[record_id])

    return nodes[0]
