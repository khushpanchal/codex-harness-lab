
BLACK = "B"
WHITE = "W"
NONE = ""


class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        self.board = board
        self.rows = len(board)
        self.columns = len(board[0]) if self.rows else 0
        if any(len(row) != self.columns for row in board):
            raise ValueError("Board rows must all have the same width")

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        self._validate_coordinate(x, y)
        if self.board[y][x] != " ":
            return NONE, set()

        region = set()
        to_visit = [(x, y)]
        owners = set()
        while to_visit:
            point = to_visit.pop()
            if point in region:
                continue
            region.add(point)
            px, py = point
            for nx, ny in self._neighbors(px, py):
                stone = self.board[ny][nx]
                if stone == " ":
                    if (nx, ny) not in region:
                        to_visit.append((nx, ny))
                else:
                    owners.add(stone)

        if len(owners) != 1:
            return NONE, region
        return owners.pop(), region

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        remaining = {
            (x, y)
            for y, row in enumerate(self.board)
            for x, stone in enumerate(row)
            if stone == " "
        }
        result = {BLACK: set(), WHITE: set(), NONE: set()}

        while remaining:
            point = next(iter(remaining))
            region = self._empty_region(*point)
            result[self._owner_of_region(region)].update(region)
            remaining.difference_update(region)
        return result

    def _empty_region(self, x, y):
        region = set()
        to_visit = [(x, y)]
        while to_visit:
            point = to_visit.pop()
            if point in region:
                continue
            region.add(point)
            px, py = point
            for nx, ny in self._neighbors(px, py):
                if self.board[ny][nx] == " " and (nx, ny) not in region:
                    to_visit.append((nx, ny))
        return region

    def _owner_of_region(self, region):
        owners = set()
        for x, y in region:
            for nx, ny in self._neighbors(x, y):
                stone = self.board[ny][nx]
                if stone != " ":
                    owners.add(stone)
        return owners.pop() if len(owners) == 1 else NONE

    def _neighbors(self, x, y):
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.columns and 0 <= ny < self.rows:
                yield nx, ny

    def _validate_coordinate(self, x, y):
        if not (isinstance(x, int) and isinstance(y, int)):
            raise ValueError("Invalid coordinate")
        if not (0 <= x < self.columns and 0 <= y < self.rows):
            raise ValueError("Invalid coordinate")
