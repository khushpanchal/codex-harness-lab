def can_chain(dominoes):
    """Return one closed chain using every domino, or None if impossible."""
    dominoes = [tuple(domino) for domino in dominoes]
    if not dominoes:
        return []

    stones = dominoes
    remaining = len(dominoes)

    if remaining == 1:
        a, b = stones[0]
        return [a, b] if a == b else None

    adjacency = {}
    for node, (a, b) in enumerate(stones):
        adjacency.setdefault(a, []).append(node)
        if a != b:
            adjacency.setdefault(b, []).append(node)

    # An Eulerian circuit requires all incident values to belong to one
    # connected component and every vertex to have even degree.
    active = sorted(adjacency)
    if any(sum(2 if stones[i][0] == stones[i][1] else 1
               for i in adjacency[value]) % 2 for value in active):
        return None
    seen = {active[0]}
    stack = [active[0]]
    while stack:
        value = stack.pop()
        for stone_index in adjacency[value]:
            for other in stones[stone_index]:
                if other not in seen:
                    seen.add(other)
                    stack.append(other)
    if seen != set(active):
        return None

    # Prefer unique stones first; this tends to expose contradictions sooner
    # when a chain only exists by arranging duplicates in a particular order.
    adjacency = {value: [] for value in active}
    for i, stone in enumerate(stones):
        for value in set(stone):
            adjacency[value].append(i)

    chain = []
    needs = [1] * len(stones)

    def usable(stone_index, value):
        return needs[stone_index] > 0 and value in stones[stone_index]

    def extend(value, remaining_stones):
        if remaining_stones == 0:
            return value == chain[0][0]

        candidates = adjacency[value]
        # Try candidates in a deterministic order, but never leave a used
        # stone as the only apparent choice: that would silently permit reuse.
        for stone_index in candidates:
            if not usable(stone_index, value):
                continue
            a, b = stones[stone_index]
            for other in (b, a):
                if other != value:
                    needs[stone_index] -= 1
                    chain.append((value, other))
                    if extend(other, remaining_stones - 1):
                        return True
                    chain.pop()
                    needs[stone_index] += 1
        return False

    first_stone = next(i for i, count in enumerate(needs) if count)
    needs[first_stone] -= 1
    chain.append(stones[first_stone])
    a, b = stones[first_stone]
    starts = [(a, b)] if a == b else [(a, b), (b, a)]
    for start in starts:
        chain[-1] = start
        if extend(start[1], remaining - 1):
            return chain
    return None
