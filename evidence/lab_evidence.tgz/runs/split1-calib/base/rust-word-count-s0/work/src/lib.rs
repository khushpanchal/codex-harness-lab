use std::collections::HashMap;

/// Count occurrences of words.
pub fn word_count(words: &str) -> HashMap<String, u32> {
    let mut counts = HashMap::new();
    let mut start = None;

    for (i, ch) in words.char_indices().chain([(words.len(), ' ')]) {
        let is_word = ch.is_ascii_alphanumeric();

        if is_word && start.is_none() {
            start = Some(i);
        } else if !is_word {
            if let Some(start) = start.take() {
                let mut end = i;
                while end > start && !words.as_bytes()[end - 1].is_ascii_alphanumeric() {
                    end -= 1;
                }
                let word = &words[start..end];
                if !word.is_empty() {
                    *counts.entry(word.to_lowercase()).or_insert(0) += 1;
                }
            }
        }
    }

    counts
}
