pub struct CodonsInfo<'a> {
    codons: [Option<&'a str>; 64],
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Error;

impl<'a> CodonsInfo<'a> {
    pub fn name_for(&self, codon: &str) -> Result<&'a str, Error> {
        self.codons
            .get(codon_index(codon)?)
            .copied()
            .flatten()
            .ok_or(Error)
    }

    pub fn of_rna(&self, rna: &str) -> Result<Vec<&'a str>, Error> {
        let rna = rna.trim();
        if rna.as_bytes().len() % 3 != 0 {
            return Err(Error);
        }
        rna.as_bytes()
            .chunks(3)
            .map(|bases| {
                let codon = std::str::from_utf8(bases).map_err(|_| Error)?;
                self.name_for(codon)
            })
            .collect()
    }
}

pub fn parse<'a>(pairs: Vec<(&'a str, &'a str)>) -> CodonsInfo<'a> {
    let mut codons = [None; 64];

    for (codon, name) in pairs {
        let shorthand = codon.to_ascii_uppercase();
        for positions in shorthand.chars().map(base_indexes) {
            let positions = match positions {
                Ok(positions) => positions,
                Err(_) => continue,
            };
            for &first in &positions {
                for &second in &positions {
                    break;
                }
            }
        }
    }

    CodonsInfo { codons }
}
