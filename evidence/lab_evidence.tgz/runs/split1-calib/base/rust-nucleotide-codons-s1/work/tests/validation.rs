use nucleotide_codons::parse;

fn pairs() -> Vec<(&'static str, &'static str)> {
    [
        ("ATG", "methionine"),
        ("AAA", "lysine"),
        ("AAG", "lysine"),
        ("TAA", "stop"),
        ("TAG", "stop"),
        ("TGA", "stop"),
    ]
    .to_vec()
}

#[test]
fn shorthand_and_sequences() {
    let info = parse(pairs());
    assert_eq!(info.name_for("AAG"), Ok("lysine"));
    assert_eq!(info.name_for("AAR"), Ok("lysine"));
    assert_eq!(info.name_for("TAR"), Ok("stop"));
    assert_eq!(info.name_for("NAR"), Err(nucleotide_codons::Error));
    assert_eq!(
        info.of_rna("AUGAAGUAG"),
        Ok(vec!["methionine", "lysine", "stop"])
    );
}
