# Game status categories
# Change the values as you see fit
STATUS_WIN = 'win'
STATUS_LOSE = 'lose'
STATUS_ONGOING = 'ongoing'


class Hangman:
    def __init__(self, word):
        if not word:
            raise ValueError("The word must not be empty.")

        self.remaining_guesses = 9
        self.status = STATUS_ONGOING
        self.word = word
        self.guessed_chars = set()

    def guess(self, char):
        if self.status != STATUS_ONGOING:
            raise ValueError("The game has already ended.")

        self.guessed_chars.add(char)
        if char in self.word:
            if all(c in self.guessed_chars for c in self.word):
                self.status = STATUS_WIN
        else:
            self.remaining_guesses -= 1
            if self.remaining_guesses == 0:
                self.status = STATUS_LOSE

    def get_masked_word(self):
        return "".join(c if c in self.guessed_chars else "_" for c in self.word)

    def get_status(self):
        return self.status
