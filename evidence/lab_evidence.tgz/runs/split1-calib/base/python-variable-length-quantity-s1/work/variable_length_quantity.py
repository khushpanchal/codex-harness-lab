def encode(numbers):
    encoded = []
    for number in numbers:
        if not 0 <= number <= 0xFFFFFFFF:
            raise ValueError("number is out of range")

        groups = [number & 0x7F]
        number >>= 7
        while number:
            groups.append((number & 0x7F) | 0x80)
            number >>= 7

        encoded.extend(reversed(groups))
    return encoded


def decode(bytes_):
    decoded = []
    number = 0
    complete = False

    for byte in bytes_:
        if not 0 <= byte <= 0x7F and not byte & 0x80:
            raise ValueError("invalid byte")
        if complete:
            raise ValueError("incomplete sequence")

        number = (number << 7) | (byte & 0x7F)
        complete = not byte & 0x80
        if complete:
            if number > 0xFFFFFFFF:
                raise ValueError("number is out of range")
            decoded.append(number)
            number = 0

    if not complete:
        raise ValueError("incomplete sequence")
    return decoded
