#[derive(PartialEq, Eq, Debug)]
pub enum Bucket {
    One,
    Two,
}

/// A struct to hold your results in.
#[derive(PartialEq, Eq, Debug)]
pub struct BucketStats {
    /// The total number of "moves" it should take to reach the desired number of liters, including
    /// the first fill.
    pub moves: u8,
    /// Which bucket should end up with the desired number of liters? (Either "one" or "two")
    pub goal_bucket: Bucket,
    /// How many liters are left in the other bucket?
    pub other_bucket: u8,
}

use std::collections::VecDeque;

/// Solve the bucket problem
pub fn solve(
    capacity_1: u8,
    capacity_2: u8,
    goal: u8,
    start_bucket: &Bucket,
) -> Option<BucketStats> {
    if goal > capacity_1 || goal > capacity_2 {
        return None;
    }

    let start = start_bucket == &Bucket::One;
    if goal == 0 {
        return Some(BucketStats {
            moves: 0,
            goal_bucket: if start { Bucket::One } else { Bucket::Two },
            other_bucket: 0,
        });
    }

    let mut distances =
        vec![
            u16::MAX;
            usize::from(capacity_1) + 1 + usize::from(capacity_2) * (usize::from(capacity_1) + 1)
        ];
    let index = |amount_1: u8, amount_2: u8| {
        usize::from(amount_1) + usize::from(amount_2) * (usize::from(capacity_1) + 1)
    };
    let mut queue = VecDeque::new();

    // The exercise requires the requested bucket to be filled first.
    let first = if start {
        (capacity_1, 0)
    } else {
        (0, capacity_2)
    };
    distances[index(first.0, first.1)] = 1;
    queue.push_back(first);

    if first.0 == goal || first.1 == goal {
        return Some(BucketStats {
            moves: 1,
            goal_bucket: if first.0 == goal && (first.1 != goal || start) {
                Bucket::One
            } else {
                Bucket::Two
            },
            other_bucket: if first.0 == goal && (first.1 != goal || start) {
                first.1
            } else {
                first.0
            },
        });
    }

    let mut best = None;
    while let Some((amount_1, amount_2)) = queue.pop_front() {
        let distance = distances[index(amount_1, amount_2)];
        if amount_1 == goal || amount_2 == goal {
            let goal_bucket = if amount_1 == goal && (amount_2 != goal || start) {
                Bucket::One
            } else {
                Bucket::Two
            };
            best = Some((
                distance,
                goal_bucket,
                if amount_1 == goal && (amount_2 != goal || start) {
                    amount_2
                } else {
                    amount_1
                },
            ));
            break;
        }

        let pour_1_into_2 = |amount_1: u8, amount_2: u8| {
            let transferred = capacity_2.min(amount_1 + amount_2) - amount_2;
            (amount_1 - transferred, amount_2 + transferred)
        };
        let pour_2_into_1 = |amount_1: u8, amount_2: u8| {
            let transferred = capacity_1.min(amount_1 + amount_2) - amount_1;
            (amount_1 + transferred, amount_2 - transferred)
        };

        let next_states = [
            (capacity_1, amount_2),
            (0, amount_2),
            pour_1_into_2(amount_1, amount_2),
            (amount_1, capacity_2),
            (amount_1, 0),
            pour_2_into_1(amount_1, amount_2),
        ];

        for (next_1, next_2) in next_states {
            if next_1 == amount_1 && next_2 == amount_2 {
                continue;
            }
            // Once we start with a bucket, it may not end empty while the other is full.
            if (start && next_1 == 0 && next_2 == capacity_2)
                || (!start && next_2 == 0 && next_1 == capacity_1)
            {
                continue;
            }
            let next_index = index(next_1, next_2);
            if distances[next_index] > distance + 1 {
                distances[next_index] = distance + 1;
                queue.push_back((next_1, next_2));
            }
        }
    }

    best.and_then(|(moves, goal_bucket, other_bucket)| {
        let moves = u8::try_from(moves).ok()?;
        Some(BucketStats {
            moves,
            goal_bucket,
            other_bucket,
        })
    })
}
