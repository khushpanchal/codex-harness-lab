use std::collections::HashMap;

/// Count occurrences of words.
pub fn word_count(words: &str) -> HashMap<String, u32> {
    let mut counts = HashMap::new();
    let mut token = String::new();

    for char in words.chars().chain(std::iter::once(' ')) {
        if char.is_ascii_alphanumeric() || char == '\'' {
            token.push(char.to_ascii_lowercase());
        } else if !token.is_empty() {
            let word = token.trim_matches('\'');
            if !word.is_empty() {
                *counts.entry(word.to_string()).or_insert(0) += 1;
            }
            token.clear();
        }
    }

    counts
}
