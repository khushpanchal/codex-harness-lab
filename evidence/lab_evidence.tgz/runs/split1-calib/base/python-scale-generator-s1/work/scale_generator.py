class Scale:
    _positions = [
        ("A", None),
        ("A#", "Bb"),
        ("B", None),
        ("C", None),
        ("C#", "Db"),
        ("D", None),
        ("D#", "Eb"),
        ("E", None),
        ("F", None),
        ("F#", "Gb"),
        ("G", None),
        ("G#", "Ab"),
    ]
    _sharp_keys = {
        "major": {"G", "D", "A", "E", "B", "F#", "C"},
        "minor": {"E", "B", "F#", "C#", "G#", "D#"},
    }
    _flat_keys = {
        "major": {"F", "Bb", "Eb", "Ab", "Db", "Gb"},
        "minor": {"D", "G", "C", "F", "Bb", "Eb"},
    }

    def __init__(self, tonic):
        normalized = tonic.strip().replace("♯", "#").replace("♭", "b")
        self.tonic = normalized[0].upper() + normalized[1:]

    def _position(self):
        for index, (sharp, flat) in enumerate(self._positions):
            if self.tonic in (sharp, flat):
                return index
        raise ValueError(f"unknown tonic: {self.tonic}")

    def _use_flats(self):
        letter = self.tonic[0]
        quality = "minor" if letter.islower() else "major"
        if self.tonic in self._flat_keys[quality]:
            return True
        if self.tonic in self._sharp_keys[quality]:
            return False
        # Accidentals not represented in the signature table generally use
        # their written accidental for an ascending chromatic scale.
        return self.tonic.endswith("b")

    def _names(self):
        return [flat if self._use_flats() and flat else sharp for sharp, flat in self._positions]

    def chromatic(self):
        position = self._position()
        return self._names()[position:] + self._names()[:position]

    def interval(self, intervals):
        names = self.chromatic()
        step = {"m": 1, "M": 2, "A": 3, "S": 1, "H": 1, "T": 2, "W": 2}
        position = self._position()
        result = [self.tonic]
        for chromatic_step in intervals:
            position = (position + step[chromatic_step]) % 12
            result.append(names[position])
        return result
