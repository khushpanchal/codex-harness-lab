def grep(pattern, flags, files):
    number_lines = "-n" in flags
    list_files = "-l" in flags
    ignore_case = "-i" in flags
    invert_match = "-v" in flags
    match_entire_line = "-x" in flags

    if ignore_case:
        pattern = pattern.lower()

    lines = []
    matching_files = []
    for filename in files:
        has_match = False
        with open(filename, encoding="utf-8") as input_file:
            for line_number, line in enumerate(input_file, start=1):
                contents = line.rstrip("\n")
                candidate = contents.lower() if ignore_case else contents
                if match_entire_line:
                    matches = candidate == pattern
                else:
                    matches = pattern in candidate

                if matches != invert_match:
                    has_match = True
                    if list_files:
                        continue
                    result = contents
                    if number_lines:
                        result = f"{line_number}:{result}"
                    if len(files) > 1:
                        result = f"{filename}:{result}"
                    lines.append(result)

        if has_match and filename not in matching_files:
            matching_files.append(filename)

    if list_files:
        return "".join(f"{filename}\n" for filename in matching_files)
    return "".join(f"{line}\n" for line in lines)
