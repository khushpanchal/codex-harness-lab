def recite(start, take=1):
    if not isinstance(start, int) or not isinstance(take, int):
        raise TypeError("start and take must be integers")
    if not 0 <= start <= 99:
        raise ValueError("start must be between 0 and 99")
    if not 1 <= take <= start + 1:
        raise ValueError("take must be a positive number of available verses")

    def bottles(count):
        if count == 0:
            return "no more bottles"
        if count == 1:
            return "1 bottle"
        return f"{count} bottles"

    verses = []
    for count in range(max(start, 0), max(start - take, -1), -1):
        current = bottles(count)
        verses.append(f"{current.capitalize()} of beer on the wall, {current} of beer.")

        remaining = count - 1
        if count == 1:
            action = "Take it down and pass it around"
        else:
            action = "Take one down and pass it around"
        verses.append(f"{action}, {bottles(remaining)} of beer on the wall.")

        if remaining == 0:
            verses.append(
                "No more bottles of beer on the wall, no more bottles of beer."
            )
            verses.append(
                "Go to the store and buy some more, 99 bottles of beer on the wall."
            )
            break

    return verses
