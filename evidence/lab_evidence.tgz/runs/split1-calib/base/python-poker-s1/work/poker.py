def best_hands(hands):
    def parse(hand):
        cards = hand.split()
        return [(rank_value(card[:-1]), card[-1]) for card in cards]


    def rank_value(rank):
        values = {character: value for value, character in enumerate(
            "2 3 4 5 6 7 8 9 10 J Q K A".split(), start=2
        )}
        return values[rank]


    def score(hand):
        cards = parse(hand)
        ranks = sorted((rank for rank, _ in cards), reverse=True)
        counts = {}
        for rank in ranks:
            counts[rank] = counts.get(rank, 0) + 1
        groups = sorted(counts.items(), key=lambda item: (item[1], item[0]), reverse=True)
        ordered_ranks = tuple(rank for rank, _ in groups)
        suits = {suit for _, suit in cards}
        flush = len(suits) == 1

        # Aces may lead a five-high straight (A 2 3 4 5).
        ace_low = ranks == [14, 5, 4, 3, 2]
        straight = len(ranks) == 5 and (ace_low or all(
            high - low == -1 for low, high in zip(ranks, ranks[1:])
        ))
        straight_high = 5 if ace_low else (ranks[0] if straight else 0)

        if flush and straight and ranks == [14, 13, 12, 11, 10]:
            category, ordered_ranks = 9, (14,)
        elif flush and straight:
            category, ordered_ranks = 9, (straight_high,)
        elif counts[ranks[0]] == 4:
            category = 8
        elif len(groups) == 2 and groups[0][1] == 3:
            category = 7
        elif flush:
            category = 6
        elif straight:
            category, ordered_ranks = 5, (straight_high,)
        elif counts[ranks[0]] == 3:
            category = 4
        elif len(groups) == 3 and groups[0][1] == 2:
            category = 3
        elif len(groups) == 3 and groups[0][1] == 1:
            category = 2
        else:
            category = 1
        return category, ordered_ranks


    if not hands:
        return []
    top_score = max(score(hand) for hand in hands)
    return [hand for hand in hands if score(hand) == top_score]
