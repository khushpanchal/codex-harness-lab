class Scale:
    _SHARP_CHROMATIC = ["A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#"]
    _FLAT_CHROMATIC = ["A", "Bb", "B", "C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab"]
    _SHARP_MAJOR = {"C", "G", "D", "A", "E", "B", "F#"}
    _SHARP_MINOR = {"a", "e", "b", "f#", "c#", "g#", "d#"}
    _INTERVAL_SIZES = {"m": 1, "M": 2, "A": 3}

    def __init__(self, tonic):
        if not isinstance(tonic, str):
            raise ValueError("tonic must be a note such as C, F#, or Bb")
        tonic = tonic.strip()
        if len(tonic) not in (1, 2):
            raise ValueError("tonic must be a note such as C, F#, or Bb")
        accidental = tonic[1:]
        if accidental.lower() not in ("", "#", "b"):
            raise ValueError("invalid accidental")
        if tonic[0].upper() not in "ABCDEFG":
            raise ValueError("invalid note letter")
        self.is_minor = tonic[0].islower()
        self.tonic = tonic[0].upper() + ("#" if accidental.lower() == "#" else "b" if accidental else "")

    @property
    def _compatible_tonic(self):
        if self._uses_sharps():
            return self.tonic.replace("b", "#")
        return self.tonic.replace("#", "b")

    def chromatic(self):
        scale = self._sharp_chromatic() if self._uses_sharps() else self._flat_chromatic()
        return scale

    def interval(self, intervals):
        if not intervals:
            return [self.tonic]
        if any(size not in self._INTERVAL_SIZES for size in intervals):
            raise ValueError("intervals may only contain m, M, and A")

        chromatic = self.chromatic()
        scale = [chromatic[0]]
        position = 0
        for size in intervals:
            position = (position + self._INTERVAL_SIZES[size]) % len(chromatic)
            scale.append(chromatic[position])
        return scale

    def _uses_sharps(self):
        # Keys in the supplied table use the table's spelling. For other
        # tonics, spell according to the tonic's own accidental.
        if self.is_minor:
            minor = self.tonic[0].lower() + self.tonic[1:]
            if minor in self._SHARP_MINOR:
                return True
            if minor in {"d", "g", "c", "f", "bb", "eb"}:
                return False
        else:
            if self.tonic in self._SHARP_MAJOR:
                return True
            if self.tonic in {"F", "Bb", "Eb", "Ab", "Db", "Gb"}:
                return False
        return not self.tonic.endswith("b")

    def _sharp_chromatic(self):
        base = self._SHARP_CHROMATIC
        start = base.index(self._compatible_tonic)
        return base[start:] + base[:start]

    def _flat_chromatic(self):
        base = self._FLAT_CHROMATIC
        start = base.index(self._compatible_tonic)
        return base[start:] + base[:start]
