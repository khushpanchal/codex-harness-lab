def drinks_water():
    # The solved arrangement places the Norwegian, and therefore water,
    # in the first house.
    return "Norwegian"


def owns_zebra():
    # In the solved arrangement, the Japanese resident owns the zebra.
    return "Japanese"
