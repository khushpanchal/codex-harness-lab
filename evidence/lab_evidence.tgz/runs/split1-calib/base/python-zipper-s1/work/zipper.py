class Zipper:
    def __init__(self, focus, parents):
        self.focus = focus
        self.parents = parents

    @staticmethod
    def from_tree(tree):
        return Zipper(tree, ())

    def value(self):
        return self.focus["value"]

    def set_value(self, value):
        return Zipper({**self.focus, "value": value}, self.parents)

    def left(self):
        left = self.focus["left"]
        if left is None:
            return None
        context = self.parents + (("left", self.focus["value"], self.focus["right"]),)
        return Zipper(left, context)

    def set_left(self, tree):
        return Zipper({**self.focus, "left": tree}, self.parents)

    def right(self):
        right = self.focus["right"]
        if right is None:
            return None
        context = self.parents + (("right", self.focus["value"], self.focus["left"]),)
        return Zipper(right, context)

    def set_right(self, tree):
        return Zipper({**self.focus, "right": tree}, self.parents)

    def up(self):
        if not self.parents:
            return None
        direction, parent_value, sibling = self.parents[-1]
        if direction == "left":
            parent = {"value": parent_value, "left": self.focus, "right": sibling}
        else:
            parent = {"value": parent_value, "left": sibling, "right": self.focus}
        return Zipper(parent, self.parents[:-1])

    def to_tree(self):
        zipper = self
        while zipper.parents:
            zipper = zipper.up()
        return zipper.focus
