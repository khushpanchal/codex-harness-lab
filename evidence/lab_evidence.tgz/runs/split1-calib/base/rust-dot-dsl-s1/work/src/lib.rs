pub mod graph {
    use std::collections::HashMap;

    use super::graph::graph_items::edge::Edge;
    use super::graph::graph_items::node::Node;

    pub struct Graph {
        pub nodes: Vec<Node>,
        pub edges: Vec<Edge>,
        pub attrs: HashMap<String, String>,
    }

    impl Graph {
        pub fn new() -> Self {
            Self {
                nodes: Vec::new(),
                edges: Vec::new(),
                attrs: HashMap::new(),
            }
        }

        pub fn node(mut self, node: Node) -> Self {
            self.nodes.push(node);
            self
        }

        pub fn edge(mut self, edge: Edge) -> Self {
            self.edges.push(edge);
            self
        }

        pub fn attr(mut self, (key, value): (&str, &str)) -> Self {
            self.attrs.insert(key.into(), value.into());
            self
        }

        pub fn graph(self) -> Graph {
            self
        }
    }

    pub mod graph_items {
        pub mod edge {
            use std::collections::HashMap;

            pub struct Edge {
                pub node1: String,
                pub node2: String,
                pub attrs: HashMap<String, String>,
            }

            impl Edge {
                pub fn new(node1: &str, node2: &str) -> Self {
                    Self {
                        node1: node1.into(),
                        node2: node2.into(),
                        attrs: HashMap::new(),
                    }
                }

                pub fn attr(mut self, (key, value): (&str, &str)) -> Self {
                    self.attrs.insert(key.into(), value.into());
                    self
                }
            }
        }

        pub mod node {
            use std::collections::HashMap;

            pub struct Node {
                pub id: String,
                pub attrs: HashMap<String, String>,
            }

            impl Node {
                pub fn new(id: &str) -> Self {
                    Self {
                        id: id.into(),
                        attrs: HashMap::new(),
                    }
                }

                pub fn attr(mut self, (key, value): (&str, &str)) -> Self {
                    self.attrs.insert(key.into(), value.into());
                    self
                }
            }
        }
    }
}
