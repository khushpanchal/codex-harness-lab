pub struct Luhn {
    digits: String,
}

impl Luhn {
    pub fn is_valid(&self) -> bool {
        let digits: Vec<u8> = self
            .digits
            .bytes()
            .filter(|byte| !byte.is_ascii_whitespace())
            .collect();

        if digits.len() < 2 {
            return false;
        }

        let mut sum = 0;
        for (index, digit) in digits.iter().copied().enumerate() {
            if !digit.is_ascii_digit() {
                return false;
            }

            let from_right = digits.len() - index - 1;
            let mut value = (digit - b'0') as u32;
            if from_right % 2 == 1 {
                value *= 2;
                if value > 9 {
                    value -= 9;
                }
            }
            sum += value;
        }

        sum % 10 == 0
    }
}

impl<T: ToString> From<T> for Luhn {
    fn from(input: T) -> Self {
        Luhn {
            digits: input.to_string(),
        }
    }
}
