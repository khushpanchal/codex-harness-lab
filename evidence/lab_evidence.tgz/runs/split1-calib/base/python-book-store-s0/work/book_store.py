from functools import lru_cache


def total(basket):
    """Return the lowest possible price for basket, in cents."""
    discounts = {1: 0, 2: 5, 3: 10, 4: 20, 5: 25}
    initial = tuple(sorted((basket.count(book) for book in range(1, 6)), reverse=True))

    @lru_cache(None)
    def cheapest(counts):
        if not counts:
            return 0

        # If any books remain, a group can always use the most common titles.
        distinct = len(counts)
        return min(
            size * 800 * (100 - discounts[size]) // 100
            + cheapest(tuple(sorted(counts[:size][::-1] + counts[size:], reverse=True)))
            for size in range(1, distinct + 1)
        )

    return cheapest(initial)
