use std::borrow::Borrow;

/// A munger which XORs a key with some data
#[derive(Clone)]
pub struct Xorcism<'a> {
    key: &'a [u8],
    position: usize,
}

impl<'a> Xorcism<'a> {
    /// Create a new Xorcism munger from a key
    ///
    /// Should accept anything which has a cheap conversion to a byte slice.
    pub fn new<Key>(key: &'a Key) -> Xorcism<'a>
    where
        Key: AsRef<[u8]> + ?Sized,
    {
        Xorcism {
            key: key.as_ref(),
            position: 0,
        }
    }

    /// XOR each byte of the input buffer with a byte from the key.
    ///
    /// Note that this is stateful: repeated calls are likely to produce different results,
    /// even with identical inputs.
    pub fn munge_in_place(&mut self, data: &mut [u8]) {
        if self.key.is_empty() {
            return;
        }

        for byte in data {
            *byte ^= self.key[self.position];
            self.position = (self.position + 1) % self.key.len();
        }
    }

    /// XOR each byte of the data with a byte from the key.
    ///
    /// Note that this is stateful: repeated calls are likely to produce different results,
    /// even with identical inputs.
    ///
    /// Should accept anything which has a cheap conversion to a byte iterator.
    /// Shouldn't matter whether the byte iterator's values are owned or borrowed.
    pub fn munge<'b, Data>(&'b mut self, data: Data) -> impl Iterator<Item = u8> + 'b
    where
        Data: IntoIterator,
        Data::Item: Borrow<u8>,
        Data::IntoIter: 'b,
    {
        let key = self.key;
        let position = &mut self.position;
        data.into_iter()
            .map(move |byte: <Data as IntoIterator>::Item| {
                if key.is_empty() {
                    *byte.borrow()
                } else {
                    let result = *byte.borrow() ^ key[*position];
                    *position = (*position + 1) % key.len();
                    result
                }
            })
    }
}

#[cfg(feature = "io")]
mod io_adapters {
    use super::Xorcism;
    use std::io::{Read, Write};

    pub struct XorcismReader<'a, R> {
        xorcism: Xorcism<'a>,
        inner: R,
    }

    impl<'a, R: Read> Read for XorcismReader<'a, R> {
        fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
            let count = self.inner.read(buf)?;
            self.xorcism.munge_in_place(&mut buf[..count]);
            Ok(count)
        }
    }

    pub struct XorcismWriter<'a, W> {
        xorcism: Xorcism<'a>,
        inner: W,
    }

    impl<'a, W: Write> Write for XorcismWriter<'a, W> {
        fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
            // This fixed-size buffer avoids allocating while streaming.
            let mut encoded = [0_u8; 4096];
            let count = buf.len().min(encoded.len());
            encoded[..count].copy_from_slice(&buf[..count]);
            self.xorcism.munge_in_place(&mut encoded[..count]);
            self.inner.write_all(&encoded[..count])?;
            Ok(count)
        }

        fn flush(&mut self) -> std::io::Result<()> {
            self.inner.flush()
        }
    }

    impl<'a> Xorcism<'a> {
        pub fn reader<R: Read>(self, reader: R) -> XorcismReader<'a, R> {
            XorcismReader {
                xorcism: self,
                inner: reader,
            }
        }

        pub fn writer<W: Write>(self, writer: W) -> XorcismWriter<'a, W> {
            XorcismWriter {
                xorcism: self,
                inner: writer,
            }
        }
    }
}
