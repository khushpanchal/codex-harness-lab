from collections import deque
def measure(bucket_one, bucket_two, goal, start_bucket):
    if bucket_one <= 0 or bucket_two <= 0:
        raise ValueError("Bucket sizes must be positive integers.")
    if goal < 0 or goal > bucket_one + bucket_two:
        raise ValueError("The goal cannot be measured with the given buckets.")
    if start_bucket == "one":
        start = (bucket_one, 0)
        forbidden = (0, bucket_two)
    elif start_bucket == "two":
        start = (0, bucket_two)
        forbidden = (bucket_one, 0)
    else:
        raise ValueError("The starting bucket must be either 'one' or 'two'.")

    queue = deque([(start, 1)])
    visited = {start}

    while queue:
        (first, second), actions = queue.popleft()
        if first == goal:
            return actions, "one", second
        if second == goal:
            return actions, "two", first

        pour_into_two = min(first, bucket_two - second)
        pour_into_one = min(second, bucket_one - first)
        possible_next_states = (
            (first - pour_into_two, second + pour_into_two),
            (first + pour_into_one, second - pour_into_one),
            (0, second),
            (first, 0),
            (bucket_one, second),
            (first, bucket_two),
        )

        for next_state in possible_next_states:

            if next_state == forbidden or next_state in visited:
                continue
            visited.add(next_state)
            queue.append((next_state, actions + 1))

    raise ValueError("The goal cannot be reached under the given rules.")
