class School:
    def __init__(self):
        self._students = {}
        self._added = False

    def add_student(self, name, grade):
        if name in self._students:
            self._added = False
            return False

        self._students[name] = grade
        self._added = True
        return self._added

    def roster(self):
        return sorted(self._students, key=lambda name: (self._students[name], name))

    def grade(self, grade_number):
        return sorted(
            name
            for name, grade in self._students.items()
            if grade == grade_number
        )

    def added(self):
        return self._added
