// You should change this.
//
// Depending on your implementation, there are a variety of potential errors
// which might occur. They aren't checked by the test suite in order to
// allow the greatest freedom of implementation, but real libraries should
// provide useful, descriptive errors so that downstream code can react
// appropriately.
//
// One common idiom is to define an Error enum which wraps all potential
// errors. Another common idiom is to use a helper type such as failure::Error
// which does more or less the same thing but automatically.
#[derive(Debug)]
pub struct Error;

pub struct Scale {
    tonic: String,
    intervals: Vec<Interval>,
}

#[derive(Clone, Copy)]
enum Interval {
    Half,
    Whole,
    AugmentedSecond,
}

const SHARPS: [&str; 12] = [
    "A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#",
];
const FLATS: [&str; 12] = [
    "A", "Bb", "B", "C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab",
];

fn pitch_index(tonic: &str) -> Option<usize> {
    let letter = tonic.chars().next()?.to_ascii_uppercase() as u8;
    let letter_index = match letter {
        b'A' => 0,
        b'B' => 2,
        b'C' => 3,
        b'D' => 5,
        b'E' => 7,
        b'F' => 8,
        b'G' => 10,
        _ => return None,
    };

    match tonic.get(1..) {
        Some("#") => Some((letter_index + 1) % 12),
        Some("b") => Some((letter_index + 11) % 12),
        Some("") => Some(letter_index),
        _ => None,
    }
}

impl Scale {
    pub fn new(tonic: &str, intervals: &str) -> Result<Scale, Error> {
        let intervals = intervals
            .chars()
            .map(|interval| match interval {
                'm' => Ok(Interval::Half),
                'M' => Ok(Interval::Whole),
                'A' => Ok(Interval::AugmentedSecond),
                _ => Err(Error),
            })
            .collect::<Result<Vec<_>, Error>>()?;

        Ok(Scale {
            tonic: normalize_tonic(tonic)?,
            intervals,
        })
    }

    pub fn chromatic(tonic: &str) -> Result<Scale, Error> {
        Scale::new(tonic, "mmmmmmmmmmmm")
    }

    pub fn enumerate(&self) -> Vec<String> {
        let tonic_index = pitch_index(&self.tonic).unwrap_or_default();
        let use_flats = matches!(
            self.tonic.as_str(),
            "f" | "bb" | "eb" | "ab" | "db" | "gb" | "d" | "g" | "c" | "d#" | "g#" | "a#"
        );
        let pitch_names = if use_flats { FLATS } else { SHARPS };
        let tonic = &self.tonic;

        let mut notes = vec![tonic.to_string()];
        let mut pitch = tonic_index;

        for interval in &self.intervals {
            let step = match interval {
                Interval::Half => 1,
                Interval::Whole => 2,
                Interval::AugmentedSecond => 3,
            };
            pitch = (pitch + step) % 12;
            notes.push(pitch_names[pitch].to_string());
        }

        notes
    }
}

fn normalize_tonic(tonic: &str) -> Result<String, Error> {
    let mut chars = tonic.chars();
    let tonic = match chars.next() {
        Some(letter) => letter.to_string() + chars.as_str(),
        None => return Err(Error),
    };

    if pitch_index(&tonic).is_some() {
        Ok(tonic)
    } else {
        Err(Error)
    }
}
