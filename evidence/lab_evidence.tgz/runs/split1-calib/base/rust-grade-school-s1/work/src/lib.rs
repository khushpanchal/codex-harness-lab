use std::collections::{BTreeSet, HashMap};

#[derive(Debug)]
pub struct DuplicateStudent;

#[derive(Debug, Default, Eq, PartialEq)]
pub struct School {
    roster: HashMap<u32, BTreeSet<String>>,
}

impl School {
    pub fn new() -> School {
        School {
            roster: HashMap::new(),
        }
    }

    pub fn add(&mut self, grade: u32, student: &str) -> Result<(), DuplicateStudent> {
        self.roster
            .entry(grade)
            .or_default()
            .insert(student.to_owned())
            .then_some(())
            .ok_or(DuplicateStudent)
    }

    pub fn grades(&self) -> Vec<u32> {
        let mut grades: Vec<u32> = self.roster.keys().copied().collect();
        grades.sort_unstable();
        grades
    }

    // If `grade` returned a reference, `School` would be forced to keep a `Vec<String>`
    // internally to lend out. By returning an owned vector of owned `String`s instead,
    // the internal structure can be completely arbitrary. The tradeoff is that some data
    // must be copied each time `grade` is called.
    pub fn grade(&self, grade: u32) -> Vec<String> {
        self.roster
            .get(&grade)
            .map(|students| students.iter().cloned().collect())
            .unwrap_or_default()
    }
}
