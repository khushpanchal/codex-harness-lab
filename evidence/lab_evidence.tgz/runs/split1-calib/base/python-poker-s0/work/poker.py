def _parse(hand):
    values = {"T": 10, "J": 11, "Q": 12, "K": 13, "A": 14}
    cards = hand.split()
    if len(cards) != 5 or len(set(cards)) != 5:
        raise ValueError(f"invalid hand: {hand}")

    ranks = []
    suits = []
    for card in cards:
        face, suit = card[:-1], card[-1]
        if face not in {"2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K", "A"}:
            raise ValueError(f"invalid card: {card}")
        ranks.append(int(face) if face.isdigit() else values[face])
        suits.append(suit)
    return ranks, suits


def _rank_hand(hand):
    ranks, suits = _parse(hand)
    flush = len(set(suits)) == 1
    unique = sorted(set(ranks), reverse=True)
    straight = len(unique) == 5 and unique[0] - unique[-1] == 4
    straight_values = unique
    if unique == [14, 5, 4, 3, 2]:
        straight = True
        straight_values = [5, 4, 3, 2, 1]

    groups = sorted(((ranks.count(rank), rank) for rank in unique), reverse=True)
    shape = tuple(count for count, _ in groups)
    grouped = [rank for _, rank in groups]

    if flush and straight:
        category, ordered = 8, straight_values
    elif shape == (4, 1):
        category, ordered = 7, grouped
    elif shape == (3, 2):
        category, ordered = 6, grouped
    elif flush:
        category, ordered = 5, unique
    elif straight:
        category, ordered = 4, straight_values
    elif shape == (3, 1, 1):
        category, ordered = 3, grouped
    elif shape == (2, 2, 1):
        category, ordered = 2, grouped
    elif shape == (2, 1, 1, 1):
        category, ordered = 1, grouped
    else:
        category, ordered = 0, unique
    return (category, *ordered)


def best_hands(hands):
    if not hands:
        raise ValueError("no hands provided")
    rankings = {hand: _rank_hand(hand) for hand in hands}
    best = max(rankings.values())
    return [hand for hand in hands if rankings[hand] == best]
