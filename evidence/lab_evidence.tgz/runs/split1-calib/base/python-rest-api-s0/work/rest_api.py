import json
from decimal import Decimal


class RestAPI:
    def __init__(self, database=None):
        self.database = database if database is not None else {"users": []}
        self.users = {user["name"]: user for user in self.database["users"]}

    def get(self, url, payload=None):
        if url != "/users":
            raise ValueError(f"Unsupported GET URL: {url}")

        requested_names = payload["users"] if payload else None
        if requested_names is not None:
            missing = set(requested_names) - set(self.users)
            if missing:
                raise KeyError(f"Unknown users: {sorted(missing)}")
            names = sorted(requested_names)
        else:
            names = sorted(self.users)
        return json.dumps({"users": [self.users[name] for name in names]})

    def post(self, url, payload=None):
        if url == "/add":
            return self._add_user(payload)
        if url == "/iou":
            return self._add_iou(payload)
        raise ValueError(f"Unsupported POST URL: {url}")

    def _add_user(self, payload):
        name = payload["user"]
        if name in self.users:
            raise ValueError(f"User already exists: {name}")

        user = {"name": name, "owes": {}, "owed_by": {}, "balance": 0}
        self.database["users"].append(user)
        self.users[name] = user
        return json.dumps(user)

    def _add_iou(self, payload):
        lender_name = payload["lender"]
        borrower_name = payload["borrower"]
        amount = Decimal(str(payload["amount"]))
        lender = self.users.get(lender_name)
        borrower = self.users.get(borrower_name)
        if lender is None:
            raise KeyError(f"Unknown lender: {lender_name}")
        if borrower is None:
            raise KeyError(f"Unknown borrower: {borrower_name}")
        if amount < 0:
            raise ValueError("IOU amount must not be negative")

        self._apply_debt(borrower_name, lender_name, amount)
        return json.dumps({"users": sorted((lender, borrower), key=lambda u: u["name"])})

    def _apply_debt(self, borrower_name, lender_name, amount):
        lender = self.users[lender_name]
        borrower = self.users[borrower_name]

        # Net out any debt owed in the opposite direction first.
        reverse_amount = Decimal(str(borrower["owes"].get(lender_name, 0)))
        reverse_amount = min(reverse_amount, amount)
        if reverse_amount:
            self._decrease_debt(borrower_name, lender_name, reverse_amount)
            amount -= reverse_amount
        if amount:
            self._increase_debt(borrower_name, lender_name, amount)

    def _increase_debt(self, debtor_name, creditor_name, amount):
        debtor = self.users[debtor_name]
        creditor = self.users[creditor_name]
        debtor["owes"][creditor_name] = float(Decimal(str(debtor["owes"].get(creditor_name, 0))) + amount)
        creditor["owed_by"][debtor_name] = float(Decimal(str(creditor["owed_by"].get(debtor_name, 0))) + amount)
        self._update_balances(debtor_name, creditor_name)

    def _decrease_debt(self, debtor_name, creditor_name, amount):
        debtor = self.users[debtor_name]
        creditor = self.users[creditor_name]
        remaining = Decimal(str(debtor["owes"][creditor_name])) - amount
        if remaining:
            debtor["owes"][creditor_name] = float(remaining)
        else:
            del debtor["owes"][creditor_name]

        remaining = Decimal(str(creditor["owed_by"][debtor_name])) - amount
        if remaining:
            creditor["owed_by"][debtor_name] = float(remaining)
        else:
            del creditor["owed_by"][debtor_name]

        self._update_balances(debtor_name, creditor_name)

    def _update_balances(self, debtor_name, creditor_name):
        for name in (debtor_name, creditor_name):
            user = self.users[name]
            owed_by_total = sum((Decimal(str(value)) for value in user["owed_by"].values()), Decimal(0))
            owes_total = sum((Decimal(str(value)) for value in user["owes"].values()), Decimal(0))
            balance = owed_by_total - owes_total
            user["balance"] = float(balance) if balance else 0
