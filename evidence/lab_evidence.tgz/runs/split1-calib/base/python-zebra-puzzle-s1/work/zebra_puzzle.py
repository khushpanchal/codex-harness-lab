import itertools


def _solution():
    for colors in itertools.permutations(
        ("red", "green", "ivory", "yellow", "blue")
    ):
        green_index = colors.index("green")
        if green_index == 0 or colors[green_index - 1] != "ivory":
            continue
        if colors.index("blue") != 1:
            continue

        for drinks in itertools.permutations(
            ("coffee", "tea", "milk", "orange juice", "water")
        ):
            if drinks[2] != "milk" or drinks[colors.index("green")] != "coffee":
                continue

            for hobbies in itertools.permutations(
                ("dancing", "painting", "reading", "football", "chess")
            ):
                if drinks[hobbies.index("football")] != "orange juice":
                    continue
                if colors[hobbies.index("painting")] != "yellow":
                    continue

                for nations in itertools.permutations(
                    ("Englishman", "Spaniard", "Ukrainian", "Norwegian", "Japanese")
                ):
                    if nations[0] != "Norwegian":
                        continue
                    if colors[nations.index("Englishman")] != "red":
                        continue
                    if drinks[nations.index("Ukrainian")] != "tea":
                        continue
                    if hobbies[nations.index("Japanese")] != "chess":
                        continue

                    for pets in itertools.permutations(
                        ("dog", "snails", "fox", "horse", "zebra")
                    ):
                        if pets[nations.index("Spaniard")] != "dog":
                            continue
                        if hobbies[pets.index("snails")] != "dancing":
                            continue
                        if abs(hobbies.index("painting") - pets.index("horse")) != 1:
                            continue
                        reading_index = hobbies.index("reading")
                        fox_index = pets.index("fox")
                        if abs(reading_index - fox_index) != 1:
                            continue
                        return {
                            "water": nations[drinks.index("water")],
                            "zebra": nations[pets.index("zebra")],
                        }


def drinks_water():
    return _solution()["water"]


def owns_zebra():
    return _solution()["zebra"]


def owns_zebra():
    pass
