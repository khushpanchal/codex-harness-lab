import unittest

from simple_linked_list import LinkedList, EmptyListException, Node


class SimpleLinkedListTest(unittest.TestCase):
    def test_empty_list_has_len_zero(self):
        sut = LinkedList()
        self.assertEqual(len(sut), 0)

    # len / construction
    def test_empty_list_constructed_from_no_values(self):
        sut = LinkedList([])
        self.assertEqual(len(sut), 0)

    def test_len_of_single_element_list(self):
        sut = LinkedList([1])
        self.assertEqual(len(sut), 1)

    def test_len_of_multi_element_list(self):
        sut = LinkedList([1, 2, 3, 4, 5])
        self.assertEqual(len(sut), 5)

    def test_empty_list_has_no_head(self):
        sut = LinkedList()
        with self.assertRaises(EmptyListException):
            sut.head()

    # pop on empty
    def test_pop_on_empty_list_raises(self):
        sut = LinkedList()
        with self.assertRaises(EmptyListException):
            sut.pop()

    def test_pop_on_empty_list_error_message(self):
        sut = LinkedList()
        with self.assertRaises(EmptyListException) as ctx:
            sut.pop()
        self.assertTrue(bool(str(ctx.exception)))

    def test_iterating_empty_list_yields_nothing(self):
        sut = LinkedList()
        self.assertEqual(list(sut), [])

    # push / pop basic
    def test_push_increases_len(self):
        sut = LinkedList()
        sut.push(1)
        self.assertEqual(len(sut), 1)
        sut.push(2)
        self.assertEqual(len(sut), 2)

    def test_head_after_single_push(self):
        sut = LinkedList()
        sut.push(7)
        self.assertEqual(sut.head().value(), 7)

    def test_head_is_last_pushed_value(self):
        sut = LinkedList([1, 2, 3])
        self.assertEqual(sut.head().value(), 3)

    def test_push_then_pop_returns_last_pushed(self):
        sut = LinkedList()
        sut.push(10)
        sut.push(20)
        self.assertEqual(sut.pop(), 20)
        self.assertEqual(sut.pop(), 10)

    def test_pop_decreases_len(self):
        sut = LinkedList([1, 2, 3])
        sut.pop()
        self.assertEqual(len(sut), 2)

    def test_pop_until_empty_then_raises(self):
        sut = LinkedList([1])
        sut.pop()
        self.assertEqual(len(sut), 0)
        with self.assertRaises(EmptyListException):
            sut.pop()

    def test_can_push_after_emptying(self):
        sut = LinkedList()
        sut.push(1)
        sut.pop()
        sut.push(2)
        self.assertEqual(len(sut), 1)
        self.assertEqual(sut.head().value(), 2)

    # iteration / initialization order
    def test_constructed_list_iterates_lifo(self):
        sut = LinkedList([1, 2, 3])
        self.assertEqual(list(sut), [3, 2, 1])

    def test_constructed_from_iterable(self):
        sut = LinkedList(range(1, 4))
        self.assertEqual(list(sut), [3, 2, 1])

    def test_iterate_after_pushes(self):
        sut = LinkedList()
        for v in [1, 2, 3]:
            sut.push(v)
        self.assertEqual(list(sut), [3, 2, 1])

    def test_repeated_iteration(self):
        sut = LinkedList([1, 2, 3])
        self.assertEqual(list(sut), [3, 2, 1])
        self.assertEqual(list(sut), [3, 2, 1])

    # node linkage
    def test_node_next_returns_next_node(self):
        sut = LinkedList([1, 2, 3])
        head = sut.head()
        self.assertEqual(head.value(), 3)
        self.assertEqual(head.next().value(), 2)
        self.assertEqual(head.next().next().value(), 1)
        self.assertIsNone(head.next().next().next())

    def test_node_next_of_single_element_is_none(self):
        sut = LinkedList([42])
        self.assertIsNone(sut.head().next())

    # reversed
    def test_reversed_empty_list(self):
        sut = LinkedList()
        rev = sut.reversed()
        self.assertEqual(len(rev), 0)
        self.assertEqual(list(rev), [])

    def test_reversed_single_element(self):
        sut = LinkedList([5])
        rev = sut.reversed()
        self.assertEqual(len(rev), 1)
        self.assertEqual(list(rev), [5])

    def test_reversed_multi_element(self):
        sut = LinkedList([1, 2, 3, 4])
        self.assertEqual(list(sut.reversed()), [1, 2, 3, 4])

    def test_reversed_returns_new_list(self):
        sut = LinkedList([1, 2, 3])
        rev = sut.reversed()
        self.assertIsNot(rev, sut)
        # original unchanged
        self.assertEqual(list(sut), [3, 2, 1])
        self.assertEqual(len(sut), 3)

    def test_reversed_of_reversed_is_original_order(self):
        sut = LinkedList([1, 2, 3])
        self.assertEqual(list(sut.reversed().reversed()), [3, 2, 1])

    def test_reversed_list_is_independent(self):
        sut = LinkedList([1, 2])
        rev = sut.reversed()
        rev.pop()
        self.assertEqual(len(sut), 2)

    # mixed / duplicates
    def test_duplicate_values(self):
        sut = LinkedList([7, 7, 7])
        self.assertEqual(len(sut), 3)
        self.assertEqual(list(sut), [7, 7, 7])
        self.assertEqual(sut.pop(), 7)

    def test_various_types(self):
        sut = LinkedList(["a", 2, (3, 4)])
        self.assertEqual(list(sut), [(3, 4), 2, "a"])

    def test_push_none_value(self):
        sut = LinkedList()
        sut.push(None)
        self.assertEqual(len(sut), 1)
        self.assertIsNone(sut.pop())

    def test_long_list_roundtrip(self):
        values = list(range(1000))
        sut = LinkedList(values)
        self.assertEqual(len(sut), 1000)
        out = [sut.pop() for _ in range(1000)]
        self.assertEqual(out, list(reversed(values)))


if __name__ == "__main__":
    unittest.main()
