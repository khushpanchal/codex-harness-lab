use grade_school::*;

#[test]
fn grade_is_empty_if_no_students_in_the_roster() {
    let s = School::new();
    assert_eq!(s.grade(1), Vec::<String>::new());
}

#[test]
fn add_a_student() {
    let mut s = School::new();
    s.add(2, "Jim");
    assert_eq!(s.grade(2), vec!["Jim".to_string()]);
}

#[test]
fn add_students_to_different_grades() {
    let mut s = School::new();
    s.add(3, "Chelsea");
    s.add(7, "Logan");
    assert_eq!(s.grade(3), vec!["Chelsea".to_string()]);
    assert_eq!(s.grade(7), vec!["Logan".to_string()]);
    assert_eq!(s.grades(), vec![3, 7]);
}

#[test]
fn add_students_in_same_grade_sorted() {
    let mut s = School::new();
    s.add(2, "Zoe");
    s.add(2, "Alex");
    s.add(2, "Peter");
    assert_eq!(s.grade(2), vec!["Alex".to_string(), "Peter".to_string(), "Zoe".to_string()]);
}

#[test]
fn grades_are_sorted_in_roster() {
    let mut s = School::new();
    s.add(5, "Jim");
    s.add(1, "Anna");
    s.add(2, "Alex");
    assert_eq!(s.grades(), vec![1, 2, 5]);
}

#[test]
fn grades_have_no_duplicates() {
    let mut s = School::new();
    s.add(2, "Jim");
    s.add(2, "Anna");
    assert_eq!(s.grades(), vec![2]);
}

#[test]
fn roster_all_grades_students_sorted_by_grade_then_name() {
    let mut s = School::new();
    s.add(5, "Jim");
    s.add(1, "Charlie");
    s.add(1, "Anna");
    s.add(1, "Barb");
    s.add(2, "Zoe");
    s.add(2, "Alex");
    s.add(2, "Peter");

    let mut expected = Vec::new();
    for name in ["Anna", "Barb", "Charlie", "Alex", "Peter", "Zoe", "Jim"] {
        expected.push(name.to_string());
    }
    assert_eq!(s.grades(), vec![1, 2, 5]);
    assert_eq!(s.grade(1), vec!["Anna".to_string(), "Barb".to_string(), "Charlie".to_string()]);
    assert_eq!(s.grade(2), vec!["Alex".to_string(), "Peter".to_string(), "Zoe".to_string()]);
    assert_eq!(s.grade(5), vec!["Jim".to_string()]);
    // full roster ordering check via grades and grade lists
    let all: Vec<String> = s
        .grades()
        .iter()
        .flat_map(|g| s.grade(*g))
        .collect();
    assert_eq!(all, expected);
}

#[test]
fn grade_of_unknown_grade_is_empty() {
    let mut s = School::new();
    s.add(2, "Jim");
    assert_eq!(s.grade(1), Vec::<String>::new());
    assert_eq!(s.grade(100), Vec::<String>::new());
}

#[test]
fn adding_same_student_twice_to_same_grade_keeps_one_entry() {
    let mut s = School::new();
    s.add(2, "Jim");
    s.add(2, "Jim");
    assert_eq!(s.grade(2), vec!["Jim".to_string()]);
}

#[test]
fn adding_same_student_to_different_grades_not_allowed() {
    let mut s = School::new();
    s.add(2, "Jim");
    s.add(3, "Jim");
    // A student can appear on the roster at most once
    let total: usize = s.grades().iter().map(|g| s.grade(*g).len()).sum();
    assert_eq!(total, 1);
}

#[test]
fn adding_duplicate_does_not_corrupt_roster() {
    let mut s = School::new();
    s.add(1, "Anna");
    s.add(1, "Anna");
    s.add(1, "Barb");
    assert_eq!(s.grade(1), vec!["Anna".to_string(), "Barb".to_string()]);
    assert_eq!(s.grades(), vec![1]);
}

#[test]
fn many_grades_sorted_numerically_not_lexicographically() {
    let mut s = School::new();
    s.add(10, "Tenth");
    s.add(2, "Second");
    s.add(1, "First");
    assert_eq!(s.grades(), vec![1, 2, 10]);
}

#[test]
fn grade_queries_do_not_mutate() {
    let mut s = School::new();
    s.add(2, "Jim");
    let g1 = s.grade(2);
    let g2 = s.grade(2);
    assert_eq!(g1, g2);
    assert_eq!(s.grades(), vec![2]);
}

#[test]
fn empty_school_grades_list_is_empty() {
    let s = School::new();
    assert_eq!(s.grades(), Vec::<u32>::new());
}
