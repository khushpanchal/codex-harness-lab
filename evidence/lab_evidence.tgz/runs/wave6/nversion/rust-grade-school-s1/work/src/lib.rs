use std::collections::{BTreeMap, BTreeSet};

pub struct School {
    students: BTreeMap<u32, BTreeSet<String>>,
}

impl School {
    pub fn new() -> School {
        School {
            students: BTreeMap::new(),
        }
    }

    pub fn add(&mut self, grade: u32, student: &str) -> Result<(), String> {
        let grade_students = self.students.entry(grade).or_default();
        if !grade_students.insert(student.to_owned()) {
            return Err(format!("{student} is already enrolled in grade {grade}"));
        }
        Ok(())
    }

    pub fn grades(&self) -> Vec<u32> {
        self.students.keys().copied().collect()
    }

    // If `grade` returned a reference, `School` would be forced to keep a `Vec<String>`
    // internally to lend out. By returning an owned vector of owned `String`s instead,
    // the internal structure can be completely arbitrary. The tradeoff is that some data
    // must be copied each time `grade` is called.
    pub fn grade(&self, grade: u32) -> Vec<String> {
        self.students
            .get(&grade)
            .map(|students| students.iter().cloned().collect())
            .unwrap_or_default()
    }

    pub fn roster(&self) -> Vec<(u32, String)> {
        self.students
            .iter()
            .flat_map(|(grade, students)| {
                students
                    .iter()
                    .map(move |student| (*grade, student.clone()))
            })
            .collect()
    }
}
