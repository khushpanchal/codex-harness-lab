# test_blind_spec.py

import unittest

from list_ops import (
    append,
    concat,
    foldl,
    foldr,
    length,
    reverse,
    filter as list_ops_filter,
    map as list_ops_map,
)


class AppendTests(unittest.TestCase):
    def test_append_empty_lists(self):
        self.assertEqual(append([], []), [])

    def test_append_list_to_empty_list(self):
        self.assertEqual(append([], [1, 2, 3, 4]), [1, 2, 3, 4])

    def test_append_empty_list_to_list(self):
        self.assertEqual(append([1, 2, 3, 4], []), [1, 2, 3, 4])

    def test_append_non_empty_lists(self):
        self.assertEqual(
            append([1, 2], [2, 3, 4, 5]),
            [1, 2, 2, 3, 4, 5],
        )

    def test_append_does_not_modify_inputs(self):
        a = [1, 2]
        b = [3]
        append(a, b)
        self.assertEqual(a, [1, 2])
        self.assertEqual(b, [3])


class ConcatTests(unittest.TestCase):
    def test_concat_empty_list(self):
        self.assertEqual(concat([]), [])

    def test_concat_list_of_lists(self):
        self.assertEqual(concat([[1, 2], [3], [], [4, 5, 6]]), [1, 2, 3, 4, 5, 6])

    def test_concat_list_of_empty_lists(self):
        self.assertEqual(concat([[], [], []]), [])

    def test_concat_single_list(self):
        self.assertEqual(concat([[1, 2, 3]]), [1, 2, 3])


class FilterTests(unittest.TestCase):
    def test_filter_empty_list(self):
        self.assertEqual(list_ops_filter(lambda x: x % 2 == 1, []), [])

    def test_filter_keeps_matching(self):
        self.assertEqual(
            list_ops_filter(lambda x: x % 2 == 1, [1, 2, 3, 4, 5]),
            [1, 3, 5],
        )

    def test_filter_none_match(self):
        self.assertEqual(
            list_ops_filter(lambda x: x > 10, [1, 2, 3]),
            [],
        )

    def test_filter_all_match(self):
        self.assertEqual(
            list_ops_filter(lambda x: x > 0, [1, 2, 3]),
            [1, 2, 3],
        )

    def test_filter_preserves_order(self):
        self.assertEqual(
            list_ops_filter(lambda x: x < 5, [9, 1, 8, 2, 7, 3]),
            [1, 2, 3],
        )


class LengthTests(unittest.TestCase):
    def test_length_empty_list(self):
        self.assertEqual(length([]), 0)

    def test_length_non_empty_list(self):
        self.assertEqual(length([1, 2, 3, 4]), 4)

    def test_length_nested_counts_top_level(self):
        self.assertEqual(length([[1, 2], [3], []]), 3)


class MapTests(unittest.TestCase):
    def test_map_empty_list(self):
        self.assertEqual(list_ops_map(lambda x: x + 1, []), [])

    def test_map_non_empty_list(self):
        self.assertEqual(
            list_ops_map(lambda x: x + 1, [1, 3, 5, 7]),
            [2, 4, 6, 8],
        )

    def test_map_preserves_order(self):
        self.assertEqual(
            list_ops_map(str, [3, 1, 2]),
            ["3", "1", "2"],
        )

    def test_map_does_not_modify_input(self):
        xs = [1, 2, 3]
        list_ops_map(lambda x: x * 2, xs)
        self.assertEqual(xs, [1, 2, 3])


class FoldlTests(unittest.TestCase):
    def test_foldl_empty_list(self):
        self.assertEqual(foldl(lambda acc, el: acc + el, [], 0), 0)

    def test_foldl_direction_and_argument_order(self):
        # acc goes first, element second; left to right
        self.assertEqual(
            foldl(lambda acc, el: acc - el, [1, 2, 3, 4], 0),
            ((((0 - 1) - 2) - 3) - 4),
        )

    def test_foldl_addition(self):
        self.assertEqual(foldl(lambda acc, el: acc + el, [1, 2, 3, 4], 5), 15)

    def test_foldl_division(self):
        self.assertEqual(
            foldl(lambda acc, el: acc // el, [2, 5], 100),
            100 // 2 // 5,
        )

    def test_foldl_accumulator_type_respected(self):
        self.assertEqual(
            foldl(lambda acc, el: acc + [el], [1, 2, 3], []),
            [1, 2, 3],
        )


class FoldrTests(unittest.TestCase):
    def test_foldr_empty_list(self):
        self.assertEqual(foldr(lambda acc, el: acc + el, [], 0), 0)

    def test_foldr_direction(self):
        # folds from the right
        self.assertEqual(
            foldr(lambda acc, el: el - acc, [1, 2, 3, 4], 0),
            (1 - (2 - (3 - (4 - 0)))),
        )

    def test_foldr_addition(self):
        self.assertEqual(foldr(lambda acc, el: acc + el, [1, 2, 3, 4], 5), 15)

    def test_foldr_division(self):
        self.assertEqual(
            foldr(lambda acc, el: acc // el, [2, 5], 100),
            2 // (5 // 100) if 100 == 0 else 100 // (5 // 1),
        )

    def test_foldr_accumulator_type_respected(self):
        self.assertEqual(
            foldr(lambda acc, el: [el] + acc, [1, 2, 3], []),
            [1, 2, 3],
        )


class ReverseTests(unittest.TestCase):
    def test_reverse_empty_list(self):
        self.assertEqual(reverse([]), [])

    def test_reverse_non_empty_list(self):
        self.assertEqual(reverse([1, 3, 5, 6, 7, 8]), [8, 7, 6, 5, 3, 1])

    def test_reverse_single_element(self):
        self.assertEqual(reverse([42]), [42])

    def test_reverse_does_not_modify_input(self):
        xs = [1, 2, 3]
        reverse(xs)
        self.assertEqual(xs, [1, 2, 3])

    def test_reverse_two_elements_swaps(self):
        self.assertEqual(reverse([1, 2]), [2, 1])


if __name__ == "__main__":
    unittest.main()
