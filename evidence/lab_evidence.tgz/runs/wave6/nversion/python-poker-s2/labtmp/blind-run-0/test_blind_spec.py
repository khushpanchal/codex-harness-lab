import unittest

from poker import best_hands


class PokerTest(unittest.TestCase):
    # --- basics ---
    def test_single_hand_always_wins(self):
        self.assertEqual(best_hands(["4S 5S 7H 8D JC"]), ["4S 5S 7H 8D JC"])

    def test_highest_card_wins(self):
        self.assertEqual(best_hands(["4D 5S 6S 8D 3C", "2S 4C 7S 9H 10H", "3S 4S 5D 6H JH"]), ["3S 4S 5D 6H JH"])

    # --- tie / multiple winners ---
    def test_tie_hands_are_split(self):
        self.assertEqual(best_hands(["4D 5S 6S 8D 3C", "2S 4C 7S 9H 10H", "3S 4S 5D 6H JH", "3H 4H 5C 6C JD"]), ["3S 4S 5D 6H JH", "3H 4H 5C 6C JD"])

    def test_aces_can_be_low_in_a_straight(self):
        self.assertEqual(best_hands(["4S 5H 6C 7D AD", "2S 3H 6C 7D 9H"]), ["4S 5H 6C 7D AD"])

    def test_aces_cannot_be_more_than_low_in_a_straight(self):
        self.assertEqual(best_hands(["2S 3H 4C 5D AH", "4S 5H 6C 7D 8D"]), ["4S 5H 6C 7D 8D"])

    def test_aces_can_be_low_or_high_in_a_straight_wrap_around(self):
        self.assertEqual(best_hands(["4D 5S 6S 8D 3C", "2S 4C 7S 9H 10H", "3S 4S 5D 6H JH", "3H 4H 5C 6C JD", "AD QH TH KD JS"]), ["AD QH TH KD JS"])

    def test_ties_go_to_first_winner(self):
        self.assertEqual(best_hands(["5H 5C 6S 7S KD", "2C 3S 8S 8D TD", "5C 5D 7H 8S KC"]), ["5C 5D 7H 8S KC"])

    def test_two_pairs_beats_one_pair(self):
        self.assertEqual(best_hands(["4S 2H 6D 8D 2C", "2S 4H 6C 8D AH"]), ["2S 4H 6C 8D AH"])

    def test_one_pair_beats_high_card(self):
        self.assertEqual(best_hands(["4S 5H 6C 8D KH", "2S 4D 6D 9C 3S"]), ["4S 5H 6C 8D KH"])

    # --- high card tiebreakers ---
    def test_highest_card_down_to_4th_card_for_a_tie(self):
        self.assertEqual(best_hands(["4S 5H 6D 8D 3C", "2S 5D 9D 8C 5S"]), ["2S 5D 9D 8C 5S"])

    def test_equal_ranked_hands_split(self):
        self.assertEqual(best_hands(["4S 5H 6D 8D 3C", "2S 5D 9D 8C 5S"]), ["2S 5D 9D 8C 5S"])

    # --- pairs ---
    def test_two_pairs_first_pair_wins(self):
        self.assertEqual(best_hands(["2S 8H 6D 8D 3C", "4S 5H 4D 8D 5C"]), ["4S 5H 4D 8D 5C"])

    def test_two_pairs_second_pair_wins(self):
        self.assertEqual(best_hands(["2S QS 6D QD 3C", "4S 5H 4D 8D 5C"]), ["2S QS 6D QD 3C"])

    def test_two_pairs_both_pairs_wins(self):
        self.assertEqual(best_hands(["2S QS 6D QD 3C", "4S 5H 4D 8D 5C"]), ["2S QS 6D QD 3C"])

    def test_two_pairs_equal_rank_split(self):
        self.assertEqual(best_hands(["2S QS 6D QD 3C", "2C QD 6H QC 3D"]), ["2S QS 6D QD 3C", "2C QD 6H QC 3D"])

    def test_pair_of_jacks_beats_pair_of_tens(self):
        self.assertEqual(best_hands(["J5 JS", "T5 TS"]), ["J5 JS"])

    # --- three/four of a kind ---
    def test_three_of_a_kind_beats_two_pair(self):
        self.assertEqual(best_hands(["2S 2H 6D 2D 3C", "4S AH 4D 8D 5C"]), ["2S 2H 6D 2D 3C"])

    def test_three_of_a_kind_beats_straight(self):
        self.assertEqual(best_hands(["4S 5H 4D 5D 4C", "3S 4D 5S 6D 7C"]), ["4S 5H 4D 5D 4C"])

    def test_two_triples_are_compared_by_rank(self):
        self.assertEqual(best_hands(["2S 2H 6D 2D 3C", "4S 4H 6D 4D 3C"]), ["4S 4H 6D 4D 3C"])

    def test_two_triples_split_when_equal(self):
        self.assertEqual(best_hands(["2S 2H 6D 2D 3C", "2C 2D 6H 2C 3D"]), ["2S 2H 6D 2D 3C", "2C 2D 6H 2C 3D"])

    # --- straights ---
    def test_straight_beats_three_of_a_kind(self):
        self.assertEqual(best_hands(["4S 5H 4D 5D 4C", "3S 4D 5S 6D 7C"]), ["3S 4D 5S 6D 7C"])

    def test_straight_ends_with_ace_beats_straight_ending_with_king(self):
        self.assertEqual(best_hands(["4S 5H 4D 5D 4C", "3D 4S 5S 6C KD", "2H JD TC KH AS"]), ["2H JD TC KH AS"])

    def test_ace_low_straight_beats_three_of_a_kind(self):
        self.assertEqual(best_hands(["2S AH 4D 5D 6C", "3D 3S 3C 6D 7C"]), ["2S AH 4D 5D 6C"])

    def test_ace_high_straight_beats_ace_low_straight(self):
        self.assertEqual(best_hands(["TH JC QD KD AS", "2H 3C 4D 5C AS"]), ["TH JC QD KD AS"])

    # --- flushes ---
    def test_flush_beats_straight(self):
        self.assertEqual(best_hands(["4C 6H 7D 8D 5H", "2S 4S 5S 6S 7S"]), ["2S 4S 5S 6S 7S"])

    def test_flush_tiebreaker_by_high_card(self):
        self.assertEqual(best_hands(["2H 4H 6H 8H JH", "2D 4D 6D 8D TD"]), ["2H 4H 6H 8H JH"])

    def test_equal_flushes_split(self):
        self.assertEqual(best_hands(["2H 4H 6H 8H JH", "2D 4D 6D 8D JD"]), ["2H 4H 6H 8H JH", "2D 4D 6D 8D JD"])

    # --- full houses ---
    def test_full_house_beats_flush(self):
        self.assertEqual(best_hands(["2H 4H 6H 8H JH", "4S 4H 4D 8D 8C"]), ["4S 4H 4D 8D 8C"])

    def test_two_full_houses_higher_triple_wins(self):
        self.assertEqual(best_hands(["4H 4S 4D 9S 9D", "5H 5S 5D 8S 8D"]), ["5H 5S 5D 8S 8D"])

    def test_two_full_houses_same_triple_higher_pair_wins(self):
        self.assertEqual(best_hands(["5H 5S 5D 9S 9D", "5H 5S 5D 8S 8D"]), ["5H 5S 5D 9S 9D"])

    def test_two_equal_full_houses_split(self):
        self.assertEqual(best_hands(["5H 5S 5D 9S 9D", "5C 5D 5H 9C 9C"]), ["5H 5S 5D 9S 9D", "5C 5D 5H 9C 9C"])

    # --- four of a kind ---
    def test_four_of_a_kind_beats_full_house(self):
        self.assertEqual(best_hands(["4S 5H 4D 5D 4H", "3S 3H 2S 2D 3D"]), ["3S 3H 2S 2D 3D"])

    def test_four_of_a_kind_higher_rank_wins(self):
        self.assertEqual(best_hands(["2S 2H 2C 2D 5D", "3S 3H 3C 3D 5D"]), ["3S 3H 3C 3D 5D"])

    def test_equal_four_of_a_kind_split(self):
        self.assertEqual(best_hands(["2S 2H 2C 2D 5D", "2C 2D 2H 2S 5C"]), ["2S 2H 2C 2D 5D", "2C 2D 2H 2S 5C"])

    # --- straight flushes ---
    def test_straight_flush_beats_four_of_a_kind(self):
        self.assertEqual(best_hands(["4S 5H 5D 5D 4H", "3S 4S 5S 6S 7S"]), ["3S 4S 5S 6S 7S"])

    def test_straight_flush_high_card_wins(self):
        self.assertEqual(best_hands(["4H 6H 7H 8H 5H", "5S 7S 8S 9S 6S"]), ["5S 7S 8S 9S 6S"])

    def test_royal_flush_beats_straight_flush(self):
        self.assertEqual(best_hands(["4H 6H 7H 8H 5H", "TS JS QS KS AS"]), ["TS JS QS KS AS"])

    def test_equal_straight_flushes_split(self):
        self.assertEqual(best_hands(["4H 6H 7H 8H 5H", "4D 6D 7D 8D 5D"]), ["4H 6H 7H 8H 5H", "4D 6D 7D 8D 5D"])

    # --- more tie splitting ---
    def test_both_hands_have_a_flush_tie_goes_to_high_card_down_to_4th(self):
        self.assertEqual(best_hands(["2H 7H 8H 9H 6H", "3S 5S 6S 7S 8S"]), ["3S 5S 6S 7S 8S"])

    def test_both_hands_have_a_straight_ace_high_wins(self):
        self.assertEqual(best_hands(["4S 6C 7S 8D 5D", "5S 7D 8D 9S 6S"]), ["5S 7D 8D 9S 6S"])

    def test_both_hands_have_a_straight_ace_low_wins(self):
        self.assertEqual(best_hands(["4S 6C 7S 8D 5D", "2S 4D 5D 6S 3S"]), ["4S 6C 7S 8D 5D"])

    def test_both_hands_have_a_straight_tie_split(self):
        self.assertEqual(best_hands(["4S 6C 7S 8D 5D", "3D 5C 6D 7C 4C"]), ["4S 6C 7S 8D 5D", "3D 5C 6D 7C 4C"])


if __name__ == "__main__":
    unittest.main()
