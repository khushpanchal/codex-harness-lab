from collections import Counter


def parse_hand(hand):
    cards = hand.split()
    if len(cards) != 5 or len(set(cards)) != 5:
        raise ValueError(f"invalid poker hand: {hand!r}")

    values = {
        "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8,
        "9": 9, "T": 10, "J": 11, "Q": 12, "K": 13, "A": 14,
    }
    result = []
    for card in cards:
        if len(card) != 2 or card[0] not in values or card[1] not in "SHDC":
            raise ValueError(f"invalid poker hand: {hand!r}")
        result.append((values[card[0]], card[1]))
    return result


def rank_hand(hand):
    """Return a tuple which orders poker hands correctly."""
    cards = parse_hand(hand)
    values = sorted((rank for rank, _ in cards), reverse=True)
    suits = {suit for _, suit in cards}
    counts = Counter(values)
    groups = sorted(
        counts.items(), key=lambda item: (item[1], item[0]), reverse=True
    )
    grouped_values = [rank for rank, _ in groups]

    is_flush = len(suits) == 1
    is_straight = len(counts) == 5 and values[0] - values[-1] == 4
    # An ace is also valid below a five in A-2-3-4-5.
    if values == [14, 5, 4, 3, 2]:
        is_straight = True
        values = [5, 4, 3, 2, 1]

    if is_straight and is_flush:
        category = 8
    elif groups[0][1] == 4:
        category = 7
    elif groups[0][1] == 3 and groups[1][1] == 2:
        category = 6
    elif is_flush:
        category = 5
    elif is_straight:
        category = 4
    elif groups[0][1] == 3:
        category = 3
    elif groups[0][1] == 2 and groups[1][1] == 2:
        category = 2
    elif groups[0][1] == 2:
        category = 1
    else:
        category = 0

    if category in {1, 2, 3, 6, 7}:
        values = grouped_values

    return category, tuple(values)


def best_hands(hands):
    if not hands:
        raise ValueError("no hands were supplied")

    ranked = [(rank_hand(hand), hand) for hand in hands]
    best_rank = max(rank for rank, _ in ranked)
    return [hand for rank, hand in ranked if rank == best_rank]
