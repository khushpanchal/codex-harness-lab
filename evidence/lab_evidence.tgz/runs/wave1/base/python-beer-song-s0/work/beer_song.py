def recite(start, take=1):
    if take < 1:
        return []

    lines = []
    for number in range(start, start - take, -1):
        if lines:
            lines.append("")

        bottles = _bottles(number)
        next_number = 99 if number == 0 else number - 1
        next_bottles = _bottles(next_number)
        if number == 0:
            first_line = f"{bottles.capitalize()} of beer on the wall, {bottles} of beer."
            lines.append(first_line)
            lines.append(
                f"Go to the store and buy some more, {next_bottles} of beer on the wall."
            )
            continue

        action = "Take one down" if number > 1 else "Take it down"

        lines.append(f"{bottles} of beer on the wall, {bottles} of beer.")
        lines.append(
            f"{action} and pass it around, {next_bottles} of beer on the wall."
        )

    return lines


def _bottles(number):
    return "no more bottles" if number == 0 else f"{number} bottle{'s' if number != 1 else ''}"
