
class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        if not isinstance(board, list) or not board:
            raise ValueError("Invalid board")
        if not all(isinstance(row, str) for row in board):
            raise ValueError("Invalid board")

        self.board = board
        self.width = len(board[0])
        self.height = len(board)

        if self.width == 0 or any(len(row) != self.width for row in board):
            raise ValueError("Invalid board")

        if any(cell not in ("B", "W", " ") for row in board for cell in row):
            raise ValueError("Invalid board")

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not self._is_valid_coordinate(x, y):
            raise ValueError("Invalid coordinate")

        owner, region = self._empty_region(x, y)
        return owner, region

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        result = {"B": set(), "W": set(), "": set()}

        for y, row in enumerate(self.board):
            for x, cell in enumerate(row):
                if cell == " ":
                    owner, region = self._empty_region(x, y)
                    result[owner].update(region)

        return result

    def _is_valid_coordinate(self, x, y):
        return (
            isinstance(x, int)
            and isinstance(y, int)
            and 0 <= x < self.width
            and 0 <= y < self.height
        )

    def _empty_region(self, x, y):
        cell = self.board[y][x]
        if cell in ("B", "W"):
            return cell, {(x, y)}

        region = {(x, y)}
        pending = [(x, y)]
        owners = set()

        while pending:
            current_x, current_y = pending.pop()

            for neighbor_x, neighbor_y in self._neighbors(current_x, current_y):
                neighbor = self.board[neighbor_y][neighbor_x]
                if neighbor == " ":
                    point = (neighbor_x, neighbor_y)
                    if point not in region:
                        region.add(point)
                        pending.append(point)
                else:
                    owners.add(neighbor)

        if len(owners) == 1:
            owner = owners.pop()
        else:
            owner = ""

        return owner, region

    def _neighbors(self, x, y):
        for delta_x, delta_y in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            neighbor_x = x + delta_x
            neighbor_y = y + delta_y
            if 0 <= neighbor_x < self.width and 0 <= neighbor_y < self.height:
                yield neighbor_x, neighbor_y
