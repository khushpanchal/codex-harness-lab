M = 26
ALPHABET = "abcdefghijklmnopqrstuvwxyz"


def modular_inverse(a):
    for inverse in range(1, M):
        if (a * inverse) % M == 1:
            return inverse
    raise ValueError("a and m must be coprime.")


def encode(plain_text, a, b):
    modular_inverse(a)
    normalized = "".join(
        char.lower() for char in plain_text if char.isalnum()
    )
    encoded = []
    for char in normalized:
        if char.isdigit():
            encoded.append(char)
        else:
            encoded.append(ALPHABET[(a * ALPHABET.index(char) + b) % M])
    return " ".join(
        "".join(encoded[index:index + 5])
        for index in range(0, len(encoded), 5)
    )


def decode(ciphered_text, a, b):
    inverse = modular_inverse(a)
    normalized = "".join(char for char in ciphered_text if char.isalnum())
    decoded = []
    for char in normalized:
        if char.isdigit():
            decoded.append(char)
        else:
            decoded.append(ALPHABET[(inverse * (ALPHABET.index(char) - b)) % M])
    return "".join(decoded)
