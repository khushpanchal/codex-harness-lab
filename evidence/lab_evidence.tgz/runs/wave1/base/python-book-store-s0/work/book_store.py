from functools import cache


BASE_PRICE = 800  # cents
DISCOUNTS = (0, 5, 10, 20, 25)  # indexed by group size minus one


@cache
def _minimum_cost(state):
    state = tuple(sorted(count for count in state if count))
    if not state:
        return 0

    # `state[i]` is the number of titles with i + 1 remaining copies.
    if len(state) < 5:
        state = state + (0,) * (5 - len(state))

    best = None

    def consider(index, selected):
        nonlocal best
        if selected > 5:
            return
        if index == len(state):
            if selected == 0:
                return
            padded = state + (0,) * (len(chosen) - len(state))
            remaining = []
            for copies, titles_with_copies in enumerate(padded):
                titles_selected = chosen[copies]
                titles_added = chosen[copies + 1] if copies + 1 < len(chosen) else 0
                remaining.append(titles_with_copies - titles_selected + titles_added)
            remaining = tuple(sorted(count for count in remaining if count))
            remaining = tuple(sorted(count for count in remaining if count))
            price = selected * BASE_PRICE * (100 - DISCOUNTS[selected - 1]) // 100
            candidate = price + _minimum_cost(remaining)
            best = candidate if best is None else min(best, candidate)
            return

        for titles_selected in range(state[index] + 1):
            chosen[index] = titles_selected
            consider(index + 1, selected + titles_selected)

    chosen = [0] * len(state)
    consider(0, 0)
    return best


def total(basket):
    counts = {}
    for title in basket:
        counts[title] = counts.get(title, 0) + 1
    aggregate = [0] * max(counts.values(), default=0)
    for count in counts.values():
        aggregate[count - 1] += 1
    return _minimum_cost(tuple(aggregate))
