ANIMALS = (
    ("fly", None),
    ("spider", "It wriggled and jiggled and tickled inside her."),
    ("bird", "How absurd to swallow a bird!"),
    ("cat", "Imagine that, to swallow a cat!"),
    ("dog", "What a hog, to swallow a dog!"),
    ("goat", "Just opened her throat and swallowed a goat!"),
    ("cow", "I don't know how she swallowed a cow!"),
    ("horse", "She's dead, of course!"),
)


def _verse(index):
    animal, comment = ANIMALS[index]
    lines = [f"I know an old lady who swallowed a {animal}."]

    if animal == "horse":
        return [*lines, comment]

    lines.append(comment)

    for caught_index in range(index, 0, -1):
        caught, _ = ANIMALS[caught_index - 1]
        description = ""
        if caught == "spider":
            description = " that wriggled and jiggled and tickled inside her"
        lines.append(f"She swallowed the {animal} to catch the {caught}{description}.")
        animal = caught

    lines.append("I don't know why she swallowed the fly. Perhaps she'll die.")
    return lines


def recite(start_verse, end_verse):
    verses = [_verse(index - 1) for index in range(start_verse, end_verse + 1)]
    return [line for verse in verses for line in (*verse, "")]
