def grep(pattern, flags, files):
    number_lines = "-n" in flags
    list_files = "-l" in flags
    case_insensitive = "-i" in flags
    invert_match = "-v" in flags
    whole_line = "-x" in flags

    if case_insensitive:
        pattern = pattern.casefold()

    def matches(line):
        text = line.casefold() if case_insensitive else line
        if whole_line:
            return text == pattern
        return pattern in text

    results = []
    multiple_files = len(files) > 1
    for filename in files:
        with open(filename) as input_file:
            matching_lines = []
            for line_number, line in enumerate(input_file, start=1):
                line = line.rstrip("\n")
                if matches(line) != invert_match:
                    matching_lines.append((line_number, line))

        if matching_lines and list_files:
            results.append(filename)
        else:
            for line_number, line in matching_lines:
                prefix = ""
                if multiple_files:
                    prefix += f"{filename}:"
                if number_lines:
                    prefix += f"{line_number}:"
                results.append(prefix + line)

    return results
