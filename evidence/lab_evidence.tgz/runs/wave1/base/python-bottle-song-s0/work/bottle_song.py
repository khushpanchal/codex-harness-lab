def recite(start, take=1):
    numbers = {
        10: "Ten",
        9: "Nine",
        8: "Eight",
        7: "Seven",
        6: "Six",
        5: "Five",
        4: "Four",
        3: "Three",
        2: "Two",
        1: "One",
        0: "no",
    }
    if not 1 <= start <= 10:
        raise ValueError("start must be between 1 and 10")
    if not 1 <= take <= start:
        raise ValueError("take must end at or after zero bottles")
    lines = []
    current = start
    for _ in range(take):
        word = numbers[current]
        bottles = "bottles" if current != 1 else "bottle"
        next_word = numbers[current - 1]
        next_word = next_word.lower()
        next_bottles = "bottles" if current - 1 != 1 else "bottle"
        lines.extend(
            [
                f"{word} green {bottles} hanging on the wall,",
                f"{word} green {bottles} hanging on the wall,",
                "And if one green bottle should accidentally fall,",
                f"There'll be {next_word} green {next_bottles} hanging on the wall.",
            ]
        )
        current -= 1
    return lines
