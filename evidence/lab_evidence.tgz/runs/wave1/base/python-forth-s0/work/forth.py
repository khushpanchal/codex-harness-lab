class StackUnderflowError(Exception):
    """Raised when an operation needs more values than the stack contains."""

    def __init__(self, message):
        super().__init__(message)
        self.message = message


ARITHMETIC = {
    "+": lambda a, b: a + b,
    "-": lambda a, b: a - b,
    "*": lambda a, b: a * b,
    "/": lambda a, b: a // b,
}

STACK_WORDS = {
    "DUP": (1, 2),
    "DROP": (2, 1),
    "SWAP": (2, 2),
    "OVER": (2, 3),
}


def _is_number(token):
    return bool(token) and all(character in "0123456789" for character in token)


def _apply_stack_word(word, stack):
    minimum_size, resulting_size = STACK_WORDS[word]
    if len(stack) < minimum_size:
        raise StackUnderflowError("Insufficient number of items in stack")

    if word == "DUP":
        return stack + [stack[-1]]
    if word == "DROP":
        return stack[:-1]
    if word == "SWAP":
        return stack[:-2] + [stack[-1], stack[-2]]
    if word == "OVER":
        return stack + [stack[-2]]

    raise ValueError(f"undefined operation: {word}")


def _evaluate(tokens, definitions, stack):
    index = 0
    while index < len(tokens):
        word = tokens[index]
        index += 1
        upper_word = word.upper()

        if _is_number(word):
            stack.append(int(word))
        elif upper_word == ":":
            try:
                name = tokens[index]
                body_end = tokens.index(";", index + 1)
            except IndexError as error:
                raise ValueError("incomplete word definition") from error
            except ValueError as error:
                raise ValueError("word definition is missing ;") from error

            if _is_number(name):
                raise ValueError("undefined operation: numbers cannot be redefined")

            definitions[name.upper()] = tokens[index + 1:body_end]
            index = body_end + 1
        elif upper_word in ARITHMETIC:
            if len(stack) < 2:
                raise StackUnderflowError("Insufficient number of items in stack")
            right = stack.pop()
            left = stack.pop()
            if upper_word == "/" and right == 0:
                raise ZeroDivisionError("divide by zero")
            stack.append(ARITHMETIC[upper_word](left, right))
        elif upper_word in STACK_WORDS:
            stack[:] = _apply_stack_word(upper_word, stack)
        elif upper_word in definitions:
            _evaluate(definitions[upper_word], definitions, stack)
        else:
            raise ValueError(f"undefined operation: {word}")


def evaluate(input_data):
    tokens = " ".join(input_data).split()
    stack = []
    _evaluate(tokens, {}, stack)
    return stack
