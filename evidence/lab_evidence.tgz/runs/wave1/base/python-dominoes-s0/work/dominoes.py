def can_chain(dominoes):
    """Return an ordered closed domino chain, or ``None`` if impossible."""
    if not dominoes:
        return []

    # Build a multigraph: each stone is an undirected edge between its halves.
    adjacency = {}
    for edge_id, (left, right) in enumerate(dominoes):
        adjacency.setdefault(left, []).append((right, edge_id))
        adjacency.setdefault(right, []).append((left, edge_id))

    # A closed Eulerian circuit requires all even degrees and connectivity.
    if any(len(neighbors) % 2 for neighbors in adjacency.values()):
        return None

    # Iterative Hierholzer's algorithm.
    start = dominoes[0][0]
    used = [False] * len(dominoes)
    remaining = {value: list(neighbors) for value, neighbors in adjacency.items()}
    circuit = []
    stack = [start]

    while stack:
        current = stack[-1]
        found = False
        for index, (neighbor, edge_id) in enumerate(remaining[current]):
            if not used[edge_id]:
                used[edge_id] = True
                del remaining[current][index]
                stack.append(neighbor)
                found = True
                break
        if not found:
            circuit.append(stack.pop())

    if not all(used):
        return None

    # Convert the vertex circuit into oriented stones.
    result = []
    for i in range(len(circuit)):
        left = circuit[i]
        right = circuit[(i + 1) % len(circuit)]
        result.append((left, right))

    # Verify we produced the exact multiset of stones.
    stone_pool = list(dominoes)
    chain = []
    for left, right in result:
        if (left, right) in stone_pool:
            stone_pool.remove((left, right))
            chain.append((left, right))
        elif (right, left) in stone_pool:
            stone_pool.remove((right, left))
            chain.append((right, left))
        else:
            return None
    if stone_pool:
        return None
    return chain
