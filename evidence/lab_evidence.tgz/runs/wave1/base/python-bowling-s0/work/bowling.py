class BowlingGame:
    def __init__(self):
        self.rolls = []

    def roll(self, pins):
        if isinstance(pins, bool) or not isinstance(pins, int):
            raise ValueError("invalid pin count: expected an integer")
        if pins < 0 or pins > 10:
            raise ValueError("invalid pin count: must be between 0 and 10")
        if self._is_complete():
            raise IndexError("cannot roll after the game is over")

        frame, roll_in_frame = self._position()

        prior_rolls = self.rolls
        if frame < 10:
            if roll_in_frame == 2 and pins > 10 - prior_rolls[-1]:
                raise ValueError("invalid roll: too many pins in the frame")
        elif roll_in_frame == 2 and prior_rolls[-1] < 10 and pins > 10 - prior_rolls[-1]:
            raise ValueError("invalid roll: too many pins in the tenth frame")
        elif roll_in_frame == 3:
            first, second = prior_rolls[-2], prior_rolls[-1]
            if first < 10 and first + second != 10:
                raise IndexError("cannot throw bonus with an open tenth frame")
            if first == 10 and second < 10 and pins > 10 - second:
                raise ValueError("invalid fill ball: too many pins in the tenth frame")

        self.rolls.append(pins)

    def score(self):
        if not self._is_complete():
            raise ValueError("incomplete game: all frames must be completed")

        total = 0
        roll_index = 0

        for frame in range(10):
            if frame < 9:
                if self.rolls[roll_index] == 10:
                    total += 10 + self.rolls[roll_index + 1] + self.rolls[roll_index + 2]
                    roll_index += 1
                else:
                    total += self.rolls[roll_index] + self.rolls[roll_index + 1]
                    roll_index += 2
            else:
                total += sum(self.rolls[roll_index:])

        return total

    def _position(self):
        frame = 1
        roll_index = 0
        while frame < 10 and roll_index < len(self.rolls):
            if self.rolls[roll_index] == 10:
                roll_index += 1
            else:
                if roll_index + 1 >= len(self.rolls):
                    break
                roll_index += 2
            frame += 1

        # An incomplete ordinary frame is still part of that frame.
        if frame < 10:
            return frame, (2 if roll_index < len(self.rolls) and self.rolls[roll_index] != 10 else 1)
        return 10, len(self.rolls) - roll_index + 1

    def _is_complete(self):
        # Advance through the nine ordinary frames to find the tenth frame.
        roll_index = 0
        for _ in range(9):
            if roll_index >= len(self.rolls):
                return False
            pins = self.rolls[roll_index]
            if pins == 10:
                roll_index += 1
            else:
                if roll_index + 1 >= len(self.rolls):
                    return False
                roll_index += 2

        tenth_rolls = self.rolls[roll_index:]
        if len(tenth_rolls) == 2:
            # A strike or spare earns fill balls; only an open frame ends here.
            return tenth_rolls[0] != 10 and sum(tenth_rolls) < 10
        return len(tenth_rolls) == 3
