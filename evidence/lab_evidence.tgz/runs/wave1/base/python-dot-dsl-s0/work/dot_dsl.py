NODE, EDGE, ATTR = range(3)


class Node:
    def __init__(self, name, attrs):
        self.name = name
        self.attrs = attrs

    def __eq__(self, other):
        return self.name == other.name and self.attrs == other.attrs


class Edge:
    def __init__(self, src, dst, attrs):
        self.src = src
        self.dst = dst
        self.attrs = attrs

    def __eq__(self, other):
        return (self.src == other.src and
                self.dst == other.dst and
                self.attrs == other.attrs)


class Graph:
    def __init__(self, data=None):
        if data is None:
            raise TypeError("Graph data malformed")

        self.attrs = []
        self.nodes = []
        self.edges = []

        for entry in data:
            if (
                not isinstance(entry, tuple)
                or not entry
                or entry[0] not in (NODE, EDGE, ATTR)
                or (entry[0] == ATTR and len(entry) != 3)
                or (entry[0] == NODE and len(entry) != 3)
                or (entry[0] == EDGE and len(entry) != 4)
            ):
                raise TypeError("Graph data malformed")

            if entry[0] == ATTR:
                if not self._valid_attrs([entry[1:]]):
                    raise ValueError("ATTR malformed")
                self.attrs.append((entry[1], entry[2]))
            elif entry[0] == NODE:
                if not self._valid_node(entry[1:]):
                    raise ValueError("NODE malformed")
                self.nodes.append(Node(entry[1], entry[2]))
            else:
                if not self._valid_edge(entry[1:]):
                    raise ValueError("EDGE malformed")
                self.edges.append(Edge(entry[1], entry[2], entry[3]))

    @staticmethod
    def _valid_attrs(attrs):
        return all(
            isinstance(attr, tuple)
            and len(attr) == 2
            and isinstance(attr[0], str)
            and isinstance(attr[1], str)
            for attr in attrs
        )

    @staticmethod
    def _valid_node(entry):
        return (
            isinstance(entry[0], str)
            and isinstance(entry[1], list)
            and Graph._valid_attrs(entry[1])
        )

    @staticmethod
    def _valid_edge(entry):
        return (
            isinstance(entry[0], str)
            and isinstance(entry[1], str)
            and isinstance(entry[2], list)
            and Graph._valid_attrs(entry[2])
        )
