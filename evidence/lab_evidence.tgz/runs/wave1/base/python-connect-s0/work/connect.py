class ConnectGame:
    def __init__(self, board):
        self.board = board
        self.winner = self._get_winner(board)

    def get_winner(self):
        return self.winner

    def _get_winner(self, board):
        return _board_winner(board)


def _board_winner(board):
    if isinstance(board, str):
        rows = board.splitlines()
    else:
        rows = list(board)

    rows = [row for row in rows if row.strip()]
    if not rows:
        return ""

    # A shared margin is formatting; per-row offsets encode the staggered
    # parallelogram and must be retained.
    indentation = min(len(row) - len(row.lstrip(" ")) for row in rows)
    if indentation:
        rows = [row[indentation:] for row in rows]
    grid = [_parse_row(row) for row in rows]

    winners = [player for player in ("O", "X") if _connects(grid, player)]
    return winners[0] if len(winners) == 1 else ""


def _parse_row(row):
    cells = [position for position, char in enumerate(row) if not char.isspace()]
    if not cells:
        return ""

    # Spaced diagrams have cells every other character. Unspaced diagrams use
    # each character as one cell.
    spaced = any(right - left > 1 for left, right in zip(cells, cells[1:]))
    width = (cells[-1] // 2 + 1) if spaced else (cells[-1] + 1)
    parsed = [" "] * width
    for position in cells:
        parsed[position // 2 if spaced else position] = row[position]
    return "".join(parsed)


def _connects(grid, player):
    height = len(grid)
    width = max(len(row) for row in grid)

    def cell_at(row, column):
        return grid[row][column] if column < len(grid[row]) else " "

    def component_connects(component):
        rows = [row for row, _ in component]
        columns = [column for _, column in component]

        if player == "O":
            return min(rows) == 0 and max(rows) == height - 1
        return min(columns) == 0 and max(columns) == width - 1

    directions = ((-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0))
    seen = set()

    for row in range(height):
        for column in range(width):
            if (row, column) in seen or cell_at(row, column) != player:
                continue

            component = set()
            search = [(row, column)]
            seen.add((row, column))

            while search:
                current = search.pop()
                component.add(current)
                current_row, current_column = current

                for delta_row, delta_column in directions:
                    neighbour = (current_row + delta_row, current_column + delta_column)
                    if neighbour in seen:
                        continue

                    neighbour_row, neighbour_column = neighbour
                    if not (0 <= neighbour_row < height and 0 <= neighbour_column < width):
                        continue
                    if cell_at(*neighbour) != player:
                        continue

                    seen.add(neighbour)
                    search.append(neighbour)

            if component_connects(component):
                return True

    return False
