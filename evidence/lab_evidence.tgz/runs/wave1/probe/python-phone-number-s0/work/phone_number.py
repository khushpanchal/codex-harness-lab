import string


class PhoneNumber:
    def __init__(self, number):
        letters = set(number) & set(string.ascii_letters)
        if letters:
            raise ValueError("letters not permitted")

        stripped = number.replace("-", "").replace(".", "").replace("(", "").replace(")", "").replace("+", "").replace(" ", "")

        if not stripped.isdigit():
            raise ValueError("punctuations not permitted")

        if len(stripped) < 10:
            raise ValueError("must not be fewer than 10 digits")
        if len(stripped) > 11:
            raise ValueError("must not be greater than 11 digits")

        if len(stripped) == 11:
            if stripped[0] != "1":
                raise ValueError("11 digits must start with 1")
            stripped = stripped[1:]

        if stripped[0] == "0":
            raise ValueError("area code cannot start with zero")
        if stripped[0] == "1":
            raise ValueError("area code cannot start with one")
        if stripped[3] == "0":
            raise ValueError("exchange code cannot start with zero")
        if stripped[3] == "1":
            raise ValueError("exchange code cannot start with one")

        self.number = stripped
