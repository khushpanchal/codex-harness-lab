NUMBER_WORDS = {
    10: "ten",
    9: "nine",
    8: "eight",
    7: "seven",
    6: "six",
    5: "five",
    4: "four",
    3: "three",
    2: "two",
    1: "one",
    0: "no",
}


def _word(count):
    return NUMBER_WORDS[count]


def _verse(count):
    remaining = count - 1
    return [
        f"{_word(count).capitalize()} green bottle{'s' if count != 1 else ''} "
        f"hanging on the wall,",
        f"{_word(count).capitalize()} green bottle{'s' if count != 1 else ''} "
        f"hanging on the wall,",
        "And if one green bottle should accidentally fall,",
        f"There'll be {_word(remaining)} green "
        f"bottle{'s' if remaining != 1 else ''} hanging on the wall.",
    ]


def recite(start, take=1):
    verses = ["\n".join(_verse(count)) for count in range(start, start - take, -1)]
    return verses[0] if take == 1 else "\n\n".join(verses)
