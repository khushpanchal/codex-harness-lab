from json import dumps


class Tree:
    def __init__(self, label, children=None):
        self.label = label
        self.children = children if children is not None else []

    def __dict__(self):
        return {self.label: [c.__dict__() for c in sorted(self.children)]}

    def __str__(self, indent=None):
        return dumps(self.__dict__(), indent=indent)

    def __lt__(self, other):
        return self.label < other.label

    def __eq__(self, other):
        return self.__dict__() == other.__dict__()

    def _find_path(self, target, path):
        path.append(self)
        if self.label == target:
            return True
        for child in self.children:
            if child._find_path(target, path):
                return True
        path.pop()
        return False

    def _path(self, target):
        path = []
        if not self._find_path(target, path):
            raise ValueError(f"{target!r} is not in the tree")
        return path

    def path_to(self, from_node, to_node):
        from_path = self._path(from_node)
        to_path = self._path(to_node)
        return [node.label for node in reversed(to_path)]

    def _rebuild_from_path(self, path, index):
        node = path[index]
        child_on_path = path[index + 1] if index + 1 < len(path) else None
        children = [child for child in node.children if child is not child_on_path]
        if index > 0:
            children.append(self._rebuild_from_path(path, index - 1))
        return Tree(node.label, children)

    def from_pov(self, from_node):
        path = []
        if not self._find_path(from_node, path):
            raise ValueError(f"Tree does not contain from_node {from_node!r}")
        return self._rebuild_from_path(path, len(path) - 1)
