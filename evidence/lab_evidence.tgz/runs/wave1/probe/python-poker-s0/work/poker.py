RANK_LABELS = {"2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7,
               "8": 8, "9": 9, "10": 10, "J": 11, "Q": 12,
               "K": 13, "A": 14}

STRAIGHT_FLUSH = 8
FOUR_OF_A_KIND = 7
FULL_HOUSE = 6
FLUSH = 5
STRAIGHT = 4
THREE_OF_A_KIND = 3
TWO_PAIR = 2
PAIR = 1
HIGH_CARD = 0


def _parse(hand):
    cards = hand.split()
    if len(cards) != 5:
        raise ValueError("a poker hand must contain five cards")

    ranks = []
    suits = set()
    for card in cards:
        rank_label, suit = card[:-1], card[-1]
        try:
            rank = RANK_LABELS[rank_label]
        except KeyError as exc:
            raise ValueError(f"invalid rank in card {card!r}") from exc
        ranks.append(rank)
        suits.add(suit)

    ranks.sort(reverse=True)
    groups = {}
    for rank in ranks:
        groups[rank] = groups.get(rank, 0) + 1

    counts = sorted(groups.values(), reverse=True)
    # Tuple is compared by hand category, then by the significant ranks.
    ordered_groups = sorted(groups.items(), key=lambda item: (item[1], item[0]), reverse=True)
    significant_ranks = tuple(rank for rank, _ in ordered_groups)

    category = HIGH_CARD
    if counts == [4, 1]:
        category = FOUR_OF_A_KIND
    elif counts == [3, 2]:
        category = FULL_HOUSE
    elif counts == [3, 1, 1]:
        category = THREE_OF_A_KIND
    elif counts == [2, 2, 1]:
        category = TWO_PAIR
    elif counts == [2, 1, 1, 1]:
        category = PAIR
    else:
        is_flush = len(suits) == 1
        is_straight = _straight_high(ranks) is not None
        if is_flush and is_straight:
            category = STRAIGHT_FLUSH
        elif is_flush:
            category = FLUSH
        elif is_straight:
            category = STRAIGHT

    if category in (STRAIGHT, STRAIGHT_FLUSH):
        significant_ranks = (_straight_high(ranks),)

    return (category,) + significant_ranks


def _straight_high(sorted_descending_ranks):
    """Return the ranking high card for a straight, else None."""
    if len(set(sorted_descending_ranks)) != 5:
        return None
    if sorted_descending_ranks[0] - sorted_descending_ranks[-1] == 4:
        return sorted_descending_ranks[0]
    # A, 5, 4, 3, 2 is a valid straight with five high.
    if sorted_descending_ranks == [14, 5, 4, 3, 2]:
        return 5
    return None


def best_hands(hands):
    if not hands:
        return []

    ranked = [(hand, _parse(hand)) for hand in hands]
    best = max(score for _, score in ranked)
    return [hand for hand, score in ranked if score == best]
