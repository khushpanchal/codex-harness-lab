from decimal import Decimal
import json


def _amount(value):
    if isinstance(value, Decimal):
        return value
    if isinstance(value, int):
        return Decimal(value)
    # Decimal(str(...)) avoids binary floating-point artifacts such as
    # 0.1 + 0.2 == 0.30000000000000004.
    return Decimal(str(value))


class RestAPI:
    def __init__(self, database=None):
        self.users = {}
        if database:
            for user in database.get("users", []):
                self._add_user(user)

    def _add_user(self, data):
        name = data["name"]
        owes = {other: _amount(value) for other, value in data.get("owes", {}).items()}
        owed_by = {
            other: _amount(value) for other, value in data.get("owed_by", {}).items()
        }
        self.users[name] = {"owes": owes, "owed_by": owed_by}

    @staticmethod
    def _payload_dict(payload):
        if payload is None:
            return {}
        if isinstance(payload, str):
            return json.loads(payload)
        return payload

    @staticmethod
    def _plain_amount(value):
        value = value.normalize()
        return int(value) if value == value.to_integral_value() else float(value)

    def _user_response(self, name):
        user = self.users[name]
        return {
            "name": name,
            "owes": {other: self._plain_amount(value) for other, value in user["owes"].items()},
            "owed_by": {
                other: self._plain_amount(value) for other, value in user["owed_by"].items()
            },
            "balance": self._plain_amount(
                sum(user["owed_by"].values(), Decimal("0"))
                - sum(user["owes"].values(), Decimal("0"))
            ),
        }

    def get(self, url, payload=None):
        if url != "/users":
            return None
        names = self._payload_dict(payload).get("users", sorted(self.users))
        return {"users": [self._user_response(name) for name in sorted(names)]}

    def post(self, url, payload=None):
        payload = self._payload_dict(payload)
        if url == "/add":
            name = payload["user"]
            self._add_user({"name": name})
            return self._user_response(name)

        if url == "/iou":
            lender = payload["lender"]
            borrower = payload["borrower"]
            amount = _amount(payload["amount"])

            # Each pair has one effective debt direction. Clear both possible
            # records and calculate the net amount before adding new debt.
            prior_borrower_owes_lender = self.users[borrower]["owed_by"].pop(lender, Decimal("0"))
            prior_lender_owes_borrower = self.users[lender]["owes"].pop(borrower, Decimal("0"))
            amount -= prior_borrower_owes_lender + prior_lender_owes_borrower
            self.users[borrower]["owes"].pop(lender, None)
            self.users[lender]["owed_by"].pop(borrower, None)

            if amount > 0:
                self.users[lender]["owed_by"][borrower] = (
                    self.users[lender]["owed_by"].get(borrower, Decimal("0")) + amount
                )
                self.users[borrower]["owes"][lender] = (
                    self.users[borrower]["owes"].get(lender, Decimal("0")) + amount
                )
            elif amount < 0:
                amount = -amount
                self.users[borrower]["owed_by"][lender] = (
                    self.users[borrower]["owed_by"].get(lender, Decimal("0")) + amount
                )
                self.users[lender]["owes"][borrower] = (
                    self.users[lender]["owes"].get(borrower, Decimal("0")) + amount
                )

            return {
                "users": [
                    self._user_response(name)
                    for name in sorted((lender, borrower))
                ]
            }

        return None
