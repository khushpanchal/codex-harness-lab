def grep(pattern, flags, files):
    results = []
    case_insensitive = "-i" in flags
    needle = pattern.lower() if case_insensitive else pattern
    whole_line = "-x" in flags
    invert = "-v" in flags

    def matches(line):
        text = line.lower() if case_insensitive else line
        return text == needle if whole_line else needle in text

    for filename in files:
        with open(filename, encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, 1):
                line = line.rstrip("\n")
                if matches(line) != invert:
                    if "-l" in flags:
                        results.append(filename)
                        break
                    output = line
                    if "-n" in flags:
                        output = f"{line_number}:{output}"
                    if len(files) > 1:
                        output = f"{filename}:{output}"
                    results.append(output)

    return results
