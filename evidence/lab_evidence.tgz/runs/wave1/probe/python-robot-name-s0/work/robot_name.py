class Robot:
    def __init__(self):
        pass
import random


class Robot:
    _names_in_use = set()
    _available_names = set(
        f"{letters}{digits:03d}"
        for letters in (
            f"{first}{second}"
            for first in "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            for second in "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        )
        for digits in range(1000)
    )

    def __init__(self):
        self._name = None

    @property
    def name(self):
        if self._name is None:
            self._name = random.choice(tuple(self._available_names))
            self._available_names.remove(self._name)
            self._names_in_use.add(self._name)
        return self._name

    def reset_name(self):
        if self._name is not None:
            self._names_in_use.remove(self._name)
            self._available_names.add(self._name)
            self._name = None
            self.name
