class BowlingGame:
    def __init__(self):
        self.frame = 1
        self.pins_remaining = 10
        self.rolls_in_current_frame = 0
        self.finished = False
        self.rolls = []

    def roll(self, pins):
        if not isinstance(pins, int) or isinstance(pins, bool):
            raise ValueError("pins knocked down must be an integer")
        if pins < 0 or pins > 10:
            raise ValueError("pins knocked down must be between 0 and 10")
        if self.finished:
            raise IndexError("cannot throw bonus with an open tenth frame")
        if pins > self.pins_remaining:
            raise ValueError("invalid roll: more pins knocked down than standing")

        self.rolls.append(pins)
        self.rolls_in_current_frame += 1

        if self.frame < 10:
            if pins == 10 or self.rolls_in_current_frame == 2:
                self.frame += 1
                self.rolls_in_current_frame = 0
                self.pins_remaining = 10
            else:
                self.pins_remaining -= pins
            return

        frame_is_complete = pins == 10 or (
            self.rolls_in_current_frame == 2
            and (sum(self.rolls[-2:]) == 10 or self.rolls[-2] == 10)
        )
        if frame_is_complete:
            self.pins_remaining = 10
        else:
            self.pins_remaining -= pins

        if self.rolls_in_current_frame == 2:
            first, second = self.rolls[-2:]
            self.finished = first != 10 and first + second != 10
        elif self.rolls_in_current_frame == 3:
            self.finished = True

    def score(self):
        if not self.finished:
            raise ValueError("incomplete game: score is only available after ten frames")

        total = 0
        roll_index = 0
        for _ in range(10):
            if self.rolls[roll_index] == 10:
                total += 10 + self.rolls[roll_index + 1] + self.rolls[roll_index + 2]
                roll_index += 1
            else:
                frame_total = self.rolls[roll_index] + self.rolls[roll_index + 1]
                if frame_total == 10:
                    total += 10 + self.rolls[roll_index + 2]
                else:
                    total += frame_total
                roll_index += 2
        return total
