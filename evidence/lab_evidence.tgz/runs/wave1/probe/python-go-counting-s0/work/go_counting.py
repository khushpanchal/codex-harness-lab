class Board:
    """Count territories of each player in a Go game.

    Args:
        board (list[str]): A two-dimensional Go board.
    """

    def __init__(self, board):
        self.board = board
        self.height = len(board)
        self.width = len(board[0]) if self.height else 0

    def territory(self, x, y):
        """Find the owner and the territory containing a coordinate.

        Args:
            x (int): Column on the board.
            y (int): Row on the board.

        Returns:
            (str, set): The owner (``"W"``, ``"B"``, or ``""``) and the
                coordinates in that owner's territory.
        """
        if not isinstance(x, int) or not isinstance(y, int):
            raise ValueError('Invalid coordinate')
        if not (0 <= x < self.width and 0 <= y < self.height):
            raise ValueError('Invalid coordinate')
        if self.board[y][x] != ' ':
            raise ValueError('Invalid coordinate')

        owners = set()
        territory = set()
        to_visit = [(x, y)]
        seen = {(x, y)}

        while to_visit:
            point = to_visit.pop()
            territory.add(point)

            for neighbor in self._neighbors(point):
                nx, ny = neighbor
                value = self.board[ny][nx]
                if value in {'B', 'W'}:
                    owners.add(value)
                elif neighbor not in seen:
                    seen.add(neighbor)
                    to_visit.append(neighbor)

        owner = owners.pop() if len(owners) == 1 else ''
        return owner, territory

    def territories(self):
        """Find the owners and territories of the whole board.

        Returns:
            dict(str, set): A dictionary keyed by each owner (``"W"``,
                ``"B"``, and ``""``), with the owned coordinates as values.
        """
        result = {'B': set(), 'W': set(), '': set()}
        visited = set()

        for y, row in enumerate(self.board):
            for x, value in enumerate(row):
                if value == ' ' and (x, y) not in visited:
                    owner, territory = self.territory(x, y)
                    result[owner].update(territory)
                    visited.update(territory)

        return result

    def _neighbors(self, point):
        x, y = point
        candidates = ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1))
        return (point for point in candidates
                if 0 <= point[0] < self.width and 0 <= point[1] < self.height)
