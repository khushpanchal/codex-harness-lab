def transpose(text):
    rows = text.splitlines()
    if not rows:
        return ""

    width = max(len(row) for row in rows)
    # Right-align every row so that unequal input rows are padded on the left.
    transposed = ["" for _ in range(width)]
    for row in rows:
        padded = row.rjust(width)
        for column, char in enumerate(padded):
            transposed[column] += char

    # Spaces here can only be right-padding from alignment, so removing them
    # preserves all original characters.
    return "\n".join(row.rstrip() for row in transposed)
