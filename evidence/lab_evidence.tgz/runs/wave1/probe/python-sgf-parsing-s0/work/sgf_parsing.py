class SgfTree:
    def __init__(self, properties=None, children=None):
        self.properties = properties or {}
        self.children = children or []

    def __eq__(self, other):
        if not isinstance(other, SgfTree):
            return False
        for key, value in self.properties.items():
            if key not in other.properties:
                return False
            if other.properties[key] != value:
                return False
        for key in other.properties.keys():
            if key not in self.properties:
                return False
        if len(self.children) != len(other.children):
            return False
        for child, other_child in zip(self.children, other.children):
            if child != other_child:
                return False
        return True

    def __ne__(self, other):
        return not self == other


def parse(input_string):
    class Parser:
        def __init__(self, text):
            self.text = text
            self.pos = 0

        def skip_whitespace(self):
            while self.pos < len(self.text) and self.text[self.pos] in " \t\r\n":
                self.pos += 1

        def expect(self, char, message):
            self.skip_whitespace()
            if self.pos >= len(self.text) or self.text[self.pos] != char:
                raise ValueError(message)
            self.pos += 1

        def read_property_identifier(self):
            identifier = []
            while self.pos < len(self.text) and self.text[self.pos].isalpha():
                char = self.text[self.pos]
                if char.islower():
                    raise ValueError("property must be in uppercase")
                identifier.append(char)
                self.pos += 1
            if not identifier:
                raise ValueError("property must be in uppercase")
            return "".join(identifier)

        def read_value(self):
            self.skip_whitespace()
            if self.pos >= len(self.text) or self.text[self.pos] != "[":
                raise ValueError("properties without delimiter")
            self.pos += 1
            value = []
            while self.pos < len(self.text):
                char = self.text[self.pos]
                self.pos += 1
                if char == "]":
                    return "".join(value)
                if char != "\\":
                    if char in " \t\r":
                        char = " "
                    value.append(char)
                    continue
                if self.pos >= len(self.text):
                    break
                escaped = self.text[self.pos]
                self.pos += 1
                if escaped in " \t\r\n":
                    if escaped != "\n":
                        value.append(" ")
                    continue
                value.append(escaped)
            raise ValueError("properties without delimiter")

        def parse_tree(self):
            self.expect("(", "tree missing")
            nodes = []
            while True:
                self.skip_whitespace()
                if self.pos < len(self.text) and self.text[self.pos] == ";":
                    nodes.append(self.parse_node())
                else:
                    break
            if not nodes:
                raise ValueError("tree with no nodes")
            children = []
            while True:
                self.skip_whitespace()
                if self.pos < len(self.text) and self.text[self.pos] == "(":
                    children.append(self.parse_tree())
                else:
                    break
            self.expect(")", "tree missing")
            first = SgfTree(nodes[-1])
            for node in reversed(nodes[:-1]):
                first = SgfTree(node, [first])
            if children:
                if first.children:
                    raise ValueError("tree missing")
                first.children = children
            return first

        def parse_node(self):
            self.pos += 1
            properties = {}
            while True:
                self.skip_whitespace()
                if self.pos >= len(self.text):
                    raise ValueError("properties without delimiter")
                char = self.text[self.pos]
                if char in "(;)":
                    return properties
                if char != "[":
                    identifier = self.read_property_identifier()
                    properties[identifier] = []
                    while True:
                        self.skip_whitespace()
                        if self.pos < len(self.text) and self.text[self.pos] == "[":
                            properties[identifier].append(self.read_value())
                        else:
                            break
                else:
                    raise ValueError("properties without delimiter")

    text = input_string
    if not isinstance(text, str):
        raise ValueError("tree missing")
    text = text.lstrip()
    if not text:
        raise ValueError("tree missing")
    parser = Parser(text)
    tree = parser.parse_tree()
    parser.skip_whitespace()
    if parser.pos != len(parser.text):
        raise ValueError("tree missing")
    return tree
