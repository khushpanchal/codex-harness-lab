def proverb(*inputs, qualifier=""):
    first = inputs[0]
    lines = [
        f"For want of a {cause} the {effect} was lost."
        for cause, effect in zip(inputs, inputs[1:])
    ]
    final_noun = f"{qualifier} {first}" if qualifier else first
    lines.append(f"And all for the want of a {final_noun}.")
    return lines
