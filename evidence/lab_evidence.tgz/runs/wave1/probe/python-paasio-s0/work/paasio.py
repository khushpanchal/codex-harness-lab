import io


class MeteredFile(io.BufferedRandom):
    """Implement using a subclassing model."""

    def __new__(cls, *args, **kwargs):
        self = super().__new__(cls)
        self._read_bytes = 0
        self._read_ops = 0
        self._write_bytes = 0
        self._write_ops = 0
        return self

    def __init__(self, *args, **kwargs):
        if args and isinstance(args[0], int):
            super().__init__(io.FileIO(args[0], mode='r+b', closefd=False))
        elif args and isinstance(args[0], io.IOBase):
            super().__init__(args[0])
        else:
            super().__init__(open(*args, **kwargs))

    def __enter__(self):
        super().__enter__()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return super().__exit__(exc_type, exc_val, exc_tb)

    def __iter__(self):
        return self

    def __next__(self):
        line = super().readline()
        self._read_bytes += len(line)
        self._read_ops += 1
        if not line:
            raise StopIteration
        return line

    def read(self, size=-1):
        data = super().read(size)
        self._read_bytes += len(data)
        self._read_ops += 1
        return data

    @property
    def read_bytes(self):
        return self._read_bytes

    @property
    def read_ops(self):
        return self._read_ops

    def write(self, b):
        written = super().write(b)
        self._write_bytes += written
        self._write_ops += 1
        return written

    @property
    def write_bytes(self):
        return self._write_bytes

    @property
    def write_ops(self):
        return self._write_ops


class MeteredSocket:
    """Implement using a delegation model."""

    def __init__(self, socket):
        self._socket = socket
        self._recv_bytes = 0
        self._recv_ops = 0
        self._send_bytes = 0
        self._send_ops = 0

    def __getattr__(self, name):
        # Delegate everything except the statistics and wrapped socket itself.
        if name.startswith("_") or name in {
            "recv_bytes", "recv_ops", "send_bytes", "send_ops"
        }:
            raise AttributeError(name)
        return getattr(self._socket, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return self._socket.__exit__(exc_type, exc_val, exc_tb)

    def recv(self, bufsize, flags=0):
        data = self._socket.recv(bufsize, flags)
        self._recv_bytes += len(data)
        self._recv_ops += 1
        return data

    @property
    def recv_bytes(self):
        return self._recv_bytes

    @property
    def recv_ops(self):
        return self._recv_ops

    def send(self, data, flags=0):
        sent = self._socket.send(data, flags)
        self._send_bytes += sent
        self._send_ops += 1
        return sent

    @property
    def send_bytes(self):
        return self._send_bytes

    @property
    def send_ops(self):
        return self._send_ops
