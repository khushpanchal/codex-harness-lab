class InputCell:
    def __init__(self, initial_value):
        self._value = initial_value
        self._dependents = []

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, new_value):
        if new_value != self._value:
            self._value = new_value
            _propagate(self)


class ComputeCell:
    def __init__(self, inputs, compute_function):
        self._inputs = list(inputs)
        self._compute_function = compute_function
        self._value = compute_function([cell.value for cell in self._inputs])
        self._dependents = []
        self._callbacks = {}

        for cell in self._inputs:
            if self not in cell._dependents:
                cell._dependents.append(self)

    @property
    def value(self):
        return self._value

    def add_callback(self, callback):
        self._callbacks[callback] = None

    def remove_callback(self, callback):
        self._callbacks.pop(callback, None)


def _reachable_dependents(start):
    reachable = set()
    pending = [cell for cell in start._dependents]

    while pending:
        cell = pending.pop()
        if cell in reachable:
            continue
        reachable.add(cell)
        pending.extend(cell._dependents)

    return reachable


def _propagate(start):
    # Updating only cells reachable from the changed cell keeps unrelated
    # parts of the graph untouched, and topological order ensures that a
    # cell sees every updated input before it is recomputed.
    reachable = _reachable_dependents(start)
    updated = {start}
    changed_callbacks = []

    pending = {
        cell: sum(1 for dependency in cell._inputs if dependency in reachable)
        for cell in reachable
    }
    ready = [cell for cell, count in pending.items() if count == 0]

    while ready:
        cell = ready.pop()
        old_value = cell._value
        cell._value = cell._compute_function(
            [dependency.value for dependency in cell._inputs]
        )
        if cell._value != old_value:
            updated.add(cell)
            changed_callbacks.append(cell)

        for dependent in cell._dependents:
            if dependent in reachable:
                pending[dependent] -= 1
                if pending[dependent] == 0:
                    ready.append(dependent)

    # Notify after propagation so callbacks observe a stable graph state.
    for cell in changed_callbacks:
        for callback in list(cell._callbacks):
            callback(cell._value)
    
