from math import gcd


ALPHABET_SIZE = 26
OUTPUT_GROUP_SIZE = 5


def _validate_key(a, b):
    if gcd(a, ALPHABET_SIZE) != 1:
        raise ValueError("a and m must be coprime.")
    return a % ALPHABET_SIZE, b % ALPHABET_SIZE


def _modular_inverse(a):
    return pow(a, -1, ALPHABET_SIZE)


def _letters(text):
    return [character.lower() for character in text if character.isalnum()]


def encode(plain_text, a, b):
    a, b = _validate_key(a, b)
    encoded = []
    for character in _letters(plain_text):
        if character.isdigit():
            encoded.append(character)
            continue
        value = ord(character) - ord("a")
        encoded.append(chr(ord("a") + (a * value + b) % ALPHABET_SIZE))
    groups = [
        "".join(encoded[index:index + OUTPUT_GROUP_SIZE])
        for index in range(0, len(encoded), OUTPUT_GROUP_SIZE)
    ]
    return " ".join(groups)


def decode(ciphered_text, a, b):
    a, b = _validate_key(a, b)
    inverse_a = _modular_inverse(a)
    decoded = []
    for character in _letters(ciphered_text):
        if character.isdigit():
            decoded.append(character)
            continue
        value = ord(character) - ord("a")
        decoded.append(
            chr(ord("a") + inverse_a * (value - b) % ALPHABET_SIZE)
        )
    return "".join(decoded)
