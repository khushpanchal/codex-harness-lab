from functools import lru_cache
from itertools import combinations


_GROUP_SIZE_COST = {
    0: 0,
    1: 800,
    2: 1520,  # 8 dollars less 5%
    3: 2160,  # 24 dollars less 10%
    4: 2560,  # 32 dollars less 20%
    5: 3000,  # 40 dollars less 25%
}


def total(basket):
    counts = [0] * 5
    for book in basket:
        counts[book - 1] += 1
    return _minimum_total(tuple(counts)) / 100


@lru_cache(maxsize=None)
def _minimum_total(counts):
    if not any(counts):
        return 0

    # Comparing normalized count vectors prevents equivalent groupings
    # (for example, "book 1 then 2" versus "book 2 then 1") from being
    # explored as separate states.
    available = [index for index, count in enumerate(counts) if count]
    best = min(
        _minimum_total(_without_group(counts, sum(1 << index for index in group)))
        + _GROUP_SIZE_COST[len(group)]
        for size in range(1, len(available) + 1)
        for group in combinations(available, size)
    )

    return best


def _without_group(counts, mask):
    result = []
    for index, count in enumerate(counts):
        count -= bool(mask & (1 << index))
        if count > 0:
            result.append(count)
    return tuple(sorted(result))
