VOWELS = frozenset("aeiou")


def translate(text):
    return " ".join(translate_word(word) for word in text.split())


def translate_word(word):
    if word.startswith("xr") or word.startswith("yt") or word[0] in VOWELS:
        return word + "ay"

    # y acts as a vowel after an initial consonant cluster.
    for index in range(1, len(word)):
        if word[index] in VOWELS or word[index] == "y":
            if word[index] == "u" and word[index - 1] == "q":
                index += 1
            return word[index:] + word[:index] + "ay"

    return word + "ay"
