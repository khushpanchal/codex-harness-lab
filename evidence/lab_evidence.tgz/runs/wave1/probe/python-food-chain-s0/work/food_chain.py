ANIMALS = ("fly", "spider", "bird", "cat", "dog", "goat", "cow", "horse")

OPENINGS = {
    "bird": "How absurd to swallow a bird!",
    "cat": "Imagine that, to swallow a cat!",
    "dog": "What a hog, to swallow a dog!",
    "goat": "Just opened her throat and swallowed a goat!",
    "cow": "I don't know how she swallowed a cow!",
}

SPECIAL_LINES = {
    "fly": "I don't know why she swallowed the fly. Perhaps she'll die.",
    "spider": "It wriggled and jiggled and tickled inside her.",
    "horse": "She's dead, of course!",
}


def _verse(animal):
    lines = [f"I know an old lady who swallowed a {animal}."]

    if animal in SPECIAL_LINES:
        lines.append(SPECIAL_LINES[animal])

    if animal == "horse":
        return lines

    if animal != "fly":
        if animal in OPENINGS:
            lines.append(OPENINGS[animal])

        caught = ANIMALS[: ANIMALS.index(animal)][::-1]
        for prey in caught:
            line = f"She swallowed the {animal} to catch the {prey}"
            if prey == "spider":
                line += " that wriggled and jiggled and tickled inside her"
            lines.append(line + ".")
            animal = prey

    return lines


def recite(start_verse, end_verse):
    if not 1 <= start_verse <= end_verse <= len(ANIMALS):
        raise ValueError("verse number out of range")

    verses = [_verse(ANIMALS[index]) for index in range(start_verse - 1, end_verse)]
    result = []
    for index, verse in enumerate(verses):
        result.extend(verse)
        result.append("")
    return result
