from collections import defaultdict


def can_chain(dominoes):
    """Return one valid closed chain, or ``None`` if no such chain exists.

    Treat each domino as an edge in an undirected multigraph and construct an
    Eulerian circuit, using both possible orientations of each stone.
    """
    if dominoes is None:
        return None

    dominoes = list(dominoes)
    if not dominoes:
        return []

    for stone in dominoes:
        if not isinstance(stone, tuple) or len(stone) != 2:
            raise TypeError("dominoes must contain two-element tuples")
        left, right = stone
        if not isinstance(left, int) or not isinstance(right, int):
            raise TypeError("domino halves must contain integers")

    degree = defaultdict(int)
    adjacency = defaultdict(list)
    for index, (left, right) in enumerate(dominoes):
        degree[left] += 1
        degree[right] += 1
        adjacency[left].append((right, index, True))
        if left == right:
            continue
        adjacency[right].append((left, index, False))

    connected_values = {value for value, count in degree.items() if count}
    if len(connected_values) > 1 and not _is_connected(adjacency, connected_values):
        return None
    if any(count % 2 for count in degree.values()):
        return None

    # Every value is a possible starting point; changing roots also changes
    # which outer values meet, which can matter for chains such as [1|1].
    for root in sorted(connected_values):
        chain = _euler_circuit(dominoes, adjacency, root)
        if chain and len(chain) == len(dominoes):
            return chain
    return None


def _is_connected(adjacency, connected_values):
    start = next(iter(connected_values))
    visited = {start}
    pending = [start]
    while pending:
        value = pending.pop()
        for neighbour, _index, _forward in adjacency[value]:
            if neighbour not in visited:
                visited.add(neighbour)
                pending.append(neighbour)
    return visited == connected_values


def _euler_circuit(dominoes, original_adjacency, root):
    # Hierholzer's algorithm, with mutable stacks and per-edge use flags.
    adjacency = defaultdict(list)
    for value, edges in original_adjacency.items():
        adjacency[value] = list(edges)
    used = [False] * len(dominoes)
    oriented_stones = []
    pending = [(root, [])]
    while pending:
        value, incoming = pending[-1]
        while adjacency[value]:
            neighbour, index, forward = adjacency[value].pop()
            if not used[index]:
                used[index] = True
                left, right = dominoes[index]
                stone = (left, right) if forward else (right, left)
                pending.append((neighbour, [stone]))
                break
        else:
            _value, incoming = pending.pop()
            oriented_stones.extend(incoming)
    if not all(used):
        return None
    return oriented_stones
