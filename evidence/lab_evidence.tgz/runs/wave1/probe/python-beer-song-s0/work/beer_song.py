def recite(start, take=1):
    verses = []
    for count in range(start, start - take, -1):
        verses.append(verse(count))
    return [line for i, verse_lines in enumerate(verses)
            for line in verse_lines + ([""] if i < len(verses) - 1 else [])]


def verse(count):
    if count == 0:
        return [
            "No more bottles of beer on the wall, no more bottles of beer.",
            "Go to the store and buy some more, 99 bottles of beer on the wall.",
        ]
    return [
        f"{quantity(count)} of beer on the wall, {quantity(count)} of beer.",
        f"{action(count)}, {quantity(count - 1)} of beer on the wall.",
    ]


def quantity(count):
    if count == 1:
        return "1 bottle"
    if count == 0:
        return "no more bottles"
    return f"{count} bottles"


def action(count):
    return "Take it down and pass it around" if count == 1 else "Take one down and pass it around"
