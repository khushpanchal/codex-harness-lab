class Scale:
    def __init__(self, tonic):
        self._is_flat = tonic in self._FLAT_TONICS
        self._tonic = self._canonical_tonic(tonic)

    _SHARP_SCALE = ["A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#"]
    _FLAT_SCALE = ["A", "Bb", "B", "C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab"]
    _SHARP_TONICS = {
        "G", "D", "A", "E", "B", "F#",
        "e", "b", "f#", "c#", "g#", "d#",
    }
    _FLAT_TONICS = {
        "F", "Bb", "Eb", "Ab", "Db", "Gb",
        "d", "g", "c", "f", "Bb-", "Eb-", "Ab-", "Db-", "Gb-",
    }

    @classmethod
    def _canonical_tonic(cls, tonic):
        tonic = tonic.strip()
        if tonic in cls._SHARP_TONICS or tonic in cls._FLAT_TONICS:
            return cls._canonical_case(tonic)

        # Case-insensitive matching while preserving minor tonic spellings,
        # whose accidental notation determines sharp/flat key signatures.
        lowered = tonic.lower()
        for spelling in cls._SHARP_TONICS | cls._FLAT_TONICS:
            if spelling.lower() == lowered:
                return cls._canonical_case(spelling)

        raise ValueError(f"invalid tonic: {tonic}")

    @classmethod
    def _canonical_case(cls, tonic):
        return tonic[0].upper() + tonic[1:].lower()

    def _chromatic_starting_at(self, tonic):
        spelling = self._FLAT_SCALE if self._is_flat else self._SHARP_SCALE
        start = spelling.index(tonic)
        return spelling[start:] + spelling[:start]

    def chromatic(self):
        return self._chromatic_starting_at(self._tonic)

    def interval(self, intervals):
        if not isinstance(intervals, str):
            raise ValueError("intervals must be a string")
        if any(character not in "mMA" for character in intervals):
            raise ValueError("invalid interval pattern")

        chromatic = self._chromatic_starting_at(self._tonic)
        current = 0
        notes = [self._tonic]
        for interval in intervals:
            current += {"m": 1, "M": 2, "A": 3}[interval]
            if current > len(chromatic):
                raise ValueError("interval pattern exceeds one octave")
            notes.append(chromatic[current % len(chromatic)])
        return notes
