
class ConnectGame:
    def __init__(self, board):
        self._winner = self._determine_winner(board)

    def get_winner(self):
        return self._winner

    @staticmethod
    def _determine_winner(board):
        if isinstance(board, str):
            board = board.splitlines()

        rows = []
        for line in board:
            # Dots must be retained: they define the board's width and edges.
            # Leading indentation only renders the staggered shape.
            cells = line.split()
            if cells:
                rows.append(cells)

        if not rows:
            return None

        width = max(map(len, rows))

        def has_connection(player, starts, reaches_end):
            seen = set(starts)
            stack = list(starts)
            while stack:
                row, col = stack.pop()
                if reaches_end(row, col):
                    return True

                # On a rhombic Hex board, a lower row is shifted one cell to
                # the right, so vertical neighbours also move horizontally.
                neighbours = (
                    (row, col - 1),
                    (row, col + 1),
                    (row - 1, col),
                    (row + 1, col),
                    (row - 1, col + 1),
                    (row + 1, col - 1),
                )
                for nrow, ncol in neighbours:
                    if (
                        0 <= nrow < len(rows)
                        and 0 <= ncol < len(rows[nrow])
                        and rows[nrow][ncol] == player
                        and (nrow, ncol) not in seen
                    ):
                        seen.add((nrow, ncol))
                        stack.append((nrow, ncol))
            return False

        o_starts = [(0, col) for col, cell in enumerate(rows[0]) if cell == 'O']
        x_starts = [
            (row, 0) for row, cells in enumerate(rows) if cells and cells[0] == 'X'
        ]

        o_wins = has_connection(
            'O', o_starts, lambda row, _col: row == len(rows) - 1
        )
        x_wins = has_connection(
            'X', x_starts, lambda _row, col: col == width - 1
        )

        if o_wins and x_wins:
            return None
        if o_wins:
            return 'O'
        if x_wins:
            return 'X'
        return None
