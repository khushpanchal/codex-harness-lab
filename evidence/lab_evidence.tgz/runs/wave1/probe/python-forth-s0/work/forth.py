class StackUnderflowError(Exception):
    """Raised when an operation requires more stack items than are available."""

    def __init__(self, message):
        super().__init__(message)
        self.message = message


def evaluate(input_data):
    stack = []
    definitions = {}

    def require_items(count, word):
        if len(stack) < count:
            raise StackUnderflowError(
                "Insufficient number of items in stack"
            )

    def add():
        require_items(2, "+")
        stack.append(stack.pop() + stack.pop())

    def subtract():
        require_items(2, "-")
        right = stack.pop()
        stack[-1] -= right

    def multiply():
        require_items(2, "*")
        stack.append(stack.pop() * stack.pop())

    def divide():
        require_items(2, "/")
        right = stack.pop()
        if right == 0:
            raise ZeroDivisionError("divide by zero")
        left = stack.pop()
        quotient = abs(left) // abs(right)
        if (left < 0) != (right < 0):
            quotient = -quotient
        stack.append(quotient)

    def duplicate():
        require_items(1, "DUP")
        stack.append(stack[-1])

    def drop():
        require_items(1, "DROP")
        stack.pop()

    def swap():
        require_items(2, "SWAP")
        stack[-1], stack[-2] = stack[-2], stack[-1]

    def over():
        require_items(2, "OVER")
        stack.append(stack[-2])

    builtins = {
        "+": add,
        "-": subtract,
        "*": multiply,
        "/": divide,
        "DUP": duplicate,
        "DROP": drop,
        "SWAP": swap,
        "OVER": over,
    }

    def execute(word):
        normalized = word.upper()
        if normalized in definitions:
            for token in definitions[normalized]:
                execute(token)
        elif normalized in builtins:
            builtins[normalized]()
        elif _is_number(word):
            stack.append(int(word))
        else:
            raise ValueError("undefined operation")

    tokens = []
    for line in input_data:
        tokens.extend(line.split())

    index = 0
    while index < len(tokens):
        if tokens[index] == ":":
            index += 1
            if index >= len(tokens):
                raise ValueError("incomplete word definition")
            name = tokens[index].upper()
            index += 1
            body = []
            while index < len(tokens) and tokens[index] != ";":
                body.append(tokens[index])
                index += 1
            if index >= len(tokens):
                raise ValueError("incomplete word definition")
            if name in builtins or _is_number(name):
                raise ValueError("invalid word definition")
            definitions[name] = body
            index += 1
        else:
            execute(tokens[index])
            index += 1

    return stack


def _is_number(token):
    return token.isdigit()
