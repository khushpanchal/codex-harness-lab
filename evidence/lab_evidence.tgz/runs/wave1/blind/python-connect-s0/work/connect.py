class ConnectGame:
    def __init__(self, board):
        if isinstance(board, str):
            board = board.splitlines()

        self.raw_board = [row.lstrip() for row in board]
        raw_rows = len(self.raw_board)

        self.board = [
            row.replace(" ", "") if self._is_indented(index, raw_rows) else row
            for index, row in enumerate(self.raw_board)
        ]
        self.rows = len(self.board)
        self.columns = max((len(row) for row in self.board), default=0)

    def _is_indented(self, row_index, row_count):
        row = self.raw_board[row_index]
        next_row = self.raw_board[row_index + 1] if row_index + 1 < row_count else None
        return next_row is not None and next_row.startswith(" ")

    def get_winner(self):
        if self._connects("O", top_to_bottom=True):
            return "O"
        if self._connects("X", top_to_bottom=False):
            return "X"
        return ""

    def _connects(self, player, top_to_bottom):
        """Return whether a player links their two opposite board edges."""
        neighbors = ((-1, 0), (-1, 1), (0, -1), (0, 1), (1, 0), (1, -1))
        stack = []
        for row, cells in enumerate(self.board):
            for column, cell in enumerate(cells):
                on_start_edge = (
                    (top_to_bottom and row == 0)
                    or (not top_to_bottom and column == 0)
                )
                if cell == player and on_start_edge:
                    stack.append((row, column))

        reached = set(stack)
        target_edge = self.rows - 1 if top_to_bottom else self.columns - 1

        while stack:
            row, column = stack.pop()
            if (top_to_bottom and row == target_edge) or (
                not top_to_bottom and column == target_edge
            ):
                return True

            for row_delta, column_delta in neighbors:
                next_row = row + row_delta
                next_column = column + column_delta
                if (
                    0 <= next_row < self.rows
                    and 0 <= next_column < len(self.board[next_row])
                    and self.board[next_row][next_column] == player
                    and (next_row, next_column) not in reached
                ):
                    reached.add((next_row, next_column))
                    stack.append((next_row, next_column))

        return False
