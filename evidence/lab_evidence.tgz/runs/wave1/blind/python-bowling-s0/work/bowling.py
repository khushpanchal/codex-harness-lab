class BowlingGame:
    def __init__(self):
        self._rolls = []

    def roll(self, pins):
        if not isinstance(pins, int) or isinstance(pins, bool):
            raise ValueError("pins must be an integer")
        if pins < 0 or pins > 10:
            raise ValueError("invalid number of pins")

        rolls = self._rolls
        frame_start = 0

        # Walk the first nine frames. A strike consumes one ball; any other
        # first ball is completed by a second ball in the same frame.
        for _ in range(9):
            if frame_start >= len(rolls):
                break
            frame_start += 1 if rolls[frame_start] == 10 else 2

        if frame_start < len(rolls):
            if frame_start + 1 < len(rolls):
                # More than two balls in a non-strike frame.
                raise IndexError("cannot roll after a completed frame")
            first_roll = rolls[frame_start]
            if first_roll + pins > 10:
                raise ValueError("invalid frame: more than ten pins knocked down")
        elif frame_start == len(rolls) and self._is_tenth_frame_start(frame_start):
            self._validate_tenth_roll(rolls[frame_start:], pins)
        else:
            raise IndexError("cannot roll after the game is complete")

        rolls.append(pins)

    def _is_tenth_frame_start(self, index):
        # Frame ten begins after nine complete frames, which this flat roll
        # list has already reached when index is the first unused roll.
        return index <= len(self._rolls)

    def _validate_tenth_roll(self, tenth_rolls, pins):
        if len(tenth_rolls) == 0:
            return
        if len(tenth_rolls) >= 3:
            raise IndexError("cannot roll after the tenth frame is complete")

        first = tenth_rolls[0]
        if len(tenth_rolls) == 1:
            if first != 10 and first + pins > 10:
                raise ValueError("invalid tenth frame: more than ten pins knocked down")
            return

        second = tenth_rolls[1]
        if first == 10:
            # A fresh rack follows the strike, unless that fill ball itself
            # struck, in which case the third ball also gets a fresh rack.
            if second != 10 and second + pins > 10:
                raise ValueError("invalid fill balls")
        elif first + second == 10:
            return
        else:
            raise IndexError("cannot throw bonus with an open tenth frame")

    def score(self):
        rolls = self._rolls
        total = 0
        frame_start = 0

        for _ in range(10):
            if frame_start >= len(rolls):
                raise ValueError("game is incomplete")

            first = rolls[frame_start]
            if first == 10:
                if frame_start + 2 >= len(rolls):
                    raise ValueError("game is incomplete")
                total += 10 + rolls[frame_start + 1] + rolls[frame_start + 2]
                frame_start += 1
                continue

            if frame_start + 1 >= len(rolls):
                raise ValueError("game is incomplete")
            second = rolls[frame_start + 1]
            if first + second > 10:
                raise ValueError("invalid frame: more than ten pins knocked down")

            if first + second == 10:
                if frame_start + 2 >= len(rolls):
                    raise ValueError("game is incomplete")
                total += 10 + rolls[frame_start + 2]
            else:
                total += first + second
            frame_start += 2

        return total
