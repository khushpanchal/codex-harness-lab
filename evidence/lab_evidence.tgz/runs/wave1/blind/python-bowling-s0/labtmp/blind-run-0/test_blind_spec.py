import unittest
from bowling import BowlingGame


class BowlingGameTest(unittest.TestCase):
    def roll_game(self, rolls):
        game = BowlingGame()
        for pins in rolls:
            game.roll(pins)
        return game

    # --- basic games -------------------------------------------------
    def test_should_be_able_to_score_a_game_with_no_strikes_or_spares(self):
        rolls = [3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6]
        game = self.roll_game(rolls)
        self.assertEqual(game.score(), 90)

    def test_open_frame_plus_last_frame(self):
        rolls = [0, 0] * 18 + [0, 0]
        game = self.roll_game(rolls)
        self.assertEqual(game.score(), 0)

    def test_all_ones(self):
        game = self.roll_game([1] * 20)
        self.assertEqual(game.score(), 20)

    # --- spares ------------------------------------------------------
    def test_a_spare_followed_by_zeros(self):
        game = self.roll_game([6, 4] + [0] * 18)
        self.assertEqual(game.score(), 10)

    def test_spare_framed_as_ten(self):
        game = self.roll_game([5, 5, 3, 7, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
        self.assertEqual(game.score(), 10 + 10 + 4)

    def test_a_spare_in_the_first_frame(self):
        game = self.roll_game([5, 5, 4, 0] + [0] * 16)
        self.assertEqual(game.score(), 18)

    # --- strikes -----------------------------------------------------
    def test_a_strike_followed_by_zeros(self):
        game = self.roll_game([10] + [0] * 19)
        self.assertEqual(game.score(), 10)

    def test_a_strike_in_the_first_frame(self):
        game = self.roll_game([10, 3, 6] + [0] * 16)
        self.assertEqual(game.score(), 28)

    def test_consecutive_strikes(self):
        game = self.roll_game([10, 10, 10, 0, 0] + [0] * 14)
        self.assertEqual(game.score(), 60)

    def test_a_strike_in_the_final_frame(self):
        game = self.roll_game([0] * 18 + [10, 7, 1])
        self.assertEqual(game.score(), 18)

    # --- tenth frame -------------------------------------------------
    def test_throws_cannot_exceed_ten_pins(self):
        game = BowlingGame()
        with self.assertRaises(ValueError):
            game.roll(11)

    def test_tenth_frame_spare_with_fill_ball(self):
        game = self.roll_game([0] * 18 + [5, 5, 10])
        self.assertEqual(game.score(), 20)

    def test_tenth_frame_strike_with_two_fill_balls(self):
        game = self.roll_game([0] * 18 + [10, 5, 5])
        self.assertEqual(game.score(), 20)

    def test_tenth_frame_two_strikes_with_fill_ball(self):
        game = self.roll_game([0] * 18 + [10, 10, 5])
        self.assertEqual(game.score(), 35)

    def test_three_strikes_in_tenth_frame(self):
        game = self.roll_game([0] * 18 + [10, 10, 10])
        self.assertEqual(game.score(), 30)

    def test_tenth_frame_strike_and_spare(self):
        game = self.roll_game([0] * 18 + [10, 1, 9])
        self.assertEqual(game.score(), 20)

    # --- perfect game -------------------------------------------------
    def test_perfect_game(self):
        game = self.roll_game([10] * 12)
        self.assertEqual(game.score(), 300)

    # --- errors -------------------------------------------------------
    def test_cannot_roll_if_game_already_has_ten_frames(self):
        game = self.roll_game([0] * 20)
        with self.assertRaises(Exception):
            game.roll(0)

    def test_bonus_roll_after_a_strike_in_the_last_frame_cannot_score_more_than_two_extra_rolls(self):
        game = self.roll_game([10] * 11 + [0])
        with self.assertRaises(Exception):
            game.roll(0)

    def test_bonus_roll_after_a_strike_in_the_last_frame_cannot_score_more_than_10_pins(self):
        game = self.roll_game([0] * 18 + [10, 5])
        with self.assertRaises(ValueError):
            game.roll(11)

    def test_second_bonus_roll_after_a_strike_cannot_score_more_than_10_pins(self):
        game = self.roll_game([0] * 18 + [10, 10])
        with self.assertRaises(ValueError):
            game.roll(11)

    def test_bonus_after_strike_in_last_frame_with_two_rolls_summing_over_10(self):
        game = self.roll_game([0] * 18 + [10, 5])
        with self.assertRaises(ValueError):
            game.roll(6)

    def test_bonus_after_spare_in_last_frame_cannot_score_more_than_10_pins(self):
        game = self.roll_game([0] * 18 + [5, 5])
        with self.assertRaises(ValueError):
            game.roll(11)

    def test_bonus_roll_after_a_spare_in_the_last_frame_cannot_score_more_than_one_extra_roll(self):
        game = self.roll_game([0] * 18 + [9, 1, 7])
        with self.assertRaises(Exception):
            game.roll(2)

    def test_an_incomplete_game_cannot_be_scored(self):
        game = self.roll_game([0, 0] * 9)
        with self.assertRaises(Exception):
            game.score()

    def test_incomplete_strike_game_cannot_be_scored(self):
        game = self.roll_game([10, 10])
        with self.assertRaises(Exception):
            game.score()

    def test_bonus_cannot_be_thrown_with_an_open_tenth_frame(self):
        game = self.roll_game([0] * 18 + [3, 3])
        with self.assertRaises(IndexError):
            game.roll(10)

    def test_invalid_fill_ball_after_open_tenth_frame(self):
        game = self.roll_game([0] * 18 + [0, 0])
        with self.assertRaises(Exception):
            game.roll(10)

    def test_roll_negative_pins(self):
        game = BowlingGame()
        with self.assertRaises(ValueError):
            game.roll(-1)

    def test_roll_after_game_over(self):
        game = self.roll_game([10] * 12)
        with self.assertRaises(Exception):
            game.roll(0)

    def test_score_too_early_with_spare_in_progress(self):
        game = self.roll_game([5, 5])
        with self.assertRaises(Exception):
            game.score()

    def test_pins_in_two_rolls_of_frame_cannot_exceed_ten(self):
        game = BowlingGame()
        game.roll(6)
        with self.assertRaises(ValueError):
            game.roll(5)


if __name__ == "__main__":
    unittest.main()
