def can_chain(dominoes):
    """Return True if the stones can be arranged into a closed domino chain."""
    stones = [tuple(stone) for stone in dominoes]
    if not stones:
        return True

    used = [False] * len(stones)

    def extend(chain):
        if len(chain) == len(stones):
            return chain[-1][1] == chain[0][0]

        tail = chain[-1][1]
        for index, (left, right) in enumerate(stones):
            if used[index]:
                continue
            for orientation in ((left, right), (right, left)):
                if orientation[0] == tail:
                    used[index] = True
                    chain.append(orientation)
                    if extend(chain):
                        return True
                    chain.pop()
                    used[index] = False
        return False

    for index, (left, right) in enumerate(stones):
        # For a closed loop, trying one orientation as the starting stone is
        # enough: reversing every stone in a valid chain is also valid.
        used[index] = True
        if extend([(left, right)]):
            return True
        used[index] = False
    return False
