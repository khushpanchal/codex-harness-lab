class School:
    def __init__(self):
        self.students = {}
        self.added = True

    def add_student(self, name, grade):
        if name in self.students:
            self.added = False
        else:
            self.added = True
            self.students[name] = grade

    def roster(self):
        names_by_grade = {}
        for name, grade in self.students.items():
            names_by_grade.setdefault(grade, []).append(name)

        return [
            name
            for _, names in sorted(names_by_grade.items())
            for name in sorted(names)
        ]

    def grade(self, grade_number):
        return sorted(
            name for name, grade in self.students.items() if grade == grade_number
        )
