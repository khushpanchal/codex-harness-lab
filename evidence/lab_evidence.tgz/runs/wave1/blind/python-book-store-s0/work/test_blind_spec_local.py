import unittest
from book_store import total

class T(unittest.TestCase):
    def test_empty_basket(self): self.assertEqual(total([]), 0)
    def test_single_book(self): self.assertEqual(total([1]), 8)
    def test_two_same_books_no_discount(self): self.assertEqual(total([1, 1]), 16)
    def test_two_different_books(self): self.assertEqual(total([1, 2]), 8 * 2 * 0.95)
    def test_three_different_books(self): self.assertEqual(total([1, 2, 3]), 8 * 3 * 0.90)
    def test_four_different_books(self): self.assertEqual(total([1, 2, 3, 4]), 8 * 4 * 0.80)
    def test_five_different_books(self): self.assertEqual(total([1, 2, 3, 4, 5]), 8 * 5 * 0.75)
    def test_two_groups_of_four_is_better_than_five_plus_three(self): self.assertEqual(total([1, 1, 2, 2, 3, 3, 4, 5]), 2 * (8 * 4 * 0.80))
    def test_two_of_each_plus_one_extra(self): self.assertEqual(total([1, 1, 2, 2, 3, 3, 4, 4, 5, 5]), 2 * (8 * 5 * 0.75))
    def test_grouping_only_discounted_books(self): self.assertEqual(total([1, 1, 2, 2, 3, 3, 4, 5]), 2 * (8 * 4 * 0.80))
    def test_mixed_with_untouched_book(self): self.assertEqual(total([1, 2, 3, 4, 1]), 8 * 4 * 0.80 + 8)
    def test_multiple_copies_same_only(self): self.assertEqual(total([1, 1, 1, 1]), 4 * 8)
    def test_large_basket(self): self.assertEqual(total([1] * 10 + [2, 3, 4, 5]), 10 * 8 + 4 * 8 * 0.80)
    def test_two_copies_of_two_books(self): self.assertEqual(total([1, 1, 2, 2]), 2 * 8 * 2 * 0.95)
    def test_three_books_two_same(self): self.assertEqual(total([1, 1, 2]), 8 * 2 * 0.95 + 8)
    def test_all_five_plus_one_duplicate(self): self.assertEqual(total([1, 2, 3, 4, 5, 1]), 8 * 5 * 0.75 + 8)

if __name__ == "__main__":
    unittest.main()
