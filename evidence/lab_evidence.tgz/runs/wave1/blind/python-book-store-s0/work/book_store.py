BOOK_PRICE = 8.0

DISCOUNTS = {
    1: 0,
    2: 5,
    3: 10,
    4: 20,
    5: 25,
}


def total(basket):
    counts = sorted((basket.count(book) for book in set(basket)), reverse=True)
    return _cheapest(tuple(counts))


def _cheapest(counts, cache={}):
    if not any(counts):
        return 0
    if counts in cache:
        return cache[counts]

    distinct = sum(count > 0 for count in counts)
    best = min(
        _cheapest(_remove_group(counts, group_size), cache)
        + group_size * BOOK_PRICE * (100 - DISCOUNTS[group_size]) / 100
        for group_size in range(1, distinct + 1)
    )

    cache[counts] = best
    return best


def _remove_group(counts, group_size):
    remaining = list(counts)
    for index in range(group_size):
        remaining[index] -= 1
    return tuple(sorted(remaining, reverse=True))
