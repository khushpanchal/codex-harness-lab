def encode(plain_text, a, b):
    if a % 2 == 0 or a % 13 == 0:
        raise ValueError("a and m must be coprime.")

    letters = "".join(
        char for char in plain_text.lower() if char.isalnum() and char.isascii()
    )
    return " ".join(
        "".join(
            chr(ord("a") + (a * (ord(char) - ord("a")) + b) % 26)
            if char.isalpha()
            else char
            for char in letters
        )[start : start + 5]
        for start in range(0, len(letters), 5)
    )


def decode(ciphered_text, a, b):
    if a % 2 == 0 or a % 13 == 0:
        raise ValueError("a and m must be coprime.")

    a_inverse = pow(a, -1, 26)
    return "".join(
        chr(ord("a") + (a_inverse * (ord(char) - ord("a") - b)) % 26)
        if char.isalpha()
        else char
        for char in ciphered_text.lower()
        if char.isalnum() and char.isascii()
    )
