def recite(start, take=1):
    if start < 1 or start > 10:
        raise ValueError("start must be between 1 and 10")
    if take < 1 or take > 10:
        raise ValueError("take must be between 1 and 10")

    numbers = [
        "no", "one", "two", "three", "four", "five",
        "six", "seven", "eight", "nine", "ten",
    ]

    verses = []
    for bottles in range(start, start - take, -1):
        remaining = bottles - 1
        noun = "bottle" if bottles == 1 else "bottles"
        remaining_noun = "bottle" if remaining == 1 else "bottles"
        verses.extend([
            f"{numbers[bottles].capitalize()} green {noun} hanging on the wall,",
            f"{numbers[bottles].capitalize()} green {noun} hanging on the wall,",
            "And if one green bottle should accidentally fall,",
            f"There'll be {numbers[remaining]} green {remaining_noun} hanging on the wall.",
        ])

    return verses
