"""Tests for bottle_song.recite — the "Ten Green Bottles" song reciter.

Expected outputs are written out explicitly from the lyrics given in the
exercise description (rather than generated programmatically) so the tests
do not re-implement the solution's logic.
"""

import unittest

from bottle_song import recite


# Every verse of the song, exactly as printed in the exercise description.
VERSES = {
    10: [
        "Ten green bottles hanging on the wall,",
        "Ten green bottles hanging on the wall,",
        "And if one green bottle should accidentally fall,",
        "There'll be nine green bottles hanging on the wall.",
    ],
    9: [
        "Nine green bottles hanging on the wall,",
        "Nine green bottles hanging on the wall,",
        "And if one green bottle should accidentally fall,",
        "There'll be eight green bottles hanging on the wall.",
    ],
    8: [
        "Eight green bottles hanging on the wall,",
        "Eight green bottles hanging on the wall,",
        "And if one green bottle should accidentally fall,",
        "There'll be seven green bottles hanging on the wall.",
    ],
    7: [
        "Seven green bottles hanging on the wall,",
        "Seven green bottles hanging on the wall,",
        "And if one green bottle should accidentally fall,",
        "There'll be six green bottles hanging on the wall.",
    ],
    6: [
        "Six green bottles hanging on the wall,",
        "Six green bottles hanging on the wall,",
        "And if one green bottle should accidentally fall,",
        "There'll be five green bottles hanging on the wall.",
    ],
    5: [
        "Five green bottles hanging on the wall,",
        "Five green bottles hanging on the wall,",
        "And if one green bottle should accidentally fall,",
        "There'll be four green bottles hanging on the wall.",
    ],
    4: [
        "Four green bottles hanging on the wall,",
        "Four green bottles hanging on the wall,",
        "And if one green bottle should accidentally fall,",
        "There'll be three green bottles hanging on the wall.",
    ],
    3: [
        "Three green bottles hanging on the wall,",
        "Three green bottles hanging on the wall,",
        "And if one green bottle should accidentally fall,",
        "There'll be two green bottles hanging on the wall.",
    ],
    2: [
        "Two green bottles hanging on the wall,",
        "Two green bottles hanging on the wall,",
        "And if one green bottle should accidentally fall,",
        "There'll be one green bottle hanging on the wall.",
    ],
    1: [
        "One green bottle hanging on the wall,",
        "One green bottle hanging on the wall,",
        "And if one green bottle should accidentally fall,",
        "There'll be no green bottles hanging on the wall.",
    ],
}


def verses_from(start, take):
    """Expected lines for a recitation of `take` verses beginning at `start`."""
    expected = []
    for count in range(start, start - take, -1):
        expected.extend(VERSES[count])
    return expected


class BottleSongSingleVerseTests(unittest.TestCase):
    def test_first_verse(self):
        self.assertEqual(recite(start=10), VERSES[10])

    def test_each_single_verse(self):
        for start in range(1, 11):
            with self.subTest(start=start):
                self.assertEqual(recite(start=start), VERSES[start])

    def test_final_verse(self):
        self.assertEqual(recite(start=1), VERSES[1])

    def test_final_verse_ends_with_no_green_bottles(self):
        self.assertEqual(
            recite(start=1)[-1],
            "There'll be no green bottles hanging on the wall.",
        )

    def test_penultimate_verse_ends_with_one_green_bottle(self):
        self.assertEqual(
            recite(start=2)[-1],
            "There'll be one green bottle hanging on the wall.",
        )

    def test_each_verse_has_four_lines(self):
        for start in range(1, 11):
            with self.subTest(start=start):
                self.assertEqual(len(recite(start=start)), 4)

    def test_verse_punctuation(self):
        # First three lines end with a comma, the last with a period.
        verse = recite(start=10)
        self.assertTrue(verse[0].endswith(","))
        self.assertTrue(verse[1].endswith(","))
        self.assertTrue(verse[2].endswith(","))
        self.assertTrue(verse[3].endswith("."))


class BottleSongTakeParameterTests(unittest.TestCase):
    def test_take_defaults_to_one(self):
        self.assertEqual(recite(start=7), recite(start=7, take=1))

    def test_first_two_verses(self):
        self.assertEqual(recite(start=10, take=2), verses_from(10, 2))

    def test_two_verses_reaching_the_final_verse(self):
        self.assertEqual(recite(start=2, take=2), verses_from(2, 2))

    def test_three_verses_from_the_middle(self):
        self.assertEqual(recite(start=6, take=3), verses_from(6, 3))

    def test_last_three_verses(self):
        self.assertEqual(recite(start=3, take=3), verses_from(3, 3))

    def test_all_verses(self):
        result = recite(start=10, take=10)
        self.assertEqual(result, verses_from(10, 10))
        self.assertEqual(len(result), 40)

    def test_every_valid_start_and_take_combination(self):
        for start in range(1, 11):
            for take in range(1, start + 1):
                with self.subTest(start=start, take=take):
                    self.assertEqual(
                        recite(start=start, take=take),
                        verses_from(start, take),
                    )

    def test_result_length_is_four_lines_per_verse(self):
        for start, take in [(10, 1), (10, 2), (5, 3), (3, 3), (1, 1)]:
            with self.subTest(start=start, take=take):
                self.assertEqual(len(recite(start=start, take=take)), 4 * take)


if __name__ == "__main__":
    unittest.main()
