
class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        self.board = board
        self.width = len(board[0]) if board else 0
        self.height = len(board)

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not (0 <= x < self.width and 0 <= y < self.height):
            raise ValueError("Invalid coordinate")

        if self.board[y][x] != " ":
            return "", set()

        owners = set()
        visited = set()
        to_visit = [(x, y)]

        while to_visit:
            point = to_visit.pop()
            if point in visited:
                continue
            visited.add(point)
            px, py = point

            for nx, ny in ((px - 1, py), (px + 1, py), (px, py - 1), (px, py + 1)):
                if not (0 <= nx < self.width and 0 <= ny < self.height):
                    continue

                stone = self.board[ny][nx]
                if stone == " ":
                    if (nx, ny) not in visited:
                        to_visit.append((nx, ny))
                else:
                    owners.add(stone)

        owner = owners.pop() if len(owners) == 1 else ""
        return owner, visited

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        result = {"B": set(), "W": set(), "": set()}
        counted = set()

        for y in range(self.height):
            for x in range(self.width):
                if self.board[y][x] != " " or (x, y) in counted:
                    continue

                owner, territory = self.territory(x, y)
                result[owner].update(territory)
                counted.update(territory)

        return result
