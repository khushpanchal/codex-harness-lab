NODE, EDGE, ATTR = range(3)


class Node:
    def __init__(self, name, attrs):
        self.name = name
        self.attrs = attrs

    def __eq__(self, other):
        return self.name == other.name and self.attrs == other.attrs


class Edge:
    def __init__(self, src, dst, attrs):
        self.src = src
        self.dst = dst
        self.attrs = attrs

    def __eq__(self, other):
        return (self.src == other.src and
                self.dst == other.dst and
                self.attrs == other.attrs)


class Graph:
    def __init__(self, data=None):
        if not isinstance(data, list) or not data:
            raise TypeError("Graph data malformed")

        self.nodes = []
        self.edges = []
        self.attrs = {}

        for item in data:
            if not isinstance(item, tuple) or not item:
                raise TypeError("Graph data malformed")

            kind = item[0]
            if kind == ATTR:
                if len(item) != 3 or not isinstance(item[1], str):
                    raise TypeError("Graph data malformed")
                self._validate_attrs(item[2], "attribute")
                self.attrs[item[1]] = item[2]
            elif kind == NODE:
                if len(item) != 3 or not isinstance(item[1], str):
                    raise TypeError("Graph data malformed")
                self._validate_attrs(item[2], "NODE")
                self.nodes.append(Node(item[1], item[2]))
            elif kind == EDGE:
                if len(item) != 4 or not all(
                    isinstance(value, str) for value in item[1:3]
                ):
                    raise TypeError("Graph data malformed")
                self._validate_attrs(item[3], "EDGE")
                self.edges.append(Edge(item[1], item[2], item[3]))
            else:
                raise TypeError("Graph data malformed")

    @staticmethod
    def _validate_attrs(attrs, description):
        if not isinstance(attrs, dict):
            raise TypeError("Graph data malformed")
        for name, value in attrs.items():
            if not isinstance(name, str) or not isinstance(value, str):
                raise ValueError(f"{description} malformed")
