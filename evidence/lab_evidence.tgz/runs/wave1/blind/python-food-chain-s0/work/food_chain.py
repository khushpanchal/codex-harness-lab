ANIMALS = [
    "fly",
    "spider",
    "bird",
    "cat",
    "dog",
    "goat",
    "cow",
    "horse",
]

COMMENTS = {
    "spider": "It wriggled and jiggled and tickled inside her.",
    "bird": "How absurd to swallow a bird!",
    "cat": "Imagine that, to swallow a cat!",
    "dog": "What a hog, to swallow a dog!",
    "goat": "Just opened her throat and swallowed a goat!",
    "cow": "I don't know how she swallowed a cow!",
}

SPIDER_CATCH = "She swallowed the spider to catch the fly."
BIRD_CATCH = (
    "She swallowed the bird to catch the spider "
    "that wriggled and jiggled and tickled inside her."
)


def _verse(index):
    animal = ANIMALS[index]
    lines = [f"I know an old lady who swallowed a {animal}."]

    if animal == "horse":
        lines.append("She's dead, of course!")
        return lines

    if index == 0:
        lines.append(
            "I don't know why she swallowed the fly. Perhaps she'll die."
        )
        return lines

    lines.append(COMMENTS[animal])
    for caught_index in range(index - 1, 2, -1):
        caught = ANIMALS[caught_index]
        target = ANIMALS[caught_index - 1]
        lines.append(f"She swallowed the {caught} to catch the {target}.")
    if index >= 3:
        lines.append(BIRD_CATCH)
    if index >= 2:
        lines.append(SPIDER_CATCH)
    lines.append(
        "I don't know why she swallowed the fly. Perhaps she'll die."
    )
    return lines


def recite(start_verse, end_verse):
    if start_verse < 1 or end_verse > len(ANIMALS) or start_verse > end_verse:
        raise ValueError("verse numbers must be between 1 and 8")

    return [
        line
        for index in range(start_verse - 1, end_verse)
        for line in _verse(index)
    ]
