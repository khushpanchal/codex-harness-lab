class StackUnderflowError(Exception):
    """Exception raised when the stack does not have enough items."""

    def __init__(self, message):
        super().__init__(message)
        self.message = message


def _require(stack, count):
    if len(stack) < count:
        raise StackUnderflowError("Insufficient number of items in stack")


def _pop_two(stack):
    _require(stack, 2)
    second = stack.pop()
    first = stack.pop()
    return second, first


def _execute(tokens, stack, words):
    for raw_token in tokens:
        token = raw_token.lower()

        if token in words:
            _execute(words[token], stack, words)
        elif token.lstrip("+-").isdigit() and token not in {"+", "-"}:
            stack.append(int(token))
        elif token == "+":
            second, first = _pop_two(stack)
            stack.append(first + second)
        elif token == "-":
            second, first = _pop_two(stack)
            stack.append(first - second)
        elif token == "*":
            second, first = _pop_two(stack)
            stack.append(first * second)
        elif token == "/":
            second, first = _pop_two(stack)
            if second == 0:
                raise ZeroDivisionError("divide by zero")
            stack.append(first // second)
        elif token == "dup":
            _require(stack, 1)
            stack.append(stack[-1])
        elif token == "drop":
            _require(stack, 1)
            stack.pop()
        elif token == "swap":
            second, first = _pop_two(stack)
            stack.extend((second, first))
        elif token == "over":
            _require(stack, 2)
            stack.append(stack[-2])
        else:
            raise ValueError("undefined operation")

    return stack


def evaluate(input_data):
    sources = [input_data] if isinstance(input_data, str) else list(input_data)
    tokens = [token for source in sources for token in source.split()]

    words = {}
    definition_name = None
    definition_body = []
    executable_tokens = []

    for raw_token in tokens:
        token = raw_token.lower()

        if definition_name is None:
            if token == ":":
                definition_name = ""
            elif token == ";":
                raise ValueError("undefined operation")
            else:
                executable_tokens.append(raw_token)
            continue

        if not definition_name:
            if token == ";":
                raise ValueError("undefined operation")
            definition_name = token
        elif token == ";":
            words[definition_name] = definition_body
            definition_name = None
            definition_body = []
        else:
            definition_body.append(raw_token)

    if definition_name is not None:
        raise ValueError("undefined operation")

    return _execute(executable_tokens, [], words)
