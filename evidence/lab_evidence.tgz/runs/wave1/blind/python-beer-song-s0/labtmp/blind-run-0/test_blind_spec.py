"""Tests for the "99 Bottles of Beer on the Wall" song (beer_song.recite).

All lyric text is taken verbatim from the task description.

Note: the description does not pin down trailing whitespace/newlines at the
very end of the returned text, so the suite deliberately ignores trailing
whitespace (via ``strip()``).  The verse text itself, the exact line breaks
inside a verse, and the blank line separating consecutive verses are
asserted exactly.
"""

import unittest

from beer_song import recite

# --------------------------------------------------------------------------
# Expected verses, copied verbatim from the lyrics in the task description.
# --------------------------------------------------------------------------

VERSE_99 = (
    "99 bottles of beer on the wall, 99 bottles of beer.\n"
    "Take one down and pass it around, 98 bottles of beer on the wall."
)

VERSE_10 = (
    "10 bottles of beer on the wall, 10 bottles of beer.\n"
    "Take one down and pass it around, 9 bottles of beer on the wall."
)

VERSE_2 = (
    "2 bottles of beer on the wall, 2 bottles of beer.\n"
    "Take one down and pass it around, 1 bottle of beer on the wall."
)

VERSE_1 = (
    "1 bottle of beer on the wall, 1 bottle of beer.\n"
    "Take it down and pass it around, no more bottles of beer on the wall."
)

VERSE_0 = (
    "No more bottles of beer on the wall, no more bottles of beer.\n"
    "Go to the store and buy some more, 99 bottles of beer on the wall."
)

VERSE_98 = (
    "98 bottles of beer on the wall, 98 bottles of beer.\n"
    "Take one down and pass it around, 97 bottles of beer on the wall."
)

FIRST_TWO_VERSES = VERSE_99 + "\n\n" + VERSE_98

LAST_THREE_VERSES = VERSE_2 + "\n\n" + VERSE_1 + "\n\n" + VERSE_0


# --------------------------------------------------------------------------
# Independent reference builders (used to cover every generic verse without
# hand-writing 100 strings).
# --------------------------------------------------------------------------

def reference_verse(n):
    """Reference text for the verse that starts with ``n`` bottles."""
    if n == 0:
        return VERSE_0
    if n == 1:
        return VERSE_1
    # The bottle that remains after taking one down.  "1 bottle" is singular;
    # "no more bottles" never appears here because it only follows verse 1,
    # which is handled above.
    remaining = "1 bottle" if n == 2 else "{} bottles".format(n - 1)
    return (
        "{0} bottles of beer on the wall, {0} bottles of beer.\n"
        "Take one down and pass it around, {1} of beer on the wall."
    ).format(n, remaining)


def reference_song(start, take):
    """Reference text for ``take`` consecutive verses starting at ``start``,
    separated by a blank line."""
    return "\n\n".join(
        reference_verse(n) for n in range(start, start - take, -1)
    )


# --------------------------------------------------------------------------
# Tests
# --------------------------------------------------------------------------

class BeerSongTest(unittest.TestCase):
    def assertRecitation(self, expected, start, take=1):
        actual = recite(start, take)
        self.assertIsInstance(actual, str)
        self.assertEqual(expected, actual.strip())

    # -- basic shape -------------------------------------------------------

    def test_returns_a_string(self):
        self.assertIsInstance(recite(99), str)
        self.assertIsInstance(recite(0, 1), str)
        self.assertIsInstance(recite(99, 100), str)

    # -- single verses -----------------------------------------------------

    def test_first_verse(self):
        self.assertRecitation(VERSE_99, 99)

    def test_generic_verse_with_single_digit_successor(self):
        self.assertRecitation(VERSE_10, 10)

    def test_verse_with_2_bottles_uses_singular_for_remaining_bottle(self):
        self.assertRecitation(VERSE_2, 2)

    def test_verse_with_1_bottle(self):
        # "1 bottle" singular, "Take it down" (not "Take one down"),
        # "no more bottles" lowercase.
        self.assertRecitation(VERSE_1, 1)

    def test_verse_with_0_bottles(self):
        # "No more bottles" capitalized, "Go to the store" line,
        # back up to "99 bottles".
        self.assertRecitation(VERSE_0, 0)

    def test_take_defaults_to_one(self):
        self.assertEqual(recite(43, 1), recite(43))

    def test_explicit_take_of_one(self):
        self.assertRecitation(reference_verse(43), 43, 1)

    # -- multiple verses ---------------------------------------------------

    def test_first_two_verses(self):
        self.assertRecitation(FIRST_TWO_VERSES, 99, 2)

    def test_last_three_verses_reach_the_end_of_the_song(self):
        self.assertRecitation(LAST_THREE_VERSES, 2, 3)

    def test_middle_run_of_verses(self):
        self.assertRecitation(reference_song(10, 3), 10, 3)

    def test_keyword_arguments(self):
        actual = recite(start=99, take=2)
        self.assertEqual(FIRST_TWO_VERSES, actual.strip())

    def test_verses_are_separated_by_exactly_one_blank_line(self):
        actual = recite(99, 2).strip()
        self.assertIn("\n\n", actual)
        self.assertNotIn("\n\n\n", actual)

    # -- exhaustive coverage of the generic verses --------------------------

    def test_every_generic_verse_from_2_to_99(self):
        for n in range(2, 100):
            with self.subTest(bottles=n):
                self.assertRecitation(reference_verse(n), n)

    # -- the whole song ------------------------------------------------------

    def test_whole_song(self):
        actual = recite(99, 100)
        self.assertIsInstance(actual, str)
        actual = actual.strip()
        self.assertEqual(reference_song(99, 100), actual)
        verses = actual.split("\n\n")
        self.assertEqual(100, len(verses))
        self.assertEqual(VERSE_99, verses[0])
        self.assertEqual(VERSE_0, verses[-1])


if __name__ == "__main__":
    unittest.main()
