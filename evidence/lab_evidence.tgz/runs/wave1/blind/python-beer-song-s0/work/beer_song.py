def recite(start, take=1):
    def quantity(count):
        return "no more bottles" if count == 0 else (
            "1 bottle" if count == 1 else f"{count} bottles"
        )

    verses = []
    end = max(start - take, -1)
    for number in range(start, end, -1):
        if number == 1:
            verses.append(
                "1 bottle of beer on the wall, 1 bottle of beer."
            )
            verses.append(
                "Take it down and pass it around, "
                "no more bottles of beer on the wall."
            )
        elif number == 0:
            verses.append(
                "No more bottles of beer on the wall, no more bottles of beer."
            )
            verses.append(
                "Go to the store and buy some more, 99 bottles of beer on the wall."
            )
        else:
            verses.append(
                f"{quantity(number).capitalize()} of beer on the wall, "
                f"{quantity(number)} of beer."
            )
            verses.append(
                f"Take one down and pass it around, "
                f"{quantity(number - 1)} of beer on the wall."
            )
        if number:
            verses.append("")

    return "\n".join(verses)
