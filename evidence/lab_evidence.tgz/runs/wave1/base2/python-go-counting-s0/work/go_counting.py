
class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        self.board = board
        self.width = len(board[0]) if board else 0
        self.height = len(board)

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not (0 <= x < self.width and 0 <= y < self.height):
            raise ValueError("Invalid coordinate")
        if self.board[y][x] != " ":
            raise ValueError("Coordinate is not an empty intersection")

        owner = None
        territory = set()
        pending = [(x, y)]
        seen = set(pending)

        while pending:
            point = pending.pop()
            territory.add(point)
            column, row = point
            for neighbor in self._neighbors(column, row):
                cell = self.board[neighbor[1]][neighbor[0]]
                if cell == " ":
                    if neighbor not in seen:
                        seen.add(neighbor)
                        pending.append(neighbor)
                elif owner is None:
                    owner = cell
                elif owner != cell:
                    owner = ""

        return owner if owner is not None else "", territory

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        result = {"B": set(), "W": set(), "": set()}
        visited = set()

        for y in range(self.height):
            for x in range(self.width):
                if self.board[y][x] == " " and (x, y) not in visited:
                    owner, territory = self.territory(x, y)
                    visited.update(territory)
                    result[owner].update(territory)

        return result

    def _neighbors(self, x, y):
        return (
            candidate
            for candidate in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1))
            if 0 <= candidate[0] < self.width and 0 <= candidate[1] < self.height
        )
