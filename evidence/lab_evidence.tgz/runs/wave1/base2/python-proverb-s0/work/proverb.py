def proverb(*inputs, qualifier=None):
    if not inputs:
        return ""

    lines = [
        f"For want of a {cause} the {effect} was lost."
        for cause, effect in zip(inputs, inputs[1:])
    ]
    lines.append(f"And all for the want of a {qualifier} {inputs[0]}." if qualifier else f"And all for the want of a {inputs[0]}.")
    return "\n".join(lines)
