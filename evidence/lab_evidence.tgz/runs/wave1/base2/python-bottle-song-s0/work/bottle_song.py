NUMBERS = (
    "no", "one", "two", "three", "four", "five", "six",
    "seven", "eight", "nine", "ten",
)


def _verse(start):
    bottles = f"{NUMBERS[start]} green bottle{'s' if start != 1 else ''}"
    next_bottles = f"{NUMBERS[start - 1]} green bottle{'s' if start - 1 != 1 else ''}"
    return [
        f"{bottles.capitalize()} hanging on the wall,",
        f"{bottles.capitalize()} hanging on the wall,",
        "And if one green bottle should accidentally fall,",
        f"There'll be {next_bottles} hanging on the wall.",
    ]


def recite(start, take=1):
    verses = []
    for number in range(start, start - take, -1):
        verses.extend(_verse(number))
        verses.append("")
    return "\n".join(verses).rstrip()
