VOWELS = "aeiou"
CONSONANTS = "bcdfghjklmnpqrstvwxyz"


def _translate_word(word):
    if word.startswith(("xr", "yt")) or word[:1] in VOWELS:
        return word + "ay"

    index = word.find("qu")
    if index != -1 and all(char in CONSONANTS for char in word[:index]):
        return word[index + 2 :] + word[: index + 2] + "ay"

    if len(word) > 1 and word[0] in CONSONANTS:
        for index, char in enumerate(word[1:], start=1):
            if char == "y":
                return word[index:] + word[:index] + "ay"
            if char in VOWELS:
                return word[index:] + word[:index] + "ay"
            if char not in CONSONANTS:
                break

    return word + "ay"


def translate(text):
    return " ".join(_translate_word(word) for word in text.split())
