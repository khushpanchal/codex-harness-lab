def grep(pattern, flags, files):
    flags = set(flags)
    case_insensitive = "-i" in flags
    invert = "-v" in flags
    whole_line = "-x" in flags
    numbers = "-n" in flags
    names_only = "-l" in flags

    results = []
    matching_files = []

    if case_insensitive:
        pattern = pattern.lower()

    for filename in files:
        file_matches = False
        with open(filename, encoding="utf-8") as source:
            for line_number, line in enumerate(source, start=1):
                line = line.rstrip("\n")
                haystack = line.lower() if case_insensitive else line
                matched = haystack == pattern if whole_line else pattern in haystack
                if matched != invert:
                    file_matches = True
                    if names_only:
                        break
                    prefix = ""
                    if len(files) > 1:
                        prefix += f"{filename}:"
                    if numbers:
                        prefix += f"{line_number}:"
                    results.append(prefix + line)

        if file_matches:
            matching_files.append(filename)

    return matching_files if names_only else results
