class School:
    def __init__(self):
        self.students = {}
        self._added = False

    def add_student(self, name, grade):
        if name in self.students:
            self._added = False
        else:
            self.students[name] = grade
            self._added = True
        return self._added

    def roster(self):
        return [
            name
            for grade, names in sorted(self._names_by_grade().items())
            for name in names
        ]

    def grade(self, grade_number):
        return self._names_by_grade().get(grade_number, [])

    def added(self):
        return self._added

    def _names_by_grade(self):
        grouped = {}
        for name in self.students:
            grade = self.students[name]
            grouped.setdefault(grade, []).append(name)
        return {grade: sorted(names) for grade, names in grouped.items()}
