# Game status categories
# Change the values as you see fit
STATUS_WIN = 'win'
STATUS_LOSE = 'lose'
STATUS_ONGOING = 'ongoing'


class Hangman:
    def __init__(self, word):
        if not word:
            raise ValueError("The word must not be empty.")

        self.remaining_guesses = 9
        self.status = STATUS_ONGOING
        self.word = word
        self._guessed = set()

    def guess(self, char):
        self.get_status()
        if self.status != STATUS_ONGOING:
            raise ValueError("The game has already ended.")

        if char in self._guessed:
            return

        self._guessed.add(char)
        if char not in self.word:
            self.remaining_guesses -= 1
            if self.remaining_guesses == 0:
                self.status = STATUS_LOSE

    def get_masked_word(self):
        if self.get_status() == STATUS_LOSE:
            return self.word

        return "".join(char if char in self._guessed else "_" for char in self.word)

    def get_status(self):
        if self.status == STATUS_ONGOING and all(
            char in self._guessed for char in self.word
        ):
            self.status = STATUS_WIN

        return self.status
