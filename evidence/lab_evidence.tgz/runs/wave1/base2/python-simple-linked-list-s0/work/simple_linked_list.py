class EmptyListException(Exception):
    pass


class Node:
    def __init__(self, value):
        self._value = value
        self._next = None

    def value(self):
        return self._value

    def next(self):
        return self._next


class LinkedList:
    def __init__(self, values=None):
        self._head = None
        self._length = 0
        if values is not None:
            for value in values:
                self.push(value)
            self._reverse_in_place()

    def __iter__(self):
        node = self._head
        while node is not None:
            yield node.value()
            node = node.next()

    def __len__(self):
        return self._length

    def head(self):
        if self._head is None:
            raise EmptyListException("The list is empty.")
        return self._head

    def push(self, value):
        node = Node(value)
        node._next = self._head
        self._head = node
        self._length += 1

    def pop(self):
        node = self.head()
        self._head = node.next()
        self._length -= 1
        return node.value()

    def reversed(self):
        result = LinkedList(self)
        result._reverse_in_place()
        return result

    def _reverse_in_place(self):
        previous = None
        current = self._head
        while current is not None:
            following = current.next()
            current._next = previous
            previous = current
            current = following
        self._head = previous
