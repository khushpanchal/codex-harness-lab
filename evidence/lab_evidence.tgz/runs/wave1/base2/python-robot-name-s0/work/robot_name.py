import random
import string
import threading


_used_names = set()
_name_lock = threading.Lock()


class Robot:
    def __init__(self):
        self._name = None

    @property
    def name(self):
        if self._name is None:
            with _name_lock:
                if self._name is None:
                    self._name = self._generate_name()
        return self._name

    def reset(self):
        with _name_lock:
            if self._name is not None:
                _used_names.remove(self._name)
                self._name = None

    @staticmethod
    def _generate_name():
        # Generate randomly and retry only on collisions; no deterministic sequence.
        while True:
            name = "".join(random.choices(string.ascii_uppercase, k=2) + random.choices(string.digits, k=3))
            if name not in _used_names:
                _used_names.add(name)
                return name
