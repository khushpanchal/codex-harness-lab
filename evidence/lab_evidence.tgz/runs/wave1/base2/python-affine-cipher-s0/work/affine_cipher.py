from math import gcd


def encode(plain_text, a, b):
    _validate_key(a)
    normalized = [ch for ch in plain_text.lower() if ch.isalnum() and ch.isascii()]
    encrypted = [
        chr(97 + (a * _ord_value(ch) + b) % 26) if ch.isalpha() else ch
        for ch in normalized
    ]
    return _group(encrypted)


def decode(ciphered_text, a, b):
    _validate_key(a)
    mmi = _modular_inverse(a)
    normalized = [ch for ch in ciphered_text.lower() if ch.isalnum() and ch.isascii()]
    return "".join(
        chr(97 + (mmi * (_ord_value(ch) - b)) % 26) for ch in normalized
    )


def _group(chars):
    return " ".join(
        "".join(chars[start : start + 5]) for start in range(0, len(chars), 5)
    )


def _ord_value(ch):
    return ord(ch) - 97 if ch.isalpha() else ord(ch) - ord("0")


def _validate_key(a):
    if gcd(a, 26) != 1:
        raise ValueError("a and m must be coprime.")


def _modular_inverse(a):
    for candidate in range(26):
        if (a * candidate) % 26 == 1:
            return candidate
    raise ValueError("a and m must be coprime.")
