def append(list1, list2):
    result = []
    for item in list1:
        result = result + [item]
    for item in list2:
        result = result + [item]
    return result


def concat(lists):
    result = []
    for items in lists:
        for item in items:
            result = result + [item]
    return result


def filter(function, list):
    result = []
    for item in list:
        if function(item):
            result = result + [item]
    return result


def length(list):
    count = 0
    for _ in list:
        count = count + 1
    return count


def map(function, list):
    result = []
    for item in list:
        result = result + [function(item)]
    return result


def foldl(function, list, initial):
    accumulator = initial
    for item in list:
        accumulator = function(accumulator, item)
    return accumulator


def foldr(function, list, initial):
    accumulator = initial
    reverse_index = length(list)
    while reverse_index > 0:
        reverse_index = reverse_index - 1
        item = list[reverse_index]
        accumulator = function(accumulator, item)
    return accumulator


def reverse(list):
    result = []
    for item in list:
        result = [item] + result
    return result
