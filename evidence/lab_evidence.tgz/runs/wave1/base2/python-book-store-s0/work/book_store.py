def total(basket):
    counts = {}
    for book in basket:
        if not 1 <= book <= 5:
            raise ValueError(f"unsupported book number: {book}")
        counts[book] = counts.get(book, 0) + 1

    discounts = {
        1: 0,
        2: 5,
        3: 10,
        4: 20,
        5: 25,
    }

    def price(counts, cache):
        if not counts:
            return 0
        if counts in cache:
            return cache[counts]

        best = None
        for size in range(1, min(len(counts), 5) + 1):
            remaining = [count for count in counts]
            # Taking one copy from each of the largest counts is sufficient:
            # title identities do not affect group pricing, only totals do.
            for index in range(size):
                remaining[index] -= 1

            cost = size * 800
            cost -= cost * discounts[size] // 100
            total_cost = cost + price(
                tuple(sorted(c for c in remaining if c)), cache
            )
            if best is None or total_cost < best:
                best = total_cost

        cache[counts] = best
        return best

    quantities = tuple(sorted(counts.values(), reverse=True))
    return price(quantities, {}) / 100
