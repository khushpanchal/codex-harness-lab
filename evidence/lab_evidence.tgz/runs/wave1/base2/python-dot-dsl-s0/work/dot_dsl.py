NODE, EDGE, ATTR = range(3)


class Node:
    def __init__(self, name, attrs):
        self.name = name
        self.attrs = attrs

    def __eq__(self, other):
        return self.name == other.name and self.attrs == other.attrs


class Edge:
    def __init__(self, src, dst, attrs):
        self.src = src
        self.dst = dst
        self.attrs = attrs

    def __eq__(self, other):
        return (self.src == other.src and
                self.dst == other.dst and
                self.attrs == other.attrs)


class Graph:
    def __init__(self, data=None):
        self.nodes = []
        self.attrs = {}
        self.edges = []

        if data is None:
            return

        if data is None or not isinstance(data, list) or not data:
            raise TypeError("Graph data malformed")

        for item in data:
            if not isinstance(item, tuple) or not item:
                raise TypeError("Graph data malformed")

            kind, values = item[0], item[1:]
            if kind == NODE:
                self.nodes.append(self._make_node(values))
            elif kind == EDGE:
                self.edges.append(self._make_edge(values))
            elif kind == ATTR:
                self.attrs.update(self._make_attrs(values))
            else:
                raise TypeError("Graph data malformed")

    @staticmethod
    def _make_node(values):
        if len(values) != 2:
            raise ValueError("NODE malformed")
        name, attrs = values
        if isinstance(name, (Node, Edge)) or not isinstance(attrs, dict):
            raise ValueError("NODE malformed")
        return Node(name, attrs)

    @staticmethod
    def _make_edge(values):
        if len(values) != 3:
            raise ValueError("EDGE malformed")
        src, dst, attrs = values
        if (isinstance(src, (Edge, Node)) or
                isinstance(dst, (Edge, Node)) or
                not isinstance(attrs, dict)):
            raise ValueError("EDGE malformed")
        return Edge(src, dst, attrs)

    @staticmethod
    def _make_attrs(values):
        if len(values) != 1 or not isinstance(values[0], dict):
            raise ValueError("ATTRIBUTE malformed")
        return values[0]
