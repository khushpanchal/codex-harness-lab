import json
from decimal import Decimal


class RestAPI:
    def __init__(self, database=None):
        self.users = {
            user["name"]: dict(user) for user in (database or {}).get("users", [])
        }

    @staticmethod
    def _payload(payload):
        if payload in (None, ""):
            return {}
        return json.loads(payload) if isinstance(payload, str) else payload

    @staticmethod
    def _new_user(name):
        return {"name": name, "owes": {}, "owed_by": {}, "balance": 0.0}

    @staticmethod
    def _set(user, category, other, amount):
        mapping = user[category]
        if amount:
            mapping[other] = float(amount)
        else:
            mapping.pop(other, None)

    def _summary(self, names):
        return {
            "users": [
                self._user_response(self.users[name]) for name in sorted(names)
            ]
        }

    def _user_response(self, user):
        owed_by = sum((Decimal(str(amount)) for amount in user["owed_by"].values()), Decimal("0"))
        owes = sum((Decimal(str(amount)) for amount in user["owes"].values()), Decimal("0"))
        return {
            "name": user["name"],
            "owes": dict(user["owes"]),
            "owed_by": dict(user["owed_by"]),
            "balance": float(owed_by - owes),
        }

    def get(self, url, payload=None):
        if url != "/users":
            return None
        payload = self._payload(payload)
        names = payload.get("users")
        if names is None:
            names = self.users.keys()
        return self._summary(names)

    def post(self, url, payload=None):
        payload = self._payload(payload)
        if url == "/add":
            name = payload["user"]
            self.users[name] = self._new_user(name)
            return self._user_response(self.users[name])

        if url == "/iou":
            lender = payload["lender"]
            borrower = payload["borrower"]
            amount = Decimal(str(payload["amount"]))
            lender_user = self.users[lender]
            borrower_user = self.users[borrower]

            # If the borrower already owes the lender, settle that first so a
            # pair has only one active debt at a time.
            opposite = Decimal(str(borrower_user["owes"].get(lender, 0)))
            reduced = min(opposite, amount)
            if reduced:
                self._set(borrower_user, "owes", lender, opposite - reduced)
                lender_by = Decimal(str(lender_user["owed_by"].get(borrower, 0)))
                self._set(lender_user, "owed_by", borrower, lender_by - reduced)
                amount -= reduced

            if amount:
                lender_by = Decimal(str(lender_user["owed_by"].get(borrower, 0)))
                borrower_owes = Decimal(str(borrower_user["owes"].get(lender, 0)))
                self._set(lender_user, "owed_by", borrower, lender_by + amount)
                self._set(borrower_user, "owes", lender, borrower_owes + amount)

            return self._summary([lender, borrower])

        return None
