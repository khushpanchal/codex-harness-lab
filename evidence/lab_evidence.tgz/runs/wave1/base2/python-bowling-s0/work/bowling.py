class BowlingGame:
    def __init__(self):
        self.rolls = []
        self.frame = 1
        self.ball = 1
        self.standing = 10
        self.tenth_start = None

    def roll(self, pins):
        if not isinstance(pins, int) or isinstance(pins, bool):
            raise ValueError("invalid roll")
        if pins < 0:
            raise ValueError("negative roll is invalid")
        if pins > 10:
            raise ValueError("cannot roll more than 10 pins")
        if self._is_complete():
            raise ValueError("cannot roll after the game is over")
        if pins > self.standing:
            raise ValueError("pins knocked down exceed those standing")

        if self.frame < 10:
            if pins == 10 or self.ball == 2:
                pass
            else:
                self.ball = 2
                self.standing -= pins
            self.rolls.append(pins)
            if self.frame < 10:
                self._next_frame()
            return

        self._roll_tenth(pins)

    def score(self):
        if not self._is_complete():
            raise IndexError("cannot score an incomplete game")

        total = 0
        roll_index = 0
        for _ in range(9):
            if self.rolls[roll_index] == 10:
                total += 10 + self.rolls[roll_index + 1] + self.rolls[roll_index + 2]
                roll_index += 1
            else:
                total += self.rolls[roll_index] + self.rolls[roll_index + 1]
                roll_index += 2

        return total + sum(self.rolls[roll_index:])

    def _roll_tenth(self, pins):
        tenth_rolls = self.rolls[self.tenth_start:]
        first_roll = tenth_rolls[0] if tenth_rolls else None

        if len(tenth_rolls) == 2 and first_roll != 10 and sum(tenth_rolls) != 10:
            raise IndexError("cannot throw bonus with an open tenth frame")

        self.rolls.append(pins)
        tenth_rolls.append(pins)
        if len(tenth_rolls) == 1 and pins < 10:
            self.ball = 2
            self.standing -= pins

        if len(tenth_rolls) == 2:
            if first_roll == 10 or first_roll + pins == 10:
                self.ball = 3
                self.standing = 10
            else:
                self._complete_game()
        elif len(tenth_rolls) == 3:
            self._complete_game()

    def _next_frame(self):
        self.frame += 1
        self.ball = 1
        self.standing = 10
        if self.frame == 10:
            self.tenth_start = len(self.rolls)

    def _complete_game(self):
        self.frame = 11
        self.ball = 1
        self.standing = 10

    def _is_complete(self):
        if self.frame < 10:
            return False

        tenth_rolls = self.rolls[self.tenth_start:]
        if not tenth_rolls:
            return False
        if tenth_rolls[0] == 10:
            return len(tenth_rolls) == 3
        if len(tenth_rolls) < 2:
            return False
        return sum(tenth_rolls[:2]) < 10 or len(tenth_rolls) == 3
