SECONDS = [
    "I don't know why she swallowed the fly. Perhaps she'll die.",
    "It wriggled and jiggled and tickled inside her.",
    "How absurd to swallow a bird!",
    "Imagine that, to swallow a cat!",
    "What a hog, to swallow a dog!",
    "Just opened her throat and swallowed a goat!",
    "I don't know how she swallowed a cow!",
]

ANIMALS = ["fly", "spider", "bird", "cat", "dog", "goat", "cow", "horse"]


def _verse(number):
    animal = ANIMALS[number - 1]
    lines = [f"I know an old lady who swallowed a {animal}."]

    if animal == "horse":
        lines.append("She's dead, of course!")
        return "\n".join(lines)

    lines.append(SECONDS[number - 1])
    if animal == "spider":
        lines.append("She swallowed the spider to catch the fly.")

    lines.extend(
        f"She swallowed the {ANIMALS[index]} to catch the {ANIMALS[index - 1]}"
        + (" that wriggled and jiggled and tickled inside her." if index == 2 else ".")
        for index in range(number - 1, 1, -1)
    )
    if number >= 3:
        lines.append("She swallowed the spider to catch the fly.")
    if animal != "fly":
        lines.append(SECONDS[0])
    return "\n".join(lines)


def recite(start_verse, end_verse):
    return "\n\n".join(
        _verse(number) for number in range(start_verse, end_verse + 1)
    )
