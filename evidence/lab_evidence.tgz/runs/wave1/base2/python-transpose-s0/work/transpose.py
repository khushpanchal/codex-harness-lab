def transpose(text):
    rows = text.splitlines()
    if not rows:
        return ""

    width = max(map(len, rows))
    output = []
    for column in range(width):
        output.append(
            "".join(
                row[column] if column < len(row) else " "
                for row in rows
            ).rstrip()
        )
    return "\n".join(output)
