class Scale:
    SHARP_SCALE = ["A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#"]
    FLAT_SCALE = ["A", "Bb", "B", "C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab"]
    MAJOR_SHARP = ["G", "D", "A", "E", "B", "F#"]
    MAJOR_FLAT = ["F", "Bb", "Eb", "Ab", "Db", "Gb"]
    MINOR_SHARP = ["E", "B", "F#", "C#", "G#", "D#"]
    MINOR_FLAT = ["D", "G", "C", "F", "Bb", "Eb"]
    STEP_SIZES = {"m": 1, "M": 2, "A": 3}

    def __init__(self, tonic):
        self.tonic = self._canonicalize(tonic)

    def _canonicalize(self, tonic):
        tonic = tonic.strip()
        return tonic[:1].upper() + tonic[1:].lower()

    def _use_flats(self):
        # Single-letter tonics are assumed to be major keys; C is the
        # conventional exception that uses sharps.
        key = self.tonic[:-1] if self.tonic.endswith(("b", "#")) else self.tonic
        major = len(self.tonic) == 1
        if major:
            flats = self.MAJOR_FLAT
            sharps = self.MAJOR_SHARP
        else:
            flats = self.MINOR_FLAT
            sharps = self.MINOR_SHARP
        if self.tonic == "C":
            return False
        return key in flats or (len(self.tonic) == 1 and self.tonic != "C" and key in sharps)

    def chromatic(self):
        base = self.FLAT_SCALE if self._use_flats() else self.SHARP_SCALE
        start = base.index(self.tonic)
        return base[start:] + base[:start]

    def interval(self, intervals):
        chromatic = self.chromatic()
        positions = {note.replace("b", "b"): index for index, note in enumerate(chromatic)}
        raw_positions = {}
        for index, note in enumerate(chromatic):
            pitch_class = index
            raw_positions[note] = pitch_class
        scale = [self.tonic]
        position = 0
        for step in intervals:
            position += self.STEP_SIZES[step]
            scale.append(chromatic[position % 12])
        return scale
