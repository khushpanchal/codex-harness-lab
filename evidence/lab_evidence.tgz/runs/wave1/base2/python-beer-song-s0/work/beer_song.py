def recite(start, take=1):
    if not 0 <= start <= 99:
        raise ValueError("start must be between 0 and 99")
    if take < 1:
        raise ValueError("take must be at least 1")

    return [line for number in range(start, start - take, -1) for line in _verse(number)]


def _quantity(number):
    return "no more bottles" if number == 0 else f"{number} bottle{'' if number == 1 else 's'}"


def _verse(number):
    current = _quantity(number)
    if number == 0:
        action = "Go to the store and buy some more"
        following = _quantity(99)
    else:
        action = "Take it down and pass it around" if number == 1 else "Take one down and pass it around"
        following = _quantity(number - 1)

    return [
        f"{current.capitalize()} of beer on the wall, {current} of beer.",
        f"{action}, {following} of beer on the wall.",
    ]
