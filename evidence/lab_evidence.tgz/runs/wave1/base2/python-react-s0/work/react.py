class InputCell:
    def __init__(self, initial_value):
        self._value = initial_value
        self._dependents = []

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, new_value):
        self._set_value(new_value)

    def _set_value(self, new_value):
        if self._value == new_value:
            return
        self._value = new_value
        changed = _propagate(self._dependents)
        for cell, callbacks in changed:
            for callback in callbacks:
                callback(cell)


class ComputeCell:
    def __init__(self, inputs, compute_function):
        self._inputs = list(inputs)
        self._compute_function = compute_function
        self._dependents = []
        self._callbacks = set()

        for input_cell in self._inputs:
            input_cell._dependents.append(self)

        self.value = self._compute_function(*(cell.value for cell in self._inputs))

    def add_callback(self, callback):
        self._callbacks.add(callback)

    def remove_callback(self, callback):
        self._callbacks.discard(callback)


def _propagate(start_cells):
    """Update descendants in dependency order and return their callbacks.

    Returning callbacks until every affected cell has a final value ensures
    notification handlers observe a stable reactive graph.
    """
    affected = set()
    visiting = set()
    changed = []

    def visit(cell):
        if cell not in affected:
            return
        if cell in visiting:
            raise ValueError("reactive cells contain a dependency cycle")
        visiting.add(cell)
        try:
            for input_cell in cell._inputs:
                visit(input_cell)
            new_value = cell._compute_function(*(input_cell.value for input_cell in cell._inputs))
            if new_value != cell.value:
                cell.value = new_value
                changed.append((cell, list(cell._callbacks)))
        finally:
            visiting.remove(cell)

    for start_cell in start_cells:
        for dependent in start_cell._dependents:
            affected.add(dependent)

    queue = list(affected)
    while queue:
        cell = queue.pop()
        for dependent in cell._dependents:
            if dependent not in affected:
                affected.add(dependent)
                queue.append(dependent)
    for affected_cell in affected:
        visit(affected_cell)
    return changed
    
