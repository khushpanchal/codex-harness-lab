def can_chain(dominoes):
    """Return True if the tiles can be arranged into a closed domino chain.

    Each tile is a two-item sequence.  A multiset of tiles is supported, so
    repeated entries are independent copies rather than the same object.
    """
    tiles = [(int(a), int(b)) for a, b in dominoes]
    if not tiles:
        return True

    graph = {}
    for index, (a, b) in enumerate(tiles):
        if a not in graph:
            graph[a] = []
        if b not in graph:
            graph[b] = []
        graph[a].append((b, index))
        graph[b].append((a, index))

    # By Euler's theorem, these two conditions are both necessary and
    # sufficient for a closed chain using every domino exactly once.
    if any(len(neighbours) % 2 for neighbours in graph.values()):
        return False

    start = tiles[0][0]
    seen = set()
    stack = [start]
    while stack:
        node = stack.pop()
        if node in seen:
            continue
        seen.add(node)
        stack.extend(neighbour for neighbour, _ in graph[node])
    if len(seen) != len(graph):
        return False
    return True
