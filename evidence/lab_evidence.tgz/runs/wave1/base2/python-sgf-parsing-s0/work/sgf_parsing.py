class SgfTree:
    def __init__(self, properties=None, children=None):
        self.properties = properties or {}
        self.children = children or []

    def __eq__(self, other):
        if not isinstance(other, SgfTree):
            return False
        for key, value in self.properties.items():
            if key not in other.properties:
                return False
            if other.properties[key] != value:
                return False
        for key in other.properties.keys():
            if key not in self.properties:
                return False
        if len(self.children) != len(other.children):
            return False
        for child, other_child in zip(self.children, other.children):
            if child != other_child:
                return False
        return True

    def __ne__(self, other):
        return not self == other


def parse(input_string):
    if not input_string or not isinstance(input_string, str):
        raise ValueError("tree missing")
    parser = SgfParser(input_string)
    return parser.parse_tree()


class SgfParser:
    def __init__(self, text):
        self.text = text
        self.index = 0

    def parse_tree(self):
        self.expect("(", "tree missing")
        nodes = []
        while self.peek() == ";":
            nodes.append(self.parse_node())

        trees = []
        while self.peek() == "(":
            trees.append(self.parse_tree())

        self.expect(")", "tree missing")

        if not nodes:
            raise ValueError("tree with no nodes")

        tree = nodes[-1]
        for parent, child in zip(nodes, nodes[1:]):
            parent.children = [child]
        tree.children.extend(trees)
        return nodes[0]

    def parse_node(self):
        self.expect(";", "node missing")
        properties = {}
        while True:
            start = self.index
            if not self.peek().isalpha():
                break
            key = self.parse_key()
            properties[key] = self.parse_values()
            if self.index == start:
                break
        return SgfTree(properties)

    def parse_key(self):
        key = ""
        while self.peek().isalpha():
            key += self.text[self.index]
            self.index += 1
        if not key or not (len(key) == 1 or len(key) == 2) or not key.isupper():
            raise ValueError("property must be in uppercase")
        return key

    def parse_values(self):
        values = []
        while self.peek() == "[":
            self.index += 1
            values.append(self.parse_value())
        if not values:
            raise ValueError("properties without delimiter")
        return values

    def parse_value(self):
        value = []
        while True:
            if self.index >= len(self.text):
                raise ValueError("properties without delimiter")
            char = self.text[self.index]
            self.index += 1
            if char == "]":
                break
            if char == "\\":
                if self.index >= len(self.text):
                    raise ValueError("properties without delimiter")
                escaped = self.text[self.index]
                if escaped == "\n":
                    self.index += 1
                    continue
                if escaped in "\t\v\f\r ":
                    self.index += 1
                    if escaped == "\r":
                        continue
                    value.append(" ")
                    continue
                value.append(escaped)
                self.index += 1
            elif char == "\n":
                value.append("\n")
            elif char.isspace():
                value.append(" ")
            else:
                value.append(char)
        return "".join(value)

    def peek(self):
        return self.text[self.index] if self.index < len(self.text) else ""

    def expect(self, expected, message):
        if self.peek() != expected:
            raise ValueError(message)
        self.index += 1
