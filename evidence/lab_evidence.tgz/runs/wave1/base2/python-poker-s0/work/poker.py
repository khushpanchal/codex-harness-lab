def _parse_hand(hand):
    cards = hand.split()
    if len(cards) != 5:
        raise ValueError("a poker hand must contain exactly five cards")

    values = []
    for card in cards:
        rank, suit = card[:-1], card[-1]
        if not card or len(card) > 3 or suit not in "SHDC":
            raise ValueError(f"invalid card: {card}")
        try:
            if rank == "A":
                value = 14
            elif rank == "K":
                value = 13
            elif rank == "Q":
                value = 12
            elif rank == "T":
                value = 10
            elif rank == "J":
                value = 11
            else:
                value = int(rank)
                if not 2 <= value <= 10:
                    raise ValueError(f"invalid card: {card}")
        except ValueError as error:
            raise ValueError(f"invalid card: {card}") from error
        values.append((value, suit))

    if len({(value, suit) for value, suit in values}) != 5:
        raise ValueError("a hand may not contain duplicate cards")
    return values


def _score_hand(hand):
    cards = _parse_hand(hand)
    values = sorted((value for value, _ in cards), reverse=True)
    suits = {suit for _, suit in cards}
    is_flush = len(suits) == 1

    def straight_high(cards):
        values = sorted(set(value for value, _ in cards), reverse=True)
        if len(values) != 5:
            return None
        if values[0] - values[-1] == 4:
            return values[0]
        # Ace-low straight: A 2 3 4 5.
        if values == [14, 5, 4, 3, 2]:
            return 5
        return None

    counts = {}
    for value in values:
        counts[value] = counts.get(value, 0) + 1
    groups = sorted(counts.items(), key=lambda item: (item[1], item[0]), reverse=True)
    ordered = tuple(value for value, _ in groups)
    shape = tuple(count for _, count in groups)
    straight = straight_high(cards)

    if straight and is_flush:
        category = 8
    elif shape == (4, 1):
        category = 7
    elif shape == (3, 2):
        category = 6
    elif is_flush:
        category = 5
    elif straight:
        category = 4
    elif shape == (3, 1, 1):
        category = 3
    elif shape == (2, 2, 1):
        category = 2
    elif shape == (2, 1, 1, 1):
        category = 1
    else:
        category = 0

    if category == 8:
        tiebreak = (straight,)
    elif category == 4:
        tiebreak = (straight,)
    else:
        tiebreak = ordered
    return category, tiebreak


def best_hands(hands):
    if not hands:
        return []
    best_score = None
    winners = []
    for hand in hands:
        score = _score_hand(hand)
        if best_score is None or score > best_score:
            best_score = score
            winners = [hand]
        elif score == best_score:
            winners.append(hand)
    return winners
