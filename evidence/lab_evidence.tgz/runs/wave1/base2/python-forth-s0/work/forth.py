class StackUnderflowError(Exception):
    """Raised when an operation needs more values than are on the stack."""


def evaluate(input_data):
    definitions = {}
    stack = []
    output = []

    def underflow(count):
        if len(stack) < count:
            raise StackUnderflowError("Insufficient number of items in stack")

    def add():
        underflow(2)
        right = stack.pop()
        left = stack.pop()
        stack.append(left + right)

    def subtract():
        underflow(2)
        right = stack.pop()
        left = stack.pop()
        stack.append(left - right)

    def multiply():
        underflow(2)
        right = stack.pop()
        left = stack.pop()
        stack.append(left * right)

    def divide():
        underflow(2)
        right = stack.pop()
        left = stack.pop()
        if right == 0:
            raise ZeroDivisionError("divide by zero")
        stack.append(left // right)

    def duplicate():
        underflow(1)
        stack.append(stack[-1])

    def drop():
        underflow(1)
        stack.pop()

    def swap():
        underflow(2)
        stack[-1], stack[-2] = stack[-2], stack[-1]

    def over():
        underflow(2)
        stack.append(stack[-2])

    builtins = {
        "+": add,
        "-": subtract,
        "*": multiply,
        "/": divide,
        "dup": duplicate,
        "drop": drop,
        "swap": swap,
        "over": over,
    }

    def execute(token):
        operation = token.casefold()
        if operation in definitions:
            for word in definitions[operation]:
                execute(word)
        elif operation in builtins:
            builtins[operation]()
        elif operation.lstrip("+-").isdigit() and operation not in ("+", "-"):
            stack.append(int(operation))
        else:
            raise ValueError("undefined operation")

    for source in input_data:
        stack.clear()
        tokens = source.split()
        index = 0
        while index < len(tokens):
            token = tokens[index]
            if token == ":":
                try:
                    end = tokens.index(";", index + 1)
                except ValueError as error:
                    raise ValueError("incomplete word definition") from error
                if end < index + 3:
                    raise ValueError("incomplete word definition")
                name = tokens[index + 1].casefold()
                if name.lstrip("+-").isdigit() and name not in ("+", "-"):
                    raise ValueError("cannot redefine numbers")
                definitions[name] = tokens[index + 2:end]
                index = end + 1
                continue
            execute(token)
            index += 1
        output.extend(stack)

    return output
