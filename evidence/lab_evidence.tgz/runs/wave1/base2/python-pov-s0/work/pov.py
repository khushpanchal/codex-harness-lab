from json import dumps


class Tree:
    def __init__(self, label, children=None):
        self.label = label
        self.children = children if children is not None else []

    def __dict__(self):
        return {self.label: [c.__dict__() for c in sorted(self.children)]}

    def __str__(self, indent=None):
        return dumps(self.__dict__(), indent=indent)

    def __lt__(self, other):
        return self.label < other.label

    def __eq__(self, other):
        return self.__dict__() == other.__dict__()

    def _find(self, label):
        if self.label == label:
            return self
        for child in self.children:
            found = child._find(label)
            if found is not None:
                return found
        return None

    def _validate(self, parents):
        here = id(self)
        if here in parents:
            raise ValueError("Tree could not be reoriented")
        for child in self.children:
            child._validate(parents | {here})

    def from_pov(self, from_node):
        self._validate(set())
        path = []

        def find(node, parent_label=None):
            if node.label == from_node:
                path.append(node)
                return True
            for child in node.children:
                if child.label == parent_label or find(child, node.label):
                    path.append(child)
                    return True
            return False

        if not find(self) or len(path) > 1 and path[-1].label != from_node:
            raise ValueError("Tree could not be reoriented")

        def reparent(node, parent_label=None):
            child_labels = [child.label for child in node.children]
            if len(child_labels) != len(set(child_labels)):
                raise ValueError("Tree could not be reoriented")
            return Tree(
                node.label,
                [
                    reparent(child, node.label)
                    for child in node.children
                    if child.label != parent_label
                ],
            )

        return reparent(path[-1])

    def path_to(self, from_node, to_node):
        if self._find(from_node) is None:
            raise ValueError(f"No path from {from_node!r} to {to_node!r}")
        if self._find(to_node) is None:
            raise ValueError(f"No path from {from_node!r} to {to_node!r}")

        def visit(node, parent_label=None):
            if node.label == to_node:
                return [node.label]
            for child in node.children:
                if child.label == parent_label:
                    continue
                suffix = visit(child, node.label)
                if suffix is not None:
                    return [node.label] + suffix
            return None

        return visit(self._find(from_node))
