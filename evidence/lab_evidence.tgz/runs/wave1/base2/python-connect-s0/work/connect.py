
class ConnectGame:
    def __init__(self, board):
        if isinstance(board, str):
            rows = [row for row in board.splitlines() if row.strip()]
        else:
            rows = list(board)

        if not rows:
            raise ValueError("board must not be empty")

        self.board = []
        for row in rows:
            stripped = [ch for ch in row if not ch.isspace()]
            if any(ch not in ".OXox" for ch in stripped):
                raise ValueError("board may contain only O, X, and empty cells")
            self.board.append([ch.upper() for ch in stripped])

        widths = {len(row) for row in self.board}
        if len(widths) != 1:
            raise ValueError("all board rows must contain the same number of cells")

    def get_winner(self):
        if self._connects("O", top=True):
            return "O"
        if self._connects("X", top=False):
            return "X"
        return None

    def get_result(self):
        return self.get_winner()

    def _connects(self, player, *, top):
        height = len(self.board)
        width = len(self.board[0])
        start_range = range(width if top else height)
        stack = []

        # O joins the top and bottom rows; X joins the left and right columns.
        for index in start_range:
            row, column = (0, index) if top else (index, 0)
            if self.board[row][column] == player:
                stack.append((row, column))

        seen = set(stack)
        while stack:
            row, column = stack.pop()
            reached_opposite = (
                row == height - 1 if top else column == width - 1
            )
            if reached_opposite:
                return True

            for delta_row, delta_column in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, 1), (1, -1)):
                neighbor = (row + delta_row, column + delta_column)
                neighbor_row, neighbor_column = neighbor
                if (
                    0 <= neighbor_row < height
                    and 0 <= neighbor_column < width
                    and neighbor not in seen
                    and self.board[neighbor_row][neighbor_column] == player
                ):
                    seen.add(neighbor)
                    stack.append(neighbor)

        return False
