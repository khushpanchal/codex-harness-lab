def append(list1, list2):
    result = []
    for item in list1:
        result += [item]
    for item in list2:
        result += [item]
    return result


def concatenate(lists):
    result = []
    for sublist in lists:
        result = append(result, sublist)
    return result


def filter(function, items):
    result = []
    for item in items:
        if function(item):
            result += [item]
    return result


def length(items):
    total = 0
    for _ in items:
        total += 1
    return total


def map(function, items):
    result = []
    for item in items:
        result += [function(item)]
    return result


def foldl(function, items, initial):
    accumulator = initial
    for item in items:
        accumulator = function(accumulator, item)
    return accumulator


def foldr(function, items, initial):
    accumulator = initial
    for item in reverse(items):
        accumulator = function(item, accumulator)
    return accumulator


def reverse(items):
    result = []
    for item in items:
        result = [item] + result
    return result


concat = concatenate
