import unittest

import list_ops


def test_append_empty_lists():
    assert list_ops.append([], []) == []


def test_append_to_empty_list():
    assert list_ops.append([], [1, 2, 3]) == [1, 2, 3]


def test_append_empty_list():
    assert list_ops.append([1, 2, 3], []) == [1, 2, 3]


def test_append_normal_lists():
    assert list_ops.append([1, 2], [3, 4]) == [1, 2, 3, 4]


def test_append_does_not_modify_inputs():
    first = [1, 2]
    second = [3]
    assert list_ops.append(first, second) == [1, 2, 3]
    assert first == [1, 2]
    assert second == [3]


def test_concatenate_empty_series():
    assert list_ops.concatenate([]) == []


def test_concatenate_empty_lists():
    assert list_ops.concatenate([[], [], []]) == []


def test_concatenate_normal_lists():
    assert list_ops.concatenate([[1, 2], [3], [], [4, 5]]) == [1, 2, 3, 4, 5]


def test_concat_alias_matches_concatenate():
    lists = [[1], [], [2, 3]]
    assert list_ops.concat(lists) == list_ops.concatenate(lists)


def test_filter_empty_list():
    assert list_ops.filter(lambda item: True, []) == []


def test_filter_no_items_match():
    assert list_ops.filter(lambda item: item % 2 == 0, [1, 3, 5]) == []


def test_filter_all_items_match():
    assert list_ops.filter(lambda item: item % 2 == 0, [2, 4, 6]) == [2, 4, 6]


def test_filter_matches_normal_list():
    assert list_ops.filter(lambda item: item % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]


def test_length_empty_list():
    assert list_ops.length([]) == 0


def test_length_normal_list():
    assert list_ops.length([1, 2, 3, 4]) == 4


def test_map_empty_list():
    assert list_ops.map(lambda item: item, []) == []


def test_map_normal_list():
    assert list_ops.map(lambda item: item * 2, [1, 2, 3]) == [2, 4, 6]


def test_map_preserves_item_order():
    assert list_ops.map(str, [3, 1, 2]) == ["3", "1", "2"]


def test_foldl_empty_list_returns_initial():
    assert list_ops.foldl(lambda accumulator, item: accumulator + item, [], 7) == 7


def test_foldl_adds_from_the_left():
    assert list_ops.foldl(lambda accumulator, item: accumulator + item, [1, 2, 3], 0) == 6


def test_foldl_accumulator_is_first_argument():
    calls = []

    def combine(accumulator, item):
        calls.append((accumulator, item))
        return (accumulator, item)

    result = list_ops.foldl(combine, [1, 2, 3], 0)
    assert calls == [(0, 1), ((0, 1), 2), (((0, 1), 2), 3)]
    assert result == (((0, 1), 2), 3)


def test_foldr_empty_list_returns_initial():
    assert list_ops.foldr(lambda item, accumulator: item + accumulator, [], 7) == 7


def test_foldr_adds_from_the_right():
    assert list_ops.foldr(lambda item, accumulator: item + accumulator, [1, 2, 3], 0) == 6


def test_foldr_accumulator_is_second_argument():
    calls = []

    def combine(item, accumulator):
        calls.append((item, accumulator))
        return (item, accumulator)

    result = list_ops.foldr(combine, [1, 2, 3], 0)
    assert calls == [(3, 0), (2, (3, 0)), (1, (2, (3, 0)))]
    assert result == (1, (2, (3, 0)))


def test_foldl_and_foldr_are_left_and_right_associative():
    subtract_left = list_ops.foldl(lambda accumulator, item: accumulator - item, [1, 2, 3], 10)
    subtract_right = list_ops.foldr(lambda item, accumulator: item - accumulator, [1, 2, 3], 10)
    assert subtract_left == 4
    assert subtract_right == -8


def test_reverse_empty_list():
    assert list_ops.reverse([]) == []


def test_reverse_normal_list():
    assert list_ops.reverse([1, 2, 3, 4]) == [4, 3, 2, 1]


def test_reverse_preserves_equal_items():
    assert list_ops.reverse([1, 1, 2]) == [2, 1, 1]


if __name__ == "__main__":
    function_tests = [
        unittest.FunctionTestCase(function)
        for name, function in list(globals().items())
        if name.startswith("test_") and callable(function)
    ]
    unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(function_tests))
