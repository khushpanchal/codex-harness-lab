class BowlingGame:
    def __init__(self):
        self.rolls = []

    def roll(self, pins):
        if not isinstance(pins, int) or isinstance(pins, bool):
            raise ValueError("invalid roll: pins must be an integer")
        if pins < 0 or pins > 10:
            raise ValueError("invalid roll: pins must be between 0 and 10")

        frames = self._frames(self.rolls)
        if len(frames) == 10 and frames[-1]["status"] == "complete":
            raise IndexError("cannot roll after game is over")

        if frames and frames[-1]["status"] == "in_progress":
            if len(frames) < 10:
                standing = 10 - frames[-1]["rolls"][0]
                if pins > standing:
                    raise ValueError("invalid roll: second roll exceeds standing pins")
            else:
                self._validate_tenth_roll(frames[-1]["rolls"], pins)

        self.rolls.append(pins)

    def score(self):
        frames = self._frames(self.rolls)
        if len(frames) < 10 or frames[-1]["status"] != "complete":
            raise IndexError("game is incomplete")

        total = 0
        for index, frame in enumerate(frames[:9]):
            if frame["open"]:
                total += sum(frame["rolls"])
                continue

            needed = 2 if frame["rolls"][0] == 10 else 1
            following = self._following_rolls(frames, index)
            if len(following) < needed:
                raise IndexError("game is incomplete")
            total += sum(frame["rolls"]) + sum(following[:needed])

        return total + sum(frames[-1]["rolls"])

    def _validate_tenth_roll(self, rolls, pins):
        if len(rolls) >= 3:
            raise IndexError("cannot roll after game is over")

        if len(rolls) == 0:
            return

        first = rolls[0]
        if len(rolls) == 1:
            standing = 10 if first == 10 else 10 - first
            if pins > standing:
                raise ValueError("invalid fill balls")
        elif not (first == 10 and rolls[1] == 10) and pins > 10 - rolls[1]:
            raise ValueError("invalid fill balls")
        else:
            raise IndexError("cannot roll after game is over")

    def _following_rolls(self, frames, frame_index):
        start = sum(len(frame["rolls"]) for frame in frames[: frame_index + 1])
        return self.rolls[start:]

    @staticmethod
    def _frames(rolls):
        frames = []
        index = 0

        for _ in range(9):
            if index >= len(rolls):
                break
            if rolls[index] == 10:
                frames.append({"rolls": [10], "status": "complete", "open": False})
                index += 1
            elif index + 1 < len(rolls):
                first, second = rolls[index : index + 2]
                frames.append(
                    {
                        "rolls": [first, second],
                        "status": "complete",
                        "open": first + second < 10,
                    }
                )
                index += 2
            else:
                frames.append({"rolls": [rolls[index]], "status": "in_progress", "open": False})
                index += 1

        if index < len(rolls):
            final = rolls[index:]
            if len(final) > 3:
                raise IndexError("cannot roll after game is over")

            complete = len(final) == 3 or (
                len(final) == 2 and final[0] + final[1] < 10
            )
            frames.append(
                {
                    "rolls": final,
                    "status": "complete" if complete else "in_progress",
                    "open": len(final) == 2 and final[0] + final[1] < 10,
                }
            )

        return frames
