import unittest

from pig_latin import translate


class PigLatinTests(unittest.TestCase):
    def test_empty_string_has_no_words(self):
        self.assertEqual("", translate(""))

    def test_rule_1_vowel_start(self):
        self.assertEqual("appleay", translate("apple"))

    def test_rule_1_xr_start(self):
        self.assertEqual("xrayay", translate("xray"))

    def test_rule_1_yt_start(self):
        self.assertEqual("yttriaay", translate("yttria"))

    def test_rule_2_single_consonant(self):
        self.assertEqual("igpay", translate("pig"))

    def test_rule_2_multiple_consonants(self):
        self.assertEqual("airchay", translate("chair"))
        self.assertEqual("ushthray", translate("thrush"))

    def test_rule_3_qu_with_no_preceding_consonants(self):
        self.assertEqual("ickquay", translate("quick"))

    def test_rule_3_consonants_preceding_qu(self):
        self.assertEqual("aresquay", translate("square"))

    def test_rule_4_single_consonant_followed_by_y(self):
        self.assertEqual("ymay", translate("my"))

    def test_rule_4_multiple_consonants_followed_by_y(self):
        self.assertEqual("ythmrhay", translate("rhythm"))

    def test_rule_1_takes_precedence_over_yt_rule(self):
        self.assertEqual("yttriaay", translate("yttria"))

    def test_rule_2_can_end_before_a_later_y(self):
        self.assertEqual("ellowyay", translate("yellow"))

    def test_multiple_words_are_translated_independently(self):
        self.assertEqual("igpay airchay", translate("pig chair"))


if __name__ == "__main__":
    unittest.main()
