def translate(text):
    vowels = "aeiou"

    def translate_word(word):
        if not word:
            return word

        # Treat consonant clusters as everything before the first vowel,
        # except for the special vowel-like sequences "xr" and "yt".
        if word[:2] in {"xr", "yt"} or (word[0].lower() in vowels):
            return word + "ay"

        i = 0
        while i < len(word) and word[i].lower() not in vowels:
            if i > 0 and word[i].lower() == "y":
                break
            i += 1

        # The "u" after a consonant "q" is part of the "qu" unit, as in "square".
        if i > 0 and word[i - 1].lower() == "q" and word[i].lower() == "u":
            i += 1

        return word[i:] + word[:i] + "ay"

    return " ".join(translate_word(word) for word in text.split(" "))
