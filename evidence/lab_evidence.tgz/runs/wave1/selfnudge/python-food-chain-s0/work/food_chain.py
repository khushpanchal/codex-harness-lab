_ANIMALS = (
    ("fly", None),
    ("spider", "It wriggled and jiggled and tickled inside her."),
    ("bird", "How absurd to swallow a bird!"),
    ("cat", "Imagine that, to swallow a cat!"),
    ("dog", "What a hog, to swallow a dog!"),
    ("goat", "Just opened her throat and swallowed a goat!"),
    ("cow", "I don't know how she swallowed a cow!"),
)

_SPIDER_PHRASE = " that wriggled and jiggled and tickled inside her"
_FINAL_VERSE = (
    "I know an old lady who swallowed a horse.\n"
    "She's dead, of course!"
)
_FLY_CONCLUSION = (
    "I don't know why she swallowed the fly. Perhaps she'll die."
)


def _verse(index):
    if index == len(_ANIMALS) + 1:
        return _FINAL_VERSE

    animal, remark = _ANIMALS[index - 1]
    lines = [f"I know an old lady who swallowed a {animal}."]
    if remark is not None:
        lines.append(remark)

    if index == 1:
        lines.append(_FLY_CONCLUSION)
        return "\n".join(lines)

    for chain_index in range(index, 1, -1):
        swallowed_animal = _ANIMALS[chain_index - 1][0]
        prey = _ANIMALS[chain_index - 2][0]
        prey_phrase = _SPIDER_PHRASE if prey == "spider" else ""
        lines.append(
            f"She swallowed the {swallowed_animal} to catch the {prey}{prey_phrase}."
        )

    lines.append(_FLY_CONCLUSION)
    return "\n".join(lines)


def recite(start_verse, end_verse):
    if start_verse < 1 or end_verse < start_verse or end_verse > len(_ANIMALS) + 1:
        raise ValueError("Invalid verse")

    return "\n\n".join(_verse(i) for i in range(start_verse, end_verse + 1))
