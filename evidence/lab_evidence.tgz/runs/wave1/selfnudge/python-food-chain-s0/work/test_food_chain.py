import unittest

from food_chain import recite


class FoodChainTests(unittest.TestCase):
    def assertVerse(self, verse_number, expected):
        self.assertEqual(recite(verse_number, verse_number), expected)

    def test_fly_verse(self):
        self.assertVerse(
            1,
            "I know an old lady who swallowed a fly.\n"
            "I don't know why she swallowed the fly. Perhaps she'll die.",
        )

    def test_spider_verse(self):
        self.assertVerse(
            2,
            "I know an old lady who swallowed a spider.\n"
            "It wriggled and jiggled and tickled inside her.\n"
            "She swallowed the spider to catch the fly.\n"
            "I don't know why she swallowed the fly. Perhaps she'll die.",
        )

    def test_bird_verse(self):
        self.assertVerse(
            3,
            "I know an old lady who swallowed a bird.\n"
            "How absurd to swallow a bird!\n"
            "She swallowed the bird to catch the spider that wriggled and "
            "jiggled and tickled inside her.\n"
            "She swallowed the spider to catch the fly.\n"
            "I don't know why she swallowed the fly. Perhaps she'll die.",
        )

    def test_cat_verse(self):
        self.assertVerse(
            4,
            "I know an old lady who swallowed a cat.\n"
            "Imagine that, to swallow a cat!\n"
            "She swallowed the cat to catch the bird.\n"
            "She swallowed the bird to catch the spider that wriggled and "
            "jiggled and tickled inside her.\n"
            "She swallowed the spider to catch the fly.\n"
            "I don't know why she swallowed the fly. Perhaps she'll die.",
        )

    def test_dog_verse(self):
        self.assertVerse(
            5,
            "I know an old lady who swallowed a dog.\n"
            "What a hog, to swallow a dog!\n"
            "She swallowed the dog to catch the cat.\n"
            "She swallowed the cat to catch the bird.\n"
            "She swallowed the bird to catch the spider that wriggled and "
            "jiggled and tickled inside her.\n"
            "She swallowed the spider to catch the fly.\n"
            "I don't know why she swallowed the fly. Perhaps she'll die.",
        )

    def test_goat_verse(self):
        self.assertVerse(
            6,
            "I know an old lady who swallowed a goat.\n"
            "Just opened her throat and swallowed a goat!\n"
            "She swallowed the goat to catch the dog.\n"
            "She swallowed the dog to catch the cat.\n"
            "She swallowed the cat to catch the bird.\n"
            "She swallowed the bird to catch the spider that wriggled and "
            "jiggled and tickled inside her.\n"
            "She swallowed the spider to catch the fly.\n"
            "I don't know why she swallowed the fly. Perhaps she'll die.",
        )

    def test_cow_verse(self):
        self.assertVerse(
            7,
            "I know an old lady who swallowed a cow.\n"
            "I don't know how she swallowed a cow!\n"
            "She swallowed the cow to catch the goat.\n"
            "She swallowed the goat to catch the dog.\n"
            "She swallowed the dog to catch the cat.\n"
            "She swallowed the cat to catch the bird.\n"
            "She swallowed the bird to catch the spider that wriggled and "
            "jiggled and tickled inside her.\n"
            "She swallowed the spider to catch the fly.\n"
            "I don't know why she swallowed the fly. Perhaps she'll die.",
        )

    def test_horse_verse(self):
        self.assertVerse(
            8,
            "I know an old lady who swallowed a horse.\n"
            "She's dead, of course!",
        )

    def test_single_verse_range(self):
        expected = (
            "I know an old lady who swallowed a dog.\n"
            "What a hog, to swallow a dog!\n"
            "She swallowed the dog to catch the cat.\n"
            "She swallowed the cat to catch the bird.\n"
            "She swallowed the bird to catch the spider that wriggled and "
            "jiggled and tickled inside her.\n"
            "She swallowed the spider to catch the fly.\n"
            "I don't know why she swallowed the fly. Perhaps she'll die."
        )
        self.assertEqual(recite(5, 5), expected)

    def test_first_and_last_verse_range(self):
        song = recite(1, 8)
        self.assertTrue(song.startswith(recite(1, 1) + "\n\n"))
        self.assertTrue(song.endswith(recite(8, 8)))
        self.assertEqual(song.split("\n\n")[0], recite(1, 1))
        self.assertEqual(song.split("\n\n")[-1], recite(8, 8))

    def test_contiguous_middle_range(self):
        expected = "\n\n".join(
            recite(verse, verse) for verse in range(4, 7)
        )
        self.assertEqual(recite(4, 6), expected)

    def test_whole_song_has_seven_separators(self):
        self.assertEqual(recite(1, 8).count("\n\n"), 7)

    def test_zero_verse_is_invalid(self):
        with self.assertRaises(ValueError):
            recite(0, 1)

    def test_reversed_range_is_invalid(self):
        with self.assertRaises(ValueError):
            recite(3, 2)

    def test_verse_beyond_song_is_invalid(self):
        with self.assertRaises(ValueError):
            recite(1, 9)

if __name__ == "__main__":
    unittest.main()
