def recite(start, take=1):
    verses = []
    for count in range(start, start - take, -1):
        current = _quantity(count)
        if count == 1:
            action = "Take it down and pass it around"
            remaining = _quantity(0)
        elif count == 0:
            action = "Go to the store and buy some more"
            remaining = _quantity(99)
            verses.append(
                "No more bottles of beer on the wall, no more bottles of beer.\n"
                f"{action}, {remaining} of beer on the wall."
            )
            continue
        else:
            action = "Take one down and pass it around"
            remaining = _quantity(count - 1)

        verses.append(
            f"{current} of beer on the wall, {current} of beer.\n"
            f"{action}, {remaining} of beer on the wall."
        )
    return "\n\n".join(verses)


def _quantity(count):
    if count == 0:
        return "no more bottles"
    if count == 1:
        return "1 bottle"
    return f"{count} bottles"
