import unittest

from beer_song import recite


def verse(first, second, action, take_verb="Take one down"):
    return (
        f"{first} of beer on the wall, {first} of beer.\n"
        f"{action}, {second} of beer on the wall."
    )


def quantity(count):
    if count == 0:
        return "no more bottles"
    if count == 1:
        return "1 bottle"
    return f"{count} bottles"


def standard(count):
    return verse(
        quantity(count),
        quantity(count - 1),
        "Take one down and pass it around",
    )


def final_verse():
    return (
        "No more bottles of beer on the wall, no more bottles of beer.\n"
        "Go to the store and buy some more, 99 bottles of beer on the wall."
    )


class BeerSongTests(unittest.TestCase):
    def test_single_verse_with_plural_counts(self):
        for count in (99, 98, 97, 50, 3, 2):
            with self.subTest(count=count):
                self.assertEqual(recite(count), standard(count))

    def test_two_bottle_verse_reports_one_bottle(self):
        self.assertEqual(
            recite(2),
            "2 bottles of beer on the wall, 2 bottles of beer.\n"
            "Take one down and pass it around, 1 bottle of beer on the wall.",
        )

    def test_one_bottle_verse_uses_take_it(self):
        self.assertEqual(
            recite(1),
            "1 bottle of beer on the wall, 1 bottle of beer.\n"
            "Take it down and pass it around, no more bottles of beer on the wall.",
        )

    def test_no_more_bottle_verse_uses_go_to_store(self):
        self.assertEqual(recite(0), final_verse())

    def test_take_defaults_to_one_verse(self):
        self.assertEqual(recite(99, 1), recite(99))

    def test_multiple_normal_verses_are_joined_with_blank_lines(self):
        self.assertEqual(
            recite(4, 3),
            "\n\n".join((standard(4), standard(3), standard(2))),
        )

    def test_multiple_verses_span_special_and_wraparound_cases(self):
        self.assertEqual(recite(2, 3), "\n\n".join((standard(2), recite(1), final_verse())))

    def test_take_of_all_verse_count(self):
        self.assertEqual(
            recite(3, 4),
            "\n\n".join((standard(3), standard(2), recite(1), final_verse())),
        )

    def test_first_verse_of_complete_song(self):
        self.assertEqual(recite(99), standard(99))

    def test_last_verse_of_complete_song(self):
        self.assertEqual(recite(0), final_verse())

    def test_every_verse_of_complete_song(self):
        song = recite(99, 100)
        expected = [standard(count) for count in range(99, 1, -1)]
        expected.extend((recite(1), final_verse()))
        self.assertEqual(song, "\n\n".join(expected))

    def test_wraparound_starting_earlier_includes_capitalized_final_verse(self):
        self.assertIn(
            "\n\n" + final_verse(),
            recite(2, 3),
        )

    def test_zero_take_yields_empty_song(self):
        self.assertEqual(recite(99, 0), "")


if __name__ == "__main__":
    unittest.main()
