class StackUnderflowError(Exception):
    """Exception raised when the stack does not contain enough items."""


def evaluate(input_data):
    stack = []
    words = {}

    def require(count, operation):
        if len(stack) < count:
            raise StackUnderflowError(
                f"Insufficient number of items in stack for {operation}"
            )

    def run_token(token):
        if is_number(token):
            stack.append(int(token))
        elif token.upper() in words:
            for body_token in words[token.upper()]:
                run_token(body_token)
        else:
            operation = token.upper()
            if operation == "+":
                require(2, "+")
                stack[-2:] = [stack[-2] + stack[-1]]
            elif operation == "-":
                require(2, "-")
                stack[-2:] = [stack[-2] - stack[-1]]
            elif operation == "*":
                require(2, "*")
                stack[-2:] = [stack[-2] * stack[-1]]
            elif operation == "/":
                require(2, "/")
                if stack[-1] == 0:
                    raise ZeroDivisionError("divide by zero")
                dividend, divisor = stack[-2:]
                stack[-2:] = [int(dividend / divisor)]
            elif operation == "DUP":
                require(1, "DUP")
                stack.append(stack[-1])
            elif operation == "DROP":
                require(1, "DROP")
                stack.pop()
            elif operation == "SWAP":
                require(2, "SWAP")
                stack[-2:] = [stack[-1], stack[-2]]
            elif operation == "OVER":
                require(2, "OVER")
                stack.append(stack[-2])
            else:
                raise ValueError("undefined operation")

    tokens = tokenize(input_data)
    index = 0
    while index < len(tokens):
        if tokens[index] == ":":
            index = define_word(tokens, index, words)
        else:
            run_token(tokens[index])
            index += 1
    return stack


def tokenize(input_data):
    if isinstance(input_data, str):
        input_data = [input_data]
    return [token for line in input_data for token in line.split()]


def is_number(token):
    return bool(token) and all("0" <= char <= "9" for char in token)


def define_word(tokens, start, words):
    try:
        name = tokens[start + 1]
    except IndexError:
        raise ValueError("word definition requires a name") from None
    if is_number(name):
        raise ValueError("cannot redefine numbers")
    body = []
    index = start + 2
    while index < len(tokens) and tokens[index] != ";":
        body.append(tokens[index])
        index += 1
    if index >= len(tokens):
        raise ValueError("word definition is missing ;")
    words[name.upper()] = body
    return index + 1
