
class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        self.board = board
        self.rows = len(board)
        self.columns = max((len(row) for row in board), default=0)

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not isinstance(x, int) or isinstance(x, bool):
            raise ValueError("Invalid coordinate")
        if not isinstance(y, int) or isinstance(y, bool):
            raise ValueError("Invalid coordinate")
        if not (0 <= x < self.columns and 0 <= y < self.rows):
            raise ValueError("Invalid coordinate")
        if self.board[y][x] != " ":
            raise ValueError("Invalid coordinate: intersection is occupied")

        owners = set()
        seen = {(x, y)}
        stack = [(x, y)]

        while stack:
            point = stack.pop()
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                neighbor = (point[0] + dx, point[1] + dy)
                nx, ny = neighbor
                if not (0 <= nx < self.columns and 0 <= ny < self.rows):
                    continue
                value = self.board[ny][nx]
                if value in ("B", "W"):
                    owners.add(value)
                elif neighbor not in seen:
                    seen.add(neighbor)
                    stack.append(neighbor)

        owner = owners.pop() if len(owners) == 1 else ""
        return owner, seen

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        result = {"B": set(), "W": set(), "": set()}
        for y, row in enumerate(self.board):
            for x, value in enumerate(row):
                if value == " ":
                    owner, territory = self.territory(x, y)
                    result[owner].update(territory)
        return result
