import unittest

from go_counting import Board


class GoCountingTests(unittest.TestCase):
    def test_single_point_enclosed_by_black(self):
        board = Board(["BBB", "B B", "BBB"])
        self.assertEqual(board.territory(1, 1), ("B", {(1, 1)}))

    def test_single_point_enclosed_by_white(self):
        board = Board(["WWW", "W W", "WWW"])
        self.assertEqual(board.territory(1, 1), ("W", {(1, 1)}))

    def test_region_connects_through_horizontal_and_vertical_neighbors_only(self):
        board = Board(["BBBB", "B  B", "BBBB"])
        self.assertEqual(board.territory(1, 1), ("B", {(1, 1), (2, 1)}))

    def test_region_with_only_one_adjacent_owner(self):
        board = Board([" B "])
        self.assertEqual(board.territory(0, 0), ("B", {(0, 0)}))
        self.assertEqual(board.territory(2, 0), ("B", {(2, 0)}))

    def test_region_with_mixed_owners_is_unowned(self):
        board = Board(["B W"])
        self.assertEqual(board.territory(1, 0), ("", {(1, 0)}))

    def test_empty_and_non_empty_boards_are_handled(self):
        with self.assertRaises(ValueError):
            Board([]).territory(0, 0)
        self.assertEqual(Board([" "]).territories(), {"B": set(), "W": set(), "": {(0, 0)}})

    def test_query_returns_full_region_regardless_of_starting_empty_point(self):
        board = Board(["BB", "BB", "  "])
        self.assertEqual(board.territory(0, 2), ("B", {(0, 2), (1, 2)}))
        self.assertEqual(board.territory(1, 2), ("B", {(0, 2), (1, 2)}))

    def test_stones_are_not_territory_coordinates(self):
        board = Board(["BBB", "B B", "BBB"])
        with self.assertRaises(ValueError):
            board.territory(0, 0)

    def test_whole_board_aggregates_connected_regions_once(self):
        board = Board(["BBB", "B B", "BBB"])
        self.assertEqual(board.territories(), {"B": {(1, 1)}, "W": set(), "": set()})

    def test_whole_board_separates_unowned_regions(self):
        board = Board(["B W", "   ", "W B"])
        self.assertEqual(
            board.territories(),
            {"B": set(), "W": set(), "": {(1, 0), (0, 1), (1, 1), (2, 1), (1, 2)}},
        )

    def test_provided_ignored_stones_example(self):
        board = Board(["IOOI", "O  O", "O OI", "IOI "])
        expected = {(x, y) for y in range(4) for x in range(4)}
        self.assertEqual(board.territory(1, 1), ("", expected))
        self.assertEqual(board.territories(), {"B": set(), "W": set(), "": expected})

    def test_all_invalid_coordinates_raise_with_message(self):
        board = Board(["BB", "WW"])
        for coordinate in [(-1, 0), (0, -1), (2, 0), (0, 2), (1.0, 0), (0, True)]:
            with self.subTest(coordinate=coordinate):
                with self.assertRaises(ValueError) as raised:
                    board.territory(*coordinate)
                self.assertTrue(str(raised.exception))


if __name__ == "__main__":
    unittest.main()
