class School:
    def __init__(self):
        self._students_by_grade = {}
        self._students = set()
        self._results = []

    def add_student(self, name, grade):
        if name in self._students:
            self._results.append(False)
            return False
        self._students.add(name)
        self._students_by_grade.setdefault(grade, []).append(name)
        self._results.append(True)
        return True

    def roster(self):
        return [
            name
            for _, names in sorted(self._students_by_grade.items())
            for name in sorted(names)
        ]

    def grade(self, grade_number):
        return sorted(self._students_by_grade.get(grade_number, []))

    def added(self):
        return self._results
