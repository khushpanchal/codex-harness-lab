class PhoneNumber:
    def __init__(self, number):
        if any(char.isalpha() for char in number):
            raise ValueError("letters not permitted")

        if any(not char.isdigit() and not char.isspace() and char not in "+().-" for char in number):
            raise ValueError("punctuations not permitted")

        digits = "".join(char for char in number if char.isdigit())
        digit_count = len(digits)

        if digit_count < 10:
            raise ValueError("must not be fewer than 10 digits")
        if digit_count > 11:
            raise ValueError("must not be greater than 11 digits")
        if digit_count == 11:
            if digits[0] != "1":
                raise ValueError("11 digits must start with 1")
            digits = digits[1:]

        if digits[0] == "0":
            raise ValueError("area code cannot start with zero")
        if digits[0] == "1":
            raise ValueError("area code cannot start with one")
        if digits[3] == "0":
            raise ValueError("exchange code cannot start with zero")
        if digits[3] == "1":
            raise ValueError("exchange code cannot start with one")

        self.number = digits
