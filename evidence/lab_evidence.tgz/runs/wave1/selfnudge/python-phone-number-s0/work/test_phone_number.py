import unittest

from phone_number import PhoneNumber


class PhoneNumberTests(unittest.TestCase):
    def test_examples_produce_the_clean_number(self):
        expected = "6139950253"
        for number in [
            "+1 (613)-995-0253",
            "613-995-0253",
            "1 613 995 0253",
            "613.995.0253",
        ]:
            with self.subTest(number=number):
                self.assertEqual(PhoneNumber(number).number, expected)

    def test_plain_ten_digit_number(self):
        self.assertEqual(PhoneNumber("6139950253").number, "6139950253")

    def test_country_code_as_one_without_sign(self):
        self.assertEqual(PhoneNumber("16139950253").number, "6139950253")

    def test_country_code_with_sign(self):
        self.assertEqual(PhoneNumber("+16139950253").number, "6139950253")

    def test_cleanup_uses_only_the_ten_national_digits(self):
        self.assertEqual(PhoneNumber("1 (223) 456-7890").number, "2234567890")

    def test_minimum_and_maximum_valid_boundaries(self):
        self.assertEqual(PhoneNumber("2234567890").number, "2234567890")
        self.assertEqual(PhoneNumber("12234567890").number, "2234567890")

    def test_fewer_than_ten_digits(self):
        for number in ["123456789", "(223) 456-78", "2234567890123456"[:9]]:
            with self.subTest(number=number):
                with self.assertRaisesRegex(ValueError, "fewer than 10 digits"):
                    PhoneNumber(number)

    def test_more_than_eleven_digits(self):
        for number in ["223456789012", "1 223 456 7890 0"]:
            with self.subTest(number=number):
                with self.assertRaisesRegex(ValueError, "greater than 11 digits"):
                    PhoneNumber(number)

    def test_eleven_digits_must_start_with_country_code_one(self):
        with self.assertRaisesRegex(ValueError, "11 digits must start with 1"):
            PhoneNumber("22234567890")

    def test_area_code_cannot_start_with_zero(self):
        with self.assertRaisesRegex(ValueError, "area code cannot start with zero"):
            PhoneNumber("0234567890")

    def test_area_code_cannot_start_with_one(self):
        with self.assertRaisesRegex(ValueError, "area code cannot start with one"):
            PhoneNumber("1234567890")

    def test_exchange_code_cannot_start_with_zero(self):
        with self.assertRaisesRegex(ValueError, "exchange code cannot start with zero"):
            PhoneNumber("2230567890")

    def test_exchange_code_cannot_start_with_one(self):
        with self.assertRaisesRegex(ValueError, "exchange code cannot start with one"):
            PhoneNumber("2231567890")

    def test_letters_are_not_permitted(self):
        for number in ["223-abc-7890", "+1 (613)-995-ABCD"]:
            with self.subTest(number=number):
                with self.assertRaisesRegex(ValueError, "letters not permitted"):
                    PhoneNumber(number)

    def test_punctuation_is_not_permitted(self):
        for number in ["223*456*7890", "223%456&7890", "1$223!456-7890"]:
            with self.subTest(number=number):
                with self.assertRaisesRegex(ValueError, "punctuations not permitted"):
                    PhoneNumber(number)

    def test_nanp_area_and_exchange_codes_are_enforced_after_country_code(self):
        with self.assertRaisesRegex(ValueError, "area code cannot start with one"):
            PhoneNumber("+11234567890")
        with self.assertRaisesRegex(ValueError, "exchange code cannot start with zero"):
            PhoneNumber("+12230567890")


if __name__ == "__main__":
    unittest.main()
