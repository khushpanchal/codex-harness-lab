import itertools
import unittest

from dominoes import can_chain


def forms_chain(order):
    """Independent brute-force oracle for the rules in the task description."""
    if len(order) == 0:
        return True

    chain = []
    for left, right in order:
        chain.extend([left, right])

    # The last right-hand half wraps around to the first left-hand half.
    return all(
        chain[index] == chain[(index + 1) % len(chain)]
        for index in range(1, len(chain), 2)
    )


def brute_force(dominoes):
    for order in itertools.permutations(dominoes):
        for orientations in itertools.product((False, True), repeat=len(order)):
            candidate = [
                (domino[1], domino[0]) if flipped else domino
                for domino, flipped in zip(order, orientations)
            ]
            if forms_chain(candidate):
                return True
    return False


class DominoesTests(unittest.TestCase):
    def test_empty_chain_has_no_mismatched_ends(self):
        self.assertIs(brute_force([]), True)
        self.assertIs(can_chain([]), True)

    def test_single_double_has_matching_ends(self):
        dominoes = [(1, 1)]
        self.assertIs(brute_force(dominoes), True)
        self.assertIs(can_chain(dominoes), True)

    def test_single_non_double_has_mismatched_ends(self):
        dominoes = [(1, 2)]
        self.assertIs(brute_force(dominoes), False)
        self.assertIs(can_chain(dominoes), False)

    def test_reversed_pair_forms_a_chain(self):
        dominoes = [(1, 2), (2, 1)]
        self.assertIs(brute_force(dominoes), True)
        self.assertIs(can_chain(dominoes), True)

    def test_description_triangle_example_forms_a_chain(self):
        dominoes = [(1, 2), (2, 3), (1, 3)]
        self.assertIs(brute_force(dominoes), True)
        self.assertIs(can_chain(dominoes), True)

    def test_description_triangle_example_can_be_oriented_and_reordered(self):
        dominoes = [(2, 1), (2, 3), (1, 3)]
        self.assertIs(brute_force(dominoes), True)
        self.assertIs(can_chain(dominoes), True)

    def test_description_invalid_example_has_mismatched_ends(self):
        dominoes = [(1, 2), (1, 4), (2, 3)]
        self.assertIs(brute_force(dominoes), False)
        self.assertIs(can_chain(dominoes), False)

    def test_duplicate_stones_are_treated_as_separate_dominoes(self):
        dominoes = [(1, 2), (1, 2)]
        self.assertIs(brute_force(dominoes), True)
        self.assertIs(can_chain(dominoes), True)

    def test_duplicates_requiring_multiple_solutions_are_allowed(self):
        dominoes = [(1, 2), (2, 3), (1, 3), (1, 2), (2, 3), (1, 3)]
        self.assertIs(brute_force(dominoes), True)
        self.assertIs(can_chain(dominoes), True)

    def test_disconnected_components_cannot_form_one_chain(self):
        dominoes = [(1, 2), (2, 1), (3, 4), (4, 3)]
        self.assertIs(brute_force(dominoes), False)
        self.assertIs(can_chain(dominoes), False)

    def test_double_does_not_connect_two_separate_components(self):
        dominoes = [(1, 2), (2, 3), (1, 3), (4, 4)]
        self.assertIs(brute_force(dominoes), False)
        self.assertIs(can_chain(dominoes), False)

    def test_doubles_alone_are_not_necessarily_connected(self):
        dominoes = [(1, 1), (2, 2)]
        self.assertIs(brute_force(dominoes), False)
        self.assertIs(can_chain(dominoes), False)

    def test_doubles_can_be_inserted_into_a_matching_chain(self):
        dominoes = [(1, 2), (2, 3), (1, 3), (1, 1), (2, 2), (3, 3)]
        self.assertIs(brute_force(dominoes), True)
        self.assertIs(can_chain(dominoes), True)

    def test_small_random_cases_match_brute_force_oracle(self):
        stones = [(1, 1), (1, 2), (2, 2), (2, 3), (3, 3), (1, 3)]
        for count in range(6):
            for dominoes in itertools.combinations(stones, count):
                self.assertIs(can_chain(list(dominoes)), brute_force(list(dominoes)),
                              dominoes)


if __name__ == "__main__":
    unittest.main()
