def can_chain(dominoes):
    degree = {}
    adjacency = {}

    for left, right in dominoes:
        if left == right:
            degree[left] = degree.get(left, 0) + 2
        else:
            degree[left] = degree.get(left, 0) + 1
            degree[right] = degree.get(right, 0) + 1
        adjacency.setdefault(left, set()).add(right)
        adjacency.setdefault(right, set()).add(left)

    if not degree:
        return True

    if any(count % 2 for count in degree.values()):
        return False

    start = next(iter(degree))
    seen = {start}
    stack = [start]
    while stack:
        node = stack.pop()
        for neighbor in adjacency[node]:
            if neighbor not in seen:
                seen.add(neighbor)
                stack.append(neighbor)

    return seen == set(degree)
