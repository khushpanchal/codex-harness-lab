def encode(plain_text, a, b):
    """Encrypt text with the affine cipher and group it into five-letter blocks."""
    _validate_key(a)
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    normalized = "".join(char for char in plain_text.lower() if char.isalnum())

    encrypted = []
    for char in normalized:
        if char.isdigit():
            encrypted.append(char)
        else:
            index = alphabet.index(char)
            encrypted.append(alphabet[(a * index + b) % len(alphabet)])

    ciphered = "".join(encrypted)
    return " ".join(ciphered[i:i + 5] for i in range(0, len(ciphered), 5))


def decode(ciphered_text, a, b):
    """Decrypt text produced by the affine cipher."""
    _validate_key(a)
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    inverse_a = pow(a, -1, len(alphabet))
    normalized = "".join(char for char in ciphered_text.lower() if char.isalnum())

    decoded = []
    for char in normalized:
        if char.isdigit():
            decoded.append(char)
        else:
            index = alphabet.index(char)
            decoded.append(alphabet[(inverse_a * (index - b)) % len(alphabet)])

    return "".join(decoded)


def _validate_key(a):
    from math import gcd

    if gcd(a, 26) != 1:
        raise ValueError("a and m must be coprime.")
