import unittest

from affine_cipher import decode, encode


class AffineCipherTests(unittest.TestCase):
    def test_encode_examples(self):
        self.assertEqual(encode("test", 5, 7), "ybty")
        self.assertEqual(encode("the quick brown fox jumps over the lazy dog", 19, 13),
                         "kqlfd jzvgy tpaet icdhm rtwly kqlon ubstx")

    def test_decode_examples(self):
        self.assertEqual(decode("ybty", 5, 7), "test")
        self.assertEqual(decode("ybty", 11, 7), "lqul")
        self.assertEqual(decode("kqlfd jzvgy tpaet icdhm rtwly kqlon ubstx", 19, 13),
                         "thequickbrownfoxjumpsoverthelazydog")

    def test_decode_ignores_spacing_and_punctuation(self):
        self.assertEqual(decode("kqlf.d! jzvgy\t tpaet-icdhm\nrtwly; kqlon, ubstx", 19, 13),
                         "thequickbrownfoxjumpsoverthelazydog")

    def test_encode_normalizes_case_and_excludes_spaces_and_punctuation(self):
        self.assertEqual(encode("The Quick, Brown Fox!", 19, 13),
                         "kqlfd jzvgy tpaet i")

    def test_encode_groups_in_fives_with_trailing_short_group(self):
        self.assertEqual(encode("abcdefghi", 5, 7), "hmrwb glqv")
        self.assertEqual(encode("abcdefgh", 5, 7), "hmrwb glq")

    def test_encode_preserves_digits_but_does_not_encrypt_them(self):
        self.assertEqual(encode("a1b2c", 5, 7), "h1m2r")

    def test_decode_preserves_digits_but_does_not_decrypt_them(self):
        self.assertEqual(decode("h1m2r", 5, 7), "a1b2c")

    def test_encode_round_trip(self):
        plaintext = "Testing, punctuation; and digits 12345."
        ciphertext = encode(plaintext, 11, 8)
        self.assertEqual(decode(ciphertext, 11, 8), "testingpunctuationanddigits12345")

    def test_valid_coprime_keys(self):
        for a in (1, 3, 5, 7, 9, 11, 15, 17, 19, 21, 23, 25):
            self.assertEqual(decode(encode("abcxyz", a, 8), a, 8), "abcxyz")

    def test_invalid_keys_are_not_coprime_to_m(self):
        for a in (0, 2, 4, 6, 8, 10, 12, 13, 14, 16, 18, 20, 22, 24, 26):
            with self.subTest(a=a):
                with self.assertRaisesRegex(ValueError, "a and m must be coprime."):
                    encode("test", a, 7)
                with self.assertRaisesRegex(ValueError, "a and m must be coprime."):
                    decode("ybty", a, 7)


if __name__ == "__main__":
    unittest.main()
