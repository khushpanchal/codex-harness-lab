import unittest

from bottle_song import recite


TEN = """Ten green bottles hanging on the wall,
Ten green bottles hanging on the wall,
And if one green bottle should accidentally fall,
There'll be nine green bottles hanging on the wall."""

NINE = """Nine green bottles hanging on the wall,
Nine green bottles hanging on the wall,
And if one green bottle should accidentally fall,
There'll be eight green bottles hanging on the wall."""

EIGHT = """Eight green bottles hanging on the wall,
Eight green bottles hanging on the wall,
And if one green bottle should accidentally fall,
There'll be seven green bottles hanging on the wall."""

SEVEN = """Seven green bottles hanging on the wall,
Seven green bottles hanging on the wall,
And if one green bottle should accidentally fall,
There'll be six green bottles hanging on the wall."""

SIX = """Six green bottles hanging on the wall,
Six green bottles hanging on the wall,
And if one green bottle should accidentally fall,
There'll be five green bottles hanging on the wall."""

FIVE = """Five green bottles hanging on the wall,
Five green bottles hanging on the wall,
And if one green bottle should accidentally fall,
There'll be four green bottles hanging on the wall."""

FOUR = """Four green bottles hanging on the wall,
Four green bottles hanging on the wall,
And if one green bottle should accidentally fall,
There'll be three green bottles hanging on the wall."""

THREE = """Three green bottles hanging on the wall,
Three green bottles hanging on the wall,
And if one green bottle should accidentally fall,
There'll be two green bottles hanging on the wall."""

TWO = """Two green bottles hanging on the wall,
Two green bottles hanging on the wall,
And if one green bottle should accidentally fall,
There'll be one green bottle hanging on the wall."""

ONE = """One green bottle hanging on the wall,
One green bottle hanging on the wall,
And if one green bottle should accidentally fall,
There'll be no green bottles hanging on the wall."""


class BottleSongTests(unittest.TestCase):
    def test_each_verse_matches_the_task_text(self):
        expected = [TEN, NINE, EIGHT, SEVEN, SIX, FIVE, FOUR, THREE, TWO, ONE]
        for start, verse in enumerate(reversed(expected), start=1):
            with self.subTest(start=start):
                self.assertEqual(recite(start), verse)

    def test_default_take_is_one_verse(self):
        self.assertEqual(recite(3, 1), THREE)

    def test_multiple_verses_are_consecutive_and_blank_line_separated(self):
        self.assertEqual(recite(10, 3), "\n\n".join((TEN, NINE, EIGHT)))
        self.assertEqual(recite(2, 2), "\n\n".join((TWO, ONE)))

    def test_full_song_starts_at_ten_and_has_ten_verses(self):
        all_verses = [TEN, NINE, EIGHT, SEVEN, SIX, FIVE, FOUR, THREE, TWO, ONE]
        self.assertEqual(recite(10, 10), "\n\n".join(all_verses))

    def test_take_one_uses_default_argument_directly(self):
        self.assertEqual(recite(7), SEVEN)


if __name__ == "__main__":
    unittest.main()
