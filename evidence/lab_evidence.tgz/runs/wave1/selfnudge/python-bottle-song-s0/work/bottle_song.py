WORDS = [
    "no",
    "one",
    "two",
    "three",
    "four",
    "five",
    "six",
    "seven",
    "eight",
    "nine",
    "ten",
]


def _verse(start):
    current = WORDS[start].capitalize()
    current_word = WORDS[start]
    next_word = WORDS[start - 1]
    current_noun = "bottles" if start != 1 else "bottle"
    next_noun = "bottles" if start - 1 != 1 else "bottle"

    return (
        f"{current} green {current_noun} hanging on the wall,\n"
        f"{current} green {current_noun} hanging on the wall,\n"
        f"And if one green bottle should accidentally fall,\n"
        f"There'll be {next_word} green {next_noun} hanging on the wall."
    )


def recite(start, take=1):
    verses = [_verse(count) for count in range(start, start - take, -1)]
    return "\n\n".join(verses)
