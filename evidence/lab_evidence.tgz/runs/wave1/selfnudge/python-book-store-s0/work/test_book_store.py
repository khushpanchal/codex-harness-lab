import unittest

from book_store import total


class BookStoreTests(unittest.TestCase):
    def test_empty_basket_costs_nothing(self):
        self.assertEqual(total((0, 0, 0, 0, 0)), 0)

    def test_each_single_book_has_no_discount(self):
        for title in range(5):
            counts = [0] * 5
            counts[title] = 1
            with self.subTest(title=title):
                self.assertEqual(total(counts), 8)

    def test_pair_of_different_books_gets_five_percent(self):
        self.assertEqual(total((1, 1, 0, 0, 0)), 15.2)

    def test_duplicate_books_get_no_discount(self):
        self.assertEqual(total((2, 0, 0, 0, 0)), 16)

    def test_three_different_books_get_ten_percent(self):
        self.assertEqual(total((1, 1, 1, 0, 0)), 21.6)

    def test_three_books_with_a_duplicate_get_one_discounted_pair(self):
        self.assertEqual(total((2, 1, 0, 0, 0)), 23.2)

    def test_four_different_books_get_twenty_percent(self):
        self.assertEqual(total((1, 1, 1, 1, 0)), 25.6)

    def test_four_books_with_one_duplicate_group_three_discounted_books(self):
        self.assertEqual(total((2, 1, 1, 0, 0)), 29.6)

    def test_two_pairs_are_less_expensive_than_one_discounted_pair_plus_singles(self):
        self.assertEqual(total((2, 2, 0, 0, 0)), 30.4)

    def test_five_different_books_get_twenty_five_percent(self):
        self.assertEqual(total((1, 1, 1, 1, 1)), 30)

    def test_five_books_with_one_duplicate_group_four_then_one(self):
        self.assertEqual(total((2, 1, 1, 1, 0)), 33.6)

    def test_two_pairs_and_a_single_group_three_then_two(self):
        self.assertEqual(total((2, 2, 1, 0, 0)), 36.8)

    def test_three_copies_and_two_others_group_three_then_two_singles(self):
        self.assertEqual(total((3, 1, 1, 0, 0)), 37.6)

    def test_five_identical_books_have_no_discount(self):
        self.assertEqual(total((5, 0, 0, 0, 0)), 40)

    def test_worked_example_prefers_two_groups_of_four(self):
        self.assertEqual(total((2, 2, 2, 1, 1)), 51.2)

    def test_four_pairs_are_best_grouped_as_two_groups_of_four(self):
        self.assertEqual(total((2, 2, 2, 2, 0)), 51.2)

    def test_five_pairs_are_best_grouped_as_one_group_of_five_and_four_singles(self):
        self.assertEqual(total((2, 2, 2, 2, 2)), 60.0)


if __name__ == "__main__":
    unittest.main()
