from itertools import combinations
from functools import lru_cache


def total(basket):
    counts = tuple(int(quantity) for quantity in basket)

    @lru_cache(maxsize=None)
    def best_price_cents(remaining):
        remaining = tuple(sorted(quantity for quantity in remaining if quantity))
        if not remaining:
            return 0
        titles = range(len(remaining))
        minimum = None

        for size in range(1, len(remaining) + 1):
            discount_percent = 0
            if size == 2:
                discount_percent = 5
            elif size == 3:
                discount_percent = 10
            elif size == 4:
                discount_percent = 20
            elif size == 5:
                discount_percent = 25

            group_price = size * 800 * (100 - discount_percent) // 100

            for titles_to_remove in combinations(titles, size):
                next_counts = list(remaining)
                for title in titles_to_remove:
                    next_counts[title] -= 1
                candidate = group_price + best_price_cents(tuple(next_counts))
                if minimum is None or candidate < minimum:
                    minimum = candidate

        return minimum

    return best_price_cents(counts) / 100
