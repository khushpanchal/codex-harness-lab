import io
import socket
import unittest
from unittest import mock

from paasio import MeteredFile, MeteredSocket


class MeteredFileTests(unittest.TestCase):
    class FailingFile:
        def __init__(self, fail_read=False, fail_write=False):
            self.buffer = io.BytesIO()
            self.fail_read = fail_read
            self.fail_write = fail_write

        def readinto(self, b):
            if self.fail_read:
                raise OSError("read failed")
            return self.buffer.readinto(b)

        def write(self, b):
            if self.fail_write:
                raise OSError("write failed")
            return super().write(b)

    def test_initial_counters_are_zero(self):
        with MeteredFile(io.BytesIO()) as metered:
            self.assertEqual(metered.read_bytes, 0)
            self.assertEqual(metered.read_ops, 0)
            self.assertEqual(metered.write_bytes, 0)
            self.assertEqual(metered.write_ops, 0)

    def test_write_reports_bytes_and_operations(self):
        with MeteredFile(io.BytesIO()) as metered:
            self.assertEqual(metered.write(b"hello"), 5)
            self.assertEqual(metered.write(b"!"), 1)
            self.assertEqual(metered.write_bytes, 6)
            self.assertEqual(metered.write_ops, 2)

    def test_read_reports_bytes_and_operations(self):
        with MeteredFile(io.BytesIO(b"abcdef")) as metered:
            self.assertEqual(metered.read(2), b"ab")
            self.assertEqual(metered.read(10), b"cdef")
            self.assertEqual(metered.read_bytes, 6)
            self.assertEqual(metered.read_ops, 2)

    def test_read_all_reports_all_bytes(self):
        with MeteredFile(io.BytesIO(b"all data")) as metered:
            self.assertEqual(metered.read(), b"all data")
            self.assertEqual(metered.read_bytes, 8)
            self.assertEqual(metered.read_ops, 1)

    def test_empty_read_counts_operation_but_not_bytes(self):
        with MeteredFile(io.BytesIO()) as metered:
            self.assertEqual(metered.read(0), b"")
            self.assertEqual(metered.read_bytes, 0)
            self.assertEqual(metered.read_ops, 1)

    def test_iteration_reads_lines(self):
        with MeteredFile(io.BytesIO(b"one\ntwo\n")) as metered:
            self.assertEqual(list(metered), [b"one\n", b"two\n"])
            self.assertEqual(metered.read_bytes, 7)
            self.assertEqual(metered.read_ops, 2)

    def test_failed_write_does_not_change_statistics(self):
        with MeteredFile(self.FailingBuffer(fail_write=True)) as metered:
            with self.assertRaises(OSError):
                metered.write(b"data")
            self.assertEqual(metered.write_bytes, 0)
            self.assertEqual(metered.write_ops, 0)

    def test_failed_read_does_not_change_statistics(self):
        with MeteredFile(self.FailingBuffer(fail_read=True)) as metered:
            with self.assertRaises(OSError):
                metered.read(4)
            self.assertEqual(metered.read_bytes, 0)
            self.assertEqual(metered.read_ops, 0)


class MeteredSocketTests(unittest.TestCase):
    def setUp(self):
        self.socket = mock.create_autospec(socket.socket, instance=True)

    def test_initial_counters_are_zero(self):
        metered = MeteredSocket(self.socket)
        self.assertEqual(metered.recv_bytes, 0)
        self.assertEqual(metered.recv_ops, 0)
        self.assertEqual(metered.send_bytes, 0)
        self.assertEqual(metered.send_ops, 0)

    def test_send_reports_bytes_and_operations(self):
        self.socket.send.return_value = 4
        metered = MeteredSocket(self.socket)
        self.assertEqual(metered.send(b"data"), 4)
        self.assertEqual(metered.send(b"!!"), 2)
        self.socket.send.assert_has_calls([mock.call(b"data", 0), mock.call(b"!!", 0)])
        self.assertEqual(metered.send_bytes, 6)
        self.assertEqual(metered.send_ops, 2)

    def test_recv_reports_bytes_and_operations(self):
        self.socket.recv.side_effect = [b"abc", b"de"]
        metered = MeteredSocket(self.socket)
        self.assertEqual(metered.recv(5), b"abc")
        self.assertEqual(metered.recv(5), b"de")
        self.socket.recv.assert_has_calls([mock.call(5, 0), mock.call(5, 0)])
        self.assertEqual(metered.recv_bytes, 5)
        self.assertEqual(metered.recv_ops, 2)

    def test_empty_recv_counts_operation_but_not_bytes(self):
        self.socket.recv.return_value = b""
        metered = MeteredSocket(self.socket)
        self.assertEqual(metered.recv(10), b"")
        self.assertEqual(metered.recv_bytes, 0)
        self.assertEqual(metered.recv_ops, 1)

    def test_flags_are_forwarded(self):
        self.socket.recv.return_value = b"x"
        self.socket.send.return_value = 1
        metered = MeteredSocket(self.socket)
        self.assertEqual(metered.recv(1, socket.MSG_PEEK), b"x")
        self.assertEqual(metered.send(b"x", socket.MSG_DONTROUTE), 1)
        self.socket.recv.assert_called_once_with(1, socket.MSG_PEEK)
        self.socket.send.assert_called_once_with(b"x", socket.MSG_DONTROUTE)

    def test_failed_operations_do_not_change_statistics(self):
        self.socket.recv.side_effect = OSError("recv failed")
        self.socket.send.side_effect = OSError("send failed")
        metered = MeteredSocket(self.socket)
        with self.assertRaises(OSError):
            metered.recv(4)
        with self.assertRaises(OSError):
            metered.send(b"data")
        self.assertEqual(metered.recv_bytes, 0)
        self.assertEqual(metered.recv_ops, 0)
        self.assertEqual(metered.send_bytes, 0)
        self.assertEqual(metered.send_ops, 0)

    def test_context_manager_wraps_and_delegates(self):
        metered = MeteredSocket(self.socket)
        with metered as wrapped:
            self.assertIs(wrapped, metered)
        self.socket.__exit__.assert_called_once_with(None, None, None)

    def test_unknown_attributes_are_delegated(self):
        self.socket.fileno.return_value = 17
        metered = MeteredSocket(self.socket)
        self.assertEqual(metered.fileno(), 17)
        self.socket.fileno.assert_called_once_with()


if __name__ == "__main__":
    unittest.main()
