# Game status categories
# Change the values as you see fit
STATUS_WIN = 'win'
STATUS_LOSE = 'lose'
STATUS_ONGOING = 'ongoing'


class Hangman:
    def __init__(self, word):
        self.remaining_guesses = 9
        self.status = STATUS_ONGOING
        self._word = word
        self._guessed_characters = []

    def guess(self, char):
        self.get_status()

        guessed_characters = set(self._guessed_characters)
        if char not in guessed_characters:
            self._guessed_characters.append(char)
            self.remaining_guesses = 9 - len(
                set(letter for letter in self._guessed_characters if letter not in self._word)
            )

        self.get_status()

    def get_masked_word(self):
        guessed_characters = set(self._guessed_characters)
        return "".join(
            char if char in guessed_characters else "_"
            for char in self._word
        )

    def get_status(self):
        guessed_characters = set(self._guessed_characters)
        if all(char in guessed_characters for char in self._word):
            self.status = STATUS_WIN
        elif self.remaining_guesses == -1:
            self.status = STATUS_LOSE

        if self.status != STATUS_ONGOING:
            raise ValueError("The game has already ended.")

        return self.status
