def grep(pattern, flags, files):
    case_insensitive = "-i" in flags
    line_numbers = "-n" in flags
    files_with_matches = "-l" in flags
    invert_match = "-v" in flags
    whole_line = "-x" in flags

    if case_insensitive:
        pattern = pattern.lower()

    matches = []
    matched_files = set()

    for filename in files:
        with open(filename, encoding="utf-8") as source:
            for line_number, line in enumerate(source, start=1):
                candidate = line.rstrip("\n")
                needle = candidate.lower() if case_insensitive else candidate
                is_match = needle == pattern if whole_line else pattern in needle
                if is_match != invert_match:
                    if files_with_matches:
                        matched_files.add(filename)
                    elif len(files) > 1:
                        prefix = f"{filename}:{line_number}:" if line_numbers else f"{filename}:"
                        matches.append(prefix + candidate)
                    else:
                        prefix = f"{line_number}:" if line_numbers else ""
                        matches.append(prefix + candidate)

    if files_with_matches:
        return [filename for filename in files if filename in matched_files]
    return matches
