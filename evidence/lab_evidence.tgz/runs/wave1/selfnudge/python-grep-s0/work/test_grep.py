import os
import tempfile
import unittest

from grep import grep


class GrepTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def path(self, name, contents):
        filename = os.path.join(self.tmp.name, name)
        with open(filename, "w", encoding="utf-8") as f:
            f.write(contents)
        return filename

    def test_matches_fixed_string_case_sensitively(self):
        filename = self.path("input.txt", "apple\nAn apple\nApple\nsnapple\n")
        self.assertEqual(grep("apple", [], [filename]), ["apple", "An apple", "snapple"])

    def test_number_flag_prepends_line_numbers(self):
        filename = self.path("input.txt", "one\nnot it\none\n")
        self.assertEqual(grep("one", ["-n"], [filename]), ["1:one", "3:one"])

    def test_files_flag_outputs_unique_names_in_input_order(self):
        first = self.path("first.txt", "target\n")
        second = self.path("second.txt", "no match\n")
        third = self.path("third.txt", "target\ntarget\n")
        self.assertEqual(grep("target", ["-l"], [first, second, third]), [first, third])

    def test_case_insensitive_flag(self):
        filename = self.path("input.txt", "Fruit\nfruit\nFRUIT\nberry\n")
        self.assertEqual(grep("fruit", ["-i"], [filename]), ["Fruit", "fruit", "FRUIT"])

    def test_invert_flag_selects_nonmatching_lines(self):
        filename = self.path("input.txt", "match\nbefore\nmatch\nafter\n")
        self.assertEqual(grep("match", ["-v"], [filename]), ["before", "after"])

    def test_exact_line_flag(self):
        filename = self.path("input.txt", "whole\nwhole line\na whole line\n")
        self.assertEqual(grep("whole line", ["-x"], [filename]), ["whole line"])

    def test_multiple_files_are_prefixed_with_names_and_preserve_order(self):
        first = self.path("first.txt", "needle\nother\n")
        second = self.path("second.txt", "nothing\nneedle\n")
        self.assertEqual(
            grep("needle", [], [first, second]),
            [f"{first}:needle", f"{second}:needle"],
        )

    def test_number_with_multiple_files_places_number_after_filename(self):
        first = self.path("first.txt", "needle\n")
        second = self.path("second.txt", "nothing\nneedle\n")
        self.assertEqual(
            grep("needle", ["-n"], [first, second]),
            [f"{first}:1:needle", f"{second}:2:needle"],
        )

    def test_files_flag_ignores_number_flag_output_format(self):
        filename = self.path("input.txt", "one\ntarget\n")
        self.assertEqual(grep("target", ["-l", "-n"], [filename]), [filename])

    def test_invert_with_case_insensitive(self):
        filename = self.path("input.txt", "MATCH\nhit\nmatch\n")
        self.assertEqual(grep("match", ["-i", "-v"], [filename]), ["hit"])

    def test_invert_with_exact_line(self):
        filename = self.path("input.txt", "whole\nwhole line\n")
        self.assertEqual(grep("whole", ["-v", "-x"], [filename]), ["whole line"])

    def test_number_with_inverted_matches(self):
        filename = self.path("input.txt", "target\nfirst\nsecond\n")
        self.assertEqual(grep("target", ["-n", "-v"], [filename]), ["2:first", "3:second"])

    def test_files_flag_with_inverted_matches(self):
        matching = self.path("matching.txt", "target\n")
        inverted = self.path("inverted.txt", "before\nafter\n")
        self.assertEqual(grep("target", ["-l", "-v"], [matching, inverted]), [inverted])

    def test_repeated_flags_are_ignored(self):
        filename = self.path("input.txt", "target\n")
        self.assertEqual(grep("target", ["-n", "-n"], [filename]), ["1:target"])

    def test_empty_file_has_no_matches(self):
        filename = self.path("empty.txt", "")
        self.assertEqual(grep("target", [], [filename]), [])

    def test_empty_pattern_matches_every_line(self):
        filename = self.path("input.txt", "one\n\ntwo\n")
        self.assertEqual(grep("", ["-n"], [filename]), ["1:one", "2:", "3:two"])

    def test_empty_pattern_with_exact_line_matches_empty_lines(self):
        filename = self.path("input.txt", "one\n\ntwo\n")
        self.assertEqual(grep("", ["-x"], [filename]), [""])

    def test_pattern_containing_newline_does_not_span_lines(self):
        filename = self.path("input.txt", "first\nsecond\n")
        self.assertEqual(grep("first\nsecond", [], [filename]), [])

    def test_multiple_files_with_no_matches(self):
        first = self.path("first.txt", "nothing\n")
        second = self.path("second.txt", "also nothing\n")
        self.assertEqual(grep("target", [], [first, second]), [])

    def test_requires_at_least_one_file(self):
        with self.assertRaises(TypeError):
            grep("target", [])

    def test_missing_file_raises_the_filesystem_error(self):
        missing = os.path.join(self.tmp.name, "missing.txt")
        with self.assertRaises(OSError):
            grep("target", [], [missing])


if __name__ == "__main__":
    unittest.main()
