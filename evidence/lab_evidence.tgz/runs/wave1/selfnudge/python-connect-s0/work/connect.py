
class ConnectGame:
    OFFSETS = ((-1, -1), (-1, 0), (0, -1), (0, 1), (1, 0), (1, 1))

    def __init__(self, board):
        self.rows = [row.replace(" ", "").upper() for row in board]
        self.height = len(self.rows)
        self.width = len(self.rows[0]) if self.rows else 0

    def get_winner(self):
        if self.height == 0 or self.width == 0:
            return ""

        if self.has_connection(
            "O",
            [(0, column) for column in range(self.width)],
            lambda row, column: row == self.height - 1,
        ):
            return "O"

        if self.has_connection(
            "X",
            [(row, 0) for row in range(self.height)],
            lambda row, column: column == self.width - 1,
        ):
            return "X"

        return ""

    def has_connection(self, player, starting_cells, reached_opposite_side):
        frontier = []
        seen = set()

        for cell in starting_cells:
            row, column = cell
            if self.rows[row][column] == player:
                seen.add(cell)
                frontier.append(cell)

        while frontier:
            row, column = frontier.pop()
            if reached_opposite_side(row, column):
                return True

            for row_offset, column_offset in self.OFFSETS:
                neighbor = (row + row_offset, column + column_offset)
                if neighbor in seen or not self.is_on_board(*neighbor):
                    continue
                if self.rows[neighbor[0]][neighbor[1]] == player:
                    seen.add(neighbor)
                    frontier.append(neighbor)

        return False

    def is_on_board(self, row, column):
        return 0 <= row < self.height and 0 <= column < len(self.rows[row])
